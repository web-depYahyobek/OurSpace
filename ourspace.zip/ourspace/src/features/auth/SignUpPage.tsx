import { useState, type FormEvent } from 'react'
import { Link, useLocation } from 'react-router-dom'
import { MailCheck } from 'lucide-react'
import { supabase } from '../../lib/supabase'
import { friendlyError } from '../../lib/errors'
import { safeNext } from '../../lib/navigation'
import { Alert } from '../../components/ui/Alert'
import { Button } from '../../components/ui/Button'
import { TextField } from '../../components/ui/Field'
import { AuthLayout } from './AuthLayout'
import { PasswordField } from './PasswordField'

const MIN_PASSWORD = 8

export function SignUpPage() {
  const { search } = useLocation()
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [passwordError, setPasswordError] = useState<string | null>(null)
  const [sentTo, setSentTo] = useState<string | null>(null)

  const onSubmit = async (e: FormEvent) => {
    e.preventDefault()
    setError(null)
    if (password.length < MIN_PASSWORD) {
      setPasswordError(`Use at least ${MIN_PASSWORD} characters.`)
      return
    }
    setPasswordError(null)
    setBusy(true)
    const cleanEmail = email.trim()
    const { data, error: err } = await supabase.auth.signUp({
      email: cleanEmail,
      password,
      options: { emailRedirectTo: window.location.origin + safeNext(search) },
    })
    setBusy(false)
    if (err) {
      setError(friendlyError(err))
      return
    }
    // With email confirmation on, there is no session yet: ask them to check their inbox.
    if (!data.session) setSentTo(cleanEmail)
  }

  if (sentTo) {
    return (
      <AuthLayout title="Check your email">
        <div className="flex flex-col items-center text-center">
          <span className="mb-4 flex size-14 items-center justify-center rounded-2xl bg-brand-600/15 text-brand-400">
            <MailCheck className="size-7" aria-hidden />
          </span>
          <p className="text-muted">
            We sent a confirmation link to <span className="font-semibold text-ink">{sentTo}</span>. Open it on this device to finish
            creating your account.
          </p>
          <Link to={`/sign-in${search}`} className="btn btn-secondary mt-6 w-full">
            Back to sign in
          </Link>
        </div>
      </AuthLayout>
    )
  }

  return (
    <AuthLayout
      title="Create your account"
      subtitle="You'll need an invite from your group to see anything inside."
      footer={
        <>
          Already have an account?{' '}
          <Link to={`/sign-in${search}`} className="font-semibold text-brand-400 hover:text-brand-300">
            Sign in
          </Link>
        </>
      }
    >
      <form onSubmit={onSubmit} className="space-y-4">
        {error && <Alert>{error}</Alert>}
        <TextField label="Email" type="email" autoComplete="email" required value={email} onChange={(e) => setEmail(e.target.value)} />
        <PasswordField
          value={password}
          onChange={setPassword}
          autoComplete="new-password"
          hint={`At least ${MIN_PASSWORD} characters.`}
          error={passwordError}
        />
        <Button type="submit" className="w-full" loading={busy}>
          Create account
        </Button>
      </form>
    </AuthLayout>
  )
}
