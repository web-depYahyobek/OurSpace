import type { ReactNode } from 'react'
import { Link } from 'react-router-dom'
import { LogoMark } from '../../components/layout/Logo'

export function AuthLayout({ title, subtitle, children, footer }: { title: string; subtitle?: string; children: ReactNode; footer?: ReactNode }) {
  return (
    <main className="mx-auto flex min-h-dvh w-full max-w-md flex-col justify-center px-5 py-10">
      <Link to="/welcome" className="mb-8 flex items-center gap-3 self-center" aria-label="OurSpace">
        <LogoMark className="size-12" />
        <span className="text-2xl font-bold tracking-tight">OurSpace</span>
      </Link>
      <div className="card animate-rise p-6 sm:p-8">
        <h1 className="text-2xl font-bold tracking-tight">{title}</h1>
        {subtitle && <p className="mt-1.5 text-sm text-muted">{subtitle}</p>}
        <div className="mt-6">{children}</div>
      </div>
      {footer && <div className="mt-6 text-center text-sm text-muted">{footer}</div>}
    </main>
  )
}
