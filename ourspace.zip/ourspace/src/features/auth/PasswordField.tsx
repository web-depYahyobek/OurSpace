import { useId, useState } from 'react'
import { Eye, EyeOff } from 'lucide-react'

export function PasswordField({
  value,
  onChange,
  autoComplete,
  label = 'Password',
  hint,
  error,
}: {
  value: string
  onChange: (value: string) => void
  autoComplete: 'current-password' | 'new-password'
  label?: string
  hint?: string
  error?: string | null
}) {
  const id = useId()
  const [visible, setVisible] = useState(false)
  return (
    <div>
      <label htmlFor={id} className="label">
        {label}
      </label>
      <div className="relative">
        <input
          id={id}
          type={visible ? 'text' : 'password'}
          className="input pr-12"
          value={value}
          onChange={(e) => onChange(e.target.value)}
          autoComplete={autoComplete}
          required
          aria-invalid={error ? true : undefined}
          aria-describedby={error || hint ? `${id}-help` : undefined}
        />
        <button
          type="button"
          onClick={() => setVisible((v) => !v)}
          className="absolute inset-y-0 right-0 flex w-11 items-center justify-center text-faint hover:text-ink"
          aria-label={visible ? 'Hide password' : 'Show password'}
        >
          {visible ? <EyeOff className="size-5" /> : <Eye className="size-5" />}
        </button>
      </div>
      {(error || hint) && (
        <p id={`${id}-help`} className={error ? 'mt-1.5 text-sm text-danger' : 'mt-1.5 text-xs text-faint'}>
          {error || hint}
        </p>
      )}
    </div>
  )
}
