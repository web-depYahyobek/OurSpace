import { Link, useLocation } from 'react-router-dom'
import { CalendarDays, Images, Lock, Megaphone, MessageCircle, Vote } from 'lucide-react'
import { LogoMark } from '../../components/layout/Logo'

const features = [
  { icon: MessageCircle, title: 'Group chat', text: 'Talk in real time.' },
  { icon: Images, title: 'Shared photos', text: 'Keep your memories together.' },
  { icon: Vote, title: 'Polls', text: 'Decide things quickly.' },
  { icon: CalendarDays, title: 'Events', text: 'Plan meetups and RSVP.' },
  { icon: Megaphone, title: 'Announcements', text: 'Pin what matters.' },
]

export function WelcomePage() {
  const { search } = useLocation()
  return (
    <main className="mx-auto flex min-h-dvh max-w-5xl flex-col items-center justify-center gap-12 px-6 py-12 lg:flex-row lg:gap-20">
      <section className="flex max-w-md flex-col items-center text-center lg:items-start lg:text-left">
        <div className="relative">
          <div className="absolute inset-0 -z-10 scale-150 rounded-full bg-brand-600/25 blur-3xl" aria-hidden />
          <LogoMark className="size-28" />
        </div>
        <h1 className="mt-8 text-5xl font-extrabold tracking-tight">OurSpace</h1>
        <p className="mt-2 text-xl font-medium text-muted">Friends. Together.</p>
        <p className="mt-5 text-muted">
          A private space for your friend group: chat, share photos, make decisions and plan meetups, all in one place.
        </p>
        <p className="mt-5 inline-flex items-center gap-2 rounded-full border border-brand-500/30 bg-brand-500/10 px-4 py-2 text-sm text-brand-300">
          <Lock className="size-4" aria-hidden /> Only your group. No strangers.
        </p>
        <div className="mt-8 flex w-full flex-col gap-3 sm:flex-row lg:w-auto">
          <Link to={`/sign-up${search}`} className="btn btn-primary px-8">
            Get started
          </Link>
          <Link to={`/sign-in${search}`} className="btn btn-secondary px-8">
            Sign in
          </Link>
        </div>
      </section>

      <ul className="grid w-full max-w-md gap-3">
        {features.map(({ icon: Icon, title, text }) => (
          <li key={title} className="card flex items-center gap-4 p-4">
            <span className="flex size-11 shrink-0 items-center justify-center rounded-xl bg-brand-600/15 text-brand-400">
              <Icon className="size-5" aria-hidden />
            </span>
            <span>
              <span className="block font-semibold">{title}</span>
              <span className="block text-sm text-muted">{text}</span>
            </span>
          </li>
        ))}
      </ul>
    </main>
  )
}
