import { useCallback, useEffect, useState, type FormEvent } from 'react'
import { Megaphone, Pin, PinOff, Plus, Trash2 } from 'lucide-react'
import { useMe } from '../../contexts/AuthContext'
import { useCurrentGroup, useGroup } from '../../contexts/GroupContext'
import { useToast } from '../../contexts/ToastContext'
import { supabase } from '../../lib/supabase'
import { friendlyError } from '../../lib/errors'
import { formatDateTime, timeAgo } from '../../lib/format'
import { cn } from '../../lib/cn'
import type { Announcement } from '../../lib/types'
import { PageHeader } from '../../components/layout/PageHeader'
import { Alert } from '../../components/ui/Alert'
import { Avatar } from '../../components/ui/Avatar'
import { Button } from '../../components/ui/Button'
import { ConfirmDialog } from '../../components/ui/ConfirmDialog'
import { EmptyState } from '../../components/ui/EmptyState'
import { TextAreaField, TextField } from '../../components/ui/Field'
import { Modal } from '../../components/ui/Modal'
import { SkeletonCard } from '../../components/ui/Spinner'

export function AnnouncementsPage() {
  const group = useCurrentGroup()
  const { isAdmin } = useGroup()
  const [items, setItems] = useState<Announcement[] | null>(null)
  const [error, setError] = useState<string | null>(null)
  const [creating, setCreating] = useState(false)
  const canPost = isAdmin || group.members_can_announce

  const load = useCallback(async () => {
    const { data, error: err } = await supabase
      .from('announcements')
      .select('*')
      .eq('group_id', group.id)
      .order('is_pinned', { ascending: false })
      .order('created_at', { ascending: false })
      .limit(100)
    if (err) setError(friendlyError(err))
    else {
      setError(null)
      setItems((data ?? []) as Announcement[])
    }
  }, [group.id])

  useEffect(() => {
    void load()
  }, [load])

  // Keep the list fresh when someone posts or pins.
  useEffect(() => {
    const channel = supabase
      .channel(`announcements:${group.id}`)
      .on('postgres_changes', { event: '*', schema: 'public', table: 'announcements', filter: `group_id=eq.${group.id}` }, () => void load())
      .subscribe()
    return () => {
      void supabase.removeChannel(channel)
    }
  }, [group.id, load])

  const pinned = (items ?? []).filter((a) => a.is_pinned)
  const others = (items ?? []).filter((a) => !a.is_pinned)

  return (
    <div>
      <PageHeader
        title="Announcements"
        subtitle="Important updates for the whole group."
        action={
          canPost && (
            <Button icon={<Plus className="size-4" />} onClick={() => setCreating(true)}>
              <span className="hidden sm:inline">New announcement</span>
              <span className="sm:hidden">New</span>
            </Button>
          )
        }
      />

      {error && (
        <Alert className="mb-4" action={<Button size="sm" variant="secondary" onClick={() => void load()}>Retry</Button>}>
          {error}
        </Alert>
      )}

      {items === null && !error ? (
        <div className="space-y-4">
          <SkeletonCard lines={3} />
        </div>
      ) : items && items.length === 0 ? (
        <EmptyState
          icon={Megaphone}
          title="No announcements"
          action={
            canPost && (
              <Button icon={<Plus className="size-4" />} onClick={() => setCreating(true)}>
                Post an announcement
              </Button>
            )
          }
        >
          {canPost ? 'Share news everyone should see. Admins can pin it to the top.' : 'Admins will post important updates here.'}
        </EmptyState>
      ) : (
        <div className="space-y-4">
          {pinned.map((a) => (
            <AnnouncementCard key={a.id} item={a} onChanged={load} />
          ))}
          {pinned.length > 0 && others.length > 0 && <div className="border-t border-line" />}
          {others.map((a) => (
            <AnnouncementCard key={a.id} item={a} onChanged={load} />
          ))}
        </div>
      )}

      <Modal open={creating} onClose={() => setCreating(false)} title="New announcement">
        <NewAnnouncementForm
          onDone={() => setCreating(false)}
          onCreated={() => {
            void load()
          }}
        />
      </Modal>
    </div>
  )
}

function AnnouncementCard({ item, onChanged }: { item: Announcement; onChanged: () => Promise<void> }) {
  const me = useMe()
  const { profileOf, isAdmin } = useGroup()
  const toast = useToast()
  const [pinning, setPinning] = useState(false)
  const [confirmDelete, setConfirmDelete] = useState(false)
  const author = profileOf(item.author_id)
  const canDelete = item.author_id === me.id || isAdmin

  const togglePin = async () => {
    setPinning(true)
    const { error } = await supabase.rpc('set_announcement_pinned', { p_announcement_id: item.id, p_pinned: !item.is_pinned })
    setPinning(false)
    if (error) {
      toast(friendlyError(error), 'error')
      return
    }
    toast(item.is_pinned ? 'Unpinned' : 'Pinned to the top')
    await onChanged()
  }

  const remove = async () => {
    const { error } = await supabase.from('announcements').delete().eq('id', item.id)
    if (error) throw error
    toast('Announcement deleted')
    await onChanged()
  }

  return (
    <article
      className={cn('card p-5', item.is_pinned && 'border-brand-500/40 bg-gradient-to-br from-brand-600/12 to-surface')}
      aria-labelledby={`ann-${item.id}`}
    >
      {item.is_pinned && (
        <p className="mb-2 inline-flex items-center gap-1.5 text-xs font-semibold text-brand-300">
          <Pin className="size-3.5" aria-hidden /> Pinned
        </p>
      )}
      <h2 id={`ann-${item.id}`} className="text-lg font-semibold">
        {item.title}
      </h2>
      <p className="mt-2 text-[15px] break-words whitespace-pre-wrap text-ink/90">{item.body}</p>
      <footer className="mt-4 flex items-center gap-3">
        <Avatar profile={author} size="sm" />
        <p className="min-w-0 flex-1 text-xs text-muted">
          <span className="font-medium text-ink">{author?.display_name ?? 'Former member'}</span> ·{' '}
          <time dateTime={item.created_at} title={formatDateTime(item.created_at)}>
            {timeAgo(item.created_at)}
          </time>
        </p>
        {isAdmin && (
          <Button
            size="sm"
            variant="ghost"
            loading={pinning}
            icon={item.is_pinned ? <PinOff className="size-4" /> : <Pin className="size-4" />}
            onClick={() => void togglePin()}
          >
            {item.is_pinned ? 'Unpin' : 'Pin'}
          </Button>
        )}
        {canDelete && (
          <button onClick={() => setConfirmDelete(true)} className="icon-btn size-9" aria-label="Delete announcement">
            <Trash2 className="size-4" />
          </button>
        )}
      </footer>
      <ConfirmDialog open={confirmDelete} onClose={() => setConfirmDelete(false)} title="Delete this announcement?" confirmLabel="Delete" onConfirm={remove}>
        It will be removed for everyone in the group.
      </ConfirmDialog>
    </article>
  )
}

function NewAnnouncementForm({ onDone, onCreated }: { onDone: () => void; onCreated: () => void }) {
  const me = useMe()
  const group = useCurrentGroup()
  const { isAdmin } = useGroup()
  const toast = useToast()
  const [title, setTitle] = useState('')
  const [body, setBody] = useState('')
  const [pin, setPin] = useState(false)
  const [errors, setErrors] = useState<{ title?: string; body?: string }>({})
  const [formError, setFormError] = useState<string | null>(null)
  const [busy, setBusy] = useState(false)

  const submit = async (e: FormEvent) => {
    e.preventDefault()
    const next: typeof errors = {}
    if (!title.trim()) next.title = 'Add a title.'
    if (!body.trim()) next.body = 'Write the announcement.'
    setErrors(next)
    if (Object.keys(next).length) return
    setBusy(true)
    setFormError(null)
    const { error } = await supabase.from('announcements').insert({
      group_id: group.id,
      author_id: me.id,
      title: title.trim(),
      body: body.trim(),
      is_pinned: isAdmin && pin,
    })
    setBusy(false)
    if (error) {
      setFormError(friendlyError(error))
      return
    }
    toast('Announcement posted')
    onCreated()
    onDone()
  }

  return (
    <form onSubmit={submit} className="space-y-4" noValidate>
      {formError && <Alert>{formError}</Alert>}
      <TextField label="Title" maxLength={120} value={title} error={errors.title} onChange={(e) => setTitle(e.target.value)} autoFocus />
      <TextAreaField label="Message" rows={5} maxLength={5000} value={body} error={errors.body} onChange={(e) => setBody(e.target.value)} />
      {isAdmin && (
        <label className="flex cursor-pointer items-center gap-3">
          <input type="checkbox" className="size-5 accent-brand-500" checked={pin} onChange={(e) => setPin(e.target.checked)} />
          <span className="text-sm font-medium">Pin to the top</span>
        </label>
      )}
      <div className="flex flex-col-reverse gap-2 sm:flex-row sm:justify-end">
        <Button variant="secondary" onClick={onDone} disabled={busy}>
          Cancel
        </Button>
        <Button type="submit" loading={busy}>
          Post
        </Button>
      </div>
    </form>
  )
}
