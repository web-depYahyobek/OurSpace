import { LogoMark } from '../components/layout/Logo'

/** Shown when the Supabase env vars are missing, instead of pretending the backend works. */
export function SetupNeeded() {
  return (
    <main className="mx-auto flex min-h-dvh max-w-xl flex-col justify-center px-6 py-16">
      <LogoMark className="mb-6 size-14" />
      <h1 className="text-3xl font-bold tracking-tight">Connect OurSpace to Supabase</h1>
      <p className="mt-3 text-muted">
        The app needs two public values from your Supabase project before it can sign people in or store anything.
      </p>
      <ol className="mt-8 space-y-4 text-sm">
        <li className="card p-4">
          <p className="font-semibold">1. Create <code className="text-brand-300">.env.local</code> in the project root</p>
          <pre className="mt-3 overflow-x-auto rounded-lg bg-bg p-3 text-xs text-brand-300">
{`VITE_SUPABASE_URL=https://your-project-ref.supabase.co
VITE_SUPABASE_ANON_KEY=your-anon-or-publishable-key`}
          </pre>
          <p className="mt-2 text-muted">Find both in Supabase under Project Settings → API. Never use the service_role key here.</p>
        </li>
        <li className="card p-4">
          <p className="font-semibold">2. Run the SQL in <code className="text-brand-300">supabase/migrations</code></p>
          <p className="mt-1 text-muted">In file-name order, in the SQL editor or with <code>supabase db push</code>.</p>
        </li>
        <li className="card p-4">
          <p className="font-semibold">3. Restart the dev server</p>
          <p className="mt-1 text-muted">Vite reads env files at start-up: stop it and run <code>npm run dev</code> again.</p>
        </li>
      </ol>
    </main>
  )
}
