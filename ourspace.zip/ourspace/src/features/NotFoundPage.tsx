import { Link } from 'react-router-dom'
import { LogoMark } from '../components/layout/Logo'

export function NotFoundPage() {
  return (
    <main className="mx-auto flex min-h-dvh max-w-md flex-col items-center justify-center px-6 text-center">
      <LogoMark className="mb-6 size-14" />
      <h1 className="text-2xl font-bold">Page not found</h1>
      <p className="mt-2 text-muted">This page does not exist, or the link is out of date.</p>
      <Link to="/" className="btn btn-primary mt-6">
        Go home
      </Link>
    </main>
  )
}
