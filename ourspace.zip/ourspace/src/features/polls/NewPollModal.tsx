import { useState, type FormEvent } from 'react'
import { Plus, X } from 'lucide-react'
import { useCurrentGroup } from '../../contexts/GroupContext'
import { useToast } from '../../contexts/ToastContext'
import { supabase } from '../../lib/supabase'
import { friendlyError } from '../../lib/errors'
import { toLocalInputValue } from '../../lib/format'
import { Alert } from '../../components/ui/Alert'
import { Button } from '../../components/ui/Button'
import { TextField } from '../../components/ui/Field'
import { Modal } from '../../components/ui/Modal'

const MAX_OPTIONS = 10

export function NewPollModal({ open, onClose, onCreated }: { open: boolean; onClose: () => void; onCreated: (id: string) => void }) {
  return (
    <Modal open={open} onClose={onClose} title="New poll">
      <NewPollForm onDone={onClose} onCreated={onCreated} />
    </Modal>
  )
}

function NewPollForm({ onDone, onCreated }: { onDone: () => void; onCreated: (id: string) => void }) {
  const group = useCurrentGroup()
  const toast = useToast()
  const [question, setQuestion] = useState('')
  const [options, setOptions] = useState(['', ''])
  const [hasDeadline, setHasDeadline] = useState(false)
  const [endsAt, setEndsAt] = useState(() => toLocalInputValue(new Date(Date.now() + 24 * 3600_000)))
  const [publicResults, setPublicResults] = useState(false)
  const [errors, setErrors] = useState<{ question?: string; options?: string; endsAt?: string }>({})
  const [formError, setFormError] = useState<string | null>(null)
  const [busy, setBusy] = useState(false)

  const submit = async (e: FormEvent) => {
    e.preventDefault()
    const filled = options.map((o) => o.trim()).filter(Boolean)
    const distinct = new Set(filled.map((o) => o.toLowerCase()))
    const next: typeof errors = {}
    if (!question.trim()) next.question = 'Write a question.'
    if (distinct.size < 2) next.options = 'Add at least two different options.'
    else if (distinct.size !== filled.length) next.options = 'Each option must be different.'
    if (hasDeadline && (!endsAt || new Date(endsAt) <= new Date())) next.endsAt = 'Pick a time in the future.'
    setErrors(next)
    if (Object.keys(next).length) return

    setBusy(true)
    setFormError(null)
    const { data, error } = await supabase.rpc('create_poll', {
      p_group_id: group.id,
      p_question: question.trim(),
      p_options: filled,
      p_ends_at: hasDeadline ? new Date(endsAt).toISOString() : null,
      p_show_results_before_vote: publicResults,
    })
    setBusy(false)
    if (error) {
      setFormError(friendlyError(error))
      return
    }
    onCreated(data as string)
    toast('Poll created')
    onDone()
  }

  return (
    <form onSubmit={submit} className="space-y-5" noValidate>
      {formError && <Alert>{formError}</Alert>}
      <TextField
        label="Question"
        placeholder="What movie tonight?"
        maxLength={200}
        value={question}
        error={errors.question}
        onChange={(e) => setQuestion(e.target.value)}
        autoFocus
      />

      <fieldset>
        <legend className="label">Options</legend>
        <div className="space-y-2">
          {options.map((o, i) => (
            <div key={i} className="flex items-center gap-2">
              <input
                className="input"
                aria-label={`Option ${i + 1}`}
                placeholder={`Option ${i + 1}`}
                maxLength={100}
                value={o}
                aria-invalid={errors.options ? true : undefined}
                onChange={(e) => setOptions((prev) => prev.map((x, j) => (j === i ? e.target.value : x)))}
              />
              {options.length > 2 && (
                <button
                  type="button"
                  className="icon-btn shrink-0"
                  aria-label={`Remove option ${i + 1}`}
                  onClick={() => setOptions((prev) => prev.filter((_, j) => j !== i))}
                >
                  <X className="size-5" />
                </button>
              )}
            </div>
          ))}
        </div>
        {errors.options && <p className="mt-1.5 text-sm text-danger">{errors.options}</p>}
        {options.length < MAX_OPTIONS && (
          <Button size="sm" variant="ghost" className="mt-2" icon={<Plus className="size-4" />} onClick={() => setOptions((p) => [...p, ''])}>
            Add option
          </Button>
        )}
      </fieldset>

      <div className="space-y-3 rounded-xl border border-line bg-surface-2 p-4">
        <label className="flex cursor-pointer items-center gap-3">
          <input type="checkbox" className="size-5 accent-brand-500" checked={hasDeadline} onChange={(e) => setHasDeadline(e.target.checked)} />
          <span className="text-sm font-medium">Close automatically</span>
        </label>
        {hasDeadline && (
          <TextField
            label="Closes at"
            type="datetime-local"
            value={endsAt}
            min={toLocalInputValue(new Date())}
            error={errors.endsAt}
            onChange={(e) => setEndsAt(e.target.value)}
          />
        )}
        <label className="flex cursor-pointer items-start gap-3">
          <input type="checkbox" className="mt-0.5 size-5 accent-brand-500" checked={publicResults} onChange={(e) => setPublicResults(e.target.checked)} />
          <span>
            <span className="block text-sm font-medium">Show results before voting</span>
            <span className="block text-xs text-muted">Off: people see results only after they vote or when the poll closes.</span>
          </span>
        </label>
      </div>

      <div className="flex flex-col-reverse gap-2 sm:flex-row sm:justify-end">
        <Button variant="secondary" onClick={onDone} disabled={busy}>
          Cancel
        </Button>
        <Button type="submit" loading={busy}>
          Create poll
        </Button>
      </div>
    </form>
  )
}
