import { useCallback, useEffect, useState } from 'react'
import { Plus, Vote } from 'lucide-react'
import { useCurrentGroup } from '../../contexts/GroupContext'
import { supabase } from '../../lib/supabase'
import { friendlyError } from '../../lib/errors'
import type { PollWithDetails } from '../../lib/types'
import { PageHeader } from '../../components/layout/PageHeader'
import { Alert } from '../../components/ui/Alert'
import { Button } from '../../components/ui/Button'
import { EmptyState } from '../../components/ui/EmptyState'
import { SkeletonCard } from '../../components/ui/Spinner'
import { NewPollModal } from './NewPollModal'
import { PollCard, isPollOpen } from './PollCard'

const POLL_SELECT = '*, poll_options(*), poll_votes(id, poll_id, option_id, user_id)'

export function PollsPage() {
  const group = useCurrentGroup()
  const [polls, setPolls] = useState<PollWithDetails[] | null>(null)
  const [error, setError] = useState<string | null>(null)
  const [creating, setCreating] = useState(false)

  const load = useCallback(async () => {
    const { data, error: err } = await supabase
      .from('polls')
      .select(POLL_SELECT)
      .eq('group_id', group.id)
      .order('created_at', { ascending: false })
      .limit(50)
    if (err) setError(friendlyError(err))
    else {
      setError(null)
      setPolls((data ?? []) as PollWithDetails[])
    }
  }, [group.id])

  const reloadOne = useCallback(async (pollId: string) => {
    const { data } = await supabase.from('polls').select(POLL_SELECT).eq('id', pollId).maybeSingle()
    setPolls((prev) => {
      if (!prev) return prev
      if (!data) return prev.filter((p) => p.id !== pollId)
      const next = data as PollWithDetails
      return prev.some((p) => p.id === pollId) ? prev.map((p) => (p.id === pollId ? next : p)) : [next, ...prev]
    })
  }, [])

  useEffect(() => {
    void load()
  }, [load])

  // Live vote counts. RLS decides which vote rows each member receives.
  useEffect(() => {
    const channel = supabase
      .channel(`polls:${group.id}`)
      .on('postgres_changes', { event: '*', schema: 'public', table: 'poll_votes' }, (payload) => {
        const row = (payload.new as { poll_id?: string }) ?? {}
        if (row.poll_id) void reloadOne(row.poll_id)
      })
      .subscribe()
    return () => {
      void supabase.removeChannel(channel)
    }
  }, [group.id, reloadOne])

  const open = (polls ?? []).filter(isPollOpen)
  const closed = (polls ?? []).filter((p) => !isPollOpen(p))

  return (
    <div>
      <PageHeader
        title="Polls"
        subtitle="Make group decisions quickly."
        action={
          <Button icon={<Plus className="size-4" />} onClick={() => setCreating(true)}>
            New poll
          </Button>
        }
      />

      {error && (
        <Alert className="mb-4" action={<Button size="sm" variant="secondary" onClick={() => void load()}>Retry</Button>}>
          {error}
        </Alert>
      )}

      {polls === null && !error ? (
        <div className="space-y-4">
          <SkeletonCard lines={3} />
          <SkeletonCard lines={2} />
        </div>
      ) : polls && polls.length === 0 ? (
        <EmptyState
          icon={Vote}
          title="No polls yet"
          action={
            <Button icon={<Plus className="size-4" />} onClick={() => setCreating(true)}>
              Ask the group
            </Button>
          }
        >
          Movie night? Pizza or sushi? Start a poll and let everyone vote.
        </EmptyState>
      ) : (
        <div className="space-y-8">
          {open.length > 0 && (
            <section aria-labelledby="open-polls" className="space-y-4">
              <h2 id="open-polls" className="text-sm font-semibold tracking-wide text-muted uppercase">
                Open
              </h2>
              {open.map((p) => (
                <PollCard key={p.id} poll={p} onChanged={() => void reloadOne(p.id)} onDeleted={() => setPolls((prev) => prev?.filter((x) => x.id !== p.id) ?? null)} />
              ))}
            </section>
          )}
          {closed.length > 0 && (
            <section aria-labelledby="closed-polls" className="space-y-4">
              <h2 id="closed-polls" className="text-sm font-semibold tracking-wide text-muted uppercase">
                Closed
              </h2>
              {closed.map((p) => (
                <PollCard key={p.id} poll={p} onChanged={() => void reloadOne(p.id)} onDeleted={() => setPolls((prev) => prev?.filter((x) => x.id !== p.id) ?? null)} />
              ))}
            </section>
          )}
        </div>
      )}

      <NewPollModal open={creating} onClose={() => setCreating(false)} onCreated={(id) => void reloadOne(id)} />
    </div>
  )
}
