import { useState } from 'react'
import { Check, Clock, Eye, Lock, Trash2 } from 'lucide-react'
import { useMe } from '../../contexts/AuthContext'
import { useGroup } from '../../contexts/GroupContext'
import { useToast } from '../../contexts/ToastContext'
import { supabase } from '../../lib/supabase'
import { friendlyError } from '../../lib/errors'
import { plural, timeAgo, timeUntil } from '../../lib/format'
import { cn } from '../../lib/cn'
import type { PollWithDetails } from '../../lib/types'
import { Avatar } from '../../components/ui/Avatar'
import { Button } from '../../components/ui/Button'
import { ConfirmDialog } from '../../components/ui/ConfirmDialog'

export function isPollOpen(p: PollWithDetails) {
  return !p.is_closed && (!p.ends_at || new Date(p.ends_at) > new Date())
}

export function PollCard({ poll, onChanged, onDeleted }: { poll: PollWithDetails; onChanged: () => void; onDeleted: () => void }) {
  const me = useMe()
  const { profileOf, isAdmin } = useGroup()
  const toast = useToast()
  const [choice, setChoice] = useState<string | null>(null)
  const [changing, setChanging] = useState(false)
  const [busy, setBusy] = useState(false)
  const [confirm, setConfirm] = useState<'close' | 'delete' | null>(null)

  const open = isPollOpen(poll)
  const myVote = poll.poll_votes.find((v) => v.user_id === me.id) ?? null
  const resultsVisible = poll.show_results_before_vote || !open || !!myVote
  const showForm = open && (!myVote || changing)
  const options = [...poll.poll_options].sort((a, b) => a.position - b.position)
  const total = poll.poll_votes.length
  const creator = profileOf(poll.creator_id)
  const canManage = poll.creator_id === me.id || isAdmin
  const maxVotes = Math.max(0, ...options.map((o) => poll.poll_votes.filter((v) => v.option_id === o.id).length))

  const vote = async () => {
    if (!choice) return
    setBusy(true)
    const { error } = await supabase.rpc('cast_vote', { p_poll_id: poll.id, p_option_id: choice })
    setBusy(false)
    if (error) {
      toast(friendlyError(error), 'error')
      return
    }
    setChanging(false)
    setChoice(null)
    onChanged()
  }

  const closePoll = async () => {
    const { error } = await supabase.from('polls').update({ is_closed: true }).eq('id', poll.id)
    if (error) throw error
    toast('Poll closed')
    onChanged()
  }

  const deletePoll = async () => {
    const { error } = await supabase.from('polls').delete().eq('id', poll.id)
    if (error) throw error
    toast('Poll deleted')
    onDeleted()
  }

  return (
    <article className="card p-5" aria-labelledby={`poll-${poll.id}`}>
      <header className="mb-4 flex items-start gap-3">
        <Avatar profile={creator} size="sm" />
        <div className="min-w-0 flex-1">
          <h3 id={`poll-${poll.id}`} className="text-lg leading-snug font-semibold">
            {poll.question}
          </h3>
          <p className="mt-0.5 text-xs text-muted">
            {creator?.display_name ?? 'Former member'} · {timeAgo(poll.created_at)}
          </p>
        </div>
        {open ? (
          <span className="chip border-success/30 bg-success/10 text-green-300">
            <Clock className="size-3" aria-hidden />
            {poll.ends_at ? `Ends ${timeUntil(poll.ends_at)}` : 'Open'}
          </span>
        ) : (
          <span className="chip">
            <Lock className="size-3" aria-hidden /> Closed
          </span>
        )}
      </header>

      {showForm ? (
        <fieldset>
          <legend className="sr-only">Choose one option</legend>
          <div className="space-y-2">
            {options.map((o) => {
              const selected = (choice ?? (changing ? myVote?.option_id : null)) === o.id
              return (
                <label
                  key={o.id}
                  className={cn(
                    'flex min-h-12 cursor-pointer items-center gap-3 rounded-xl border px-4 py-2.5 transition-colors has-[:focus-visible]:ring-2 has-[:focus-visible]:ring-brand-400',
                    selected ? 'border-brand-500 bg-brand-600/15' : 'border-line bg-surface-2 hover:border-line-strong',
                  )}
                >
                  <input type="radio" name={`poll-${poll.id}`} value={o.id} checked={selected} onChange={() => setChoice(o.id)} className="sr-only" />
                  <span
                    className={cn(
                      'flex size-5 shrink-0 items-center justify-center rounded-full border-2',
                      selected ? 'border-brand-400 bg-brand-500' : 'border-line-strong',
                    )}
                    aria-hidden
                  >
                    {selected && <span className="size-2 rounded-full bg-white" />}
                  </span>
                  <span className="font-medium">{o.option_text}</span>
                </label>
              )
            })}
          </div>
          <div className="mt-4 flex flex-wrap items-center gap-2">
            <Button onClick={() => void vote()} loading={busy} disabled={!choice || choice === myVote?.option_id}>
              {myVote ? 'Update vote' : 'Vote'}
            </Button>
            {changing && (
              <Button variant="ghost" onClick={() => { setChanging(false); setChoice(null) }}>
                Cancel
              </Button>
            )}
            {!resultsVisible && (
              <span className="flex items-center gap-1.5 text-xs text-faint">
                <Eye className="size-3.5" aria-hidden /> Results appear after you vote
              </span>
            )}
          </div>
        </fieldset>
      ) : (
        <ul className="space-y-2.5">
          {options.map((o) => {
            const votes = poll.poll_votes.filter((v) => v.option_id === o.id)
            const pct = total ? Math.round((votes.length / total) * 100) : 0
            const mine = myVote?.option_id === o.id
            const leading = !open && votes.length > 0 && votes.length === maxVotes
            return (
              <li key={o.id}>
                <div className="relative overflow-hidden rounded-xl border border-line bg-surface-2">
                  <div
                    className={cn('absolute inset-y-0 left-0 transition-[width] duration-500', mine || leading ? 'bg-brand-600/35' : 'bg-surface-3')}
                    style={{ width: `${pct}%` }}
                    aria-hidden
                  />
                  <div className="relative flex min-h-12 items-center gap-3 px-4 py-2.5">
                    <span className="flex-1 font-medium">
                      {o.option_text}
                      {mine && (
                        <span className="ml-2 inline-flex items-center gap-1 text-xs text-brand-300">
                          <Check className="size-3.5" aria-hidden /> your vote
                        </span>
                      )}
                    </span>
                    <span className="flex -space-x-1.5" aria-hidden>
                      {votes.slice(0, 3).map((v) => (
                        <Avatar key={v.id} profile={profileOf(v.user_id)} size="xs" className="ring-2 ring-surface-2" />
                      ))}
                    </span>
                    <span className="shrink-0 text-right text-sm whitespace-nowrap tabular-nums text-muted">
                      {votes.length}<span className="hidden sm:inline"> {votes.length === 1 ? 'vote' : 'votes'}</span> · <span className="font-semibold text-ink">{pct}%</span>
                    </span>
                  </div>
                </div>
              </li>
            )
          })}
        </ul>
      )}

      <footer className="mt-4 flex flex-wrap items-center gap-2 border-t border-line pt-3 text-sm">
        <span className="flex-1 text-muted">{resultsVisible ? plural(total, 'vote') : 'Votes hidden until you vote'}</span>
        {open && myVote && !changing && (
          <Button size="sm" variant="ghost" onClick={() => setChanging(true)}>
            Change vote
          </Button>
        )}
        {open && canManage && (
          <Button size="sm" variant="secondary" icon={<Lock className="size-3.5" />} onClick={() => setConfirm('close')}>
            Close poll
          </Button>
        )}
        {canManage && (
          <button onClick={() => setConfirm('delete')} className="icon-btn size-9" aria-label="Delete poll">
            <Trash2 className="size-4" />
          </button>
        )}
      </footer>

      <ConfirmDialog
        open={confirm === 'close'}
        onClose={() => setConfirm(null)}
        title="Close this poll?"
        confirmLabel="Close poll"
        danger={false}
        onConfirm={closePoll}
      >
        Nobody will be able to vote or change their vote, and everyone will see the final results.
      </ConfirmDialog>
      <ConfirmDialog open={confirm === 'delete'} onClose={() => setConfirm(null)} title="Delete this poll?" confirmLabel="Delete poll" onConfirm={deletePoll}>
        The poll and all its votes will be removed for everyone.
      </ConfirmDialog>
    </article>
  )
}
