import { Clock, MapPin } from 'lucide-react'
import { useMe } from '../../contexts/AuthContext'
import { useGroup } from '../../contexts/GroupContext'
import { formatTime, timeUntil } from '../../lib/format'
import { cn } from '../../lib/cn'
import type { EventWithRsvps } from '../../lib/types'
import { Avatar } from '../../components/ui/Avatar'
import { RSVP_LABELS } from './rsvp'

export function DateBadge({ iso, past = false }: { iso: string; past?: boolean }) {
  const d = new Date(iso)
  return (
    <span
      className={cn(
        'flex size-14 shrink-0 flex-col items-center justify-center rounded-2xl border',
        past ? 'border-line bg-surface-2 text-muted' : 'border-brand-500/40 bg-brand-600/15 text-ink',
      )}
      aria-hidden
    >
      <span className={cn('text-[10px] font-semibold uppercase', past ? 'text-faint' : 'text-brand-300')}>
        {d.toLocaleDateString(undefined, { month: 'short' })}
      </span>
      <span className="text-xl leading-none font-bold">{d.getDate()}</span>
    </span>
  )
}

export function EventCard({ event, past = false, onOpen }: { event: EventWithRsvps; past?: boolean; onOpen: () => void }) {
  const me = useMe()
  const { profileOf } = useGroup()
  const going = event.event_rsvps.filter((r) => r.status === 'going')
  const maybe = event.event_rsvps.filter((r) => r.status === 'maybe').length
  const mine = event.event_rsvps.find((r) => r.user_id === me.id)

  return (
    <button
      onClick={onOpen}
      className={cn('card flex w-full items-center gap-4 p-4 text-left transition-colors hover:border-line-strong hover:bg-surface-2', past && 'opacity-75')}
    >
      <DateBadge iso={event.starts_at} past={past} />
      <span className="min-w-0 flex-1">
        <span className="block truncate font-semibold">{event.title}</span>
        <span className="mt-0.5 flex flex-wrap items-center gap-x-3 gap-y-0.5 text-sm text-muted">
          <span className="inline-flex items-center gap-1">
            <Clock className="size-3.5" aria-hidden />
            {new Date(event.starts_at).toLocaleDateString(undefined, { weekday: 'short' })} {formatTime(event.starts_at)}
            {!past && <span className="text-brand-300"> · {timeUntil(event.starts_at)}</span>}
          </span>
          {event.location && (
            <span className="inline-flex min-w-0 items-center gap-1">
              <MapPin className="size-3.5 shrink-0" aria-hidden />
              <span className="truncate">{event.location}</span>
            </span>
          )}
        </span>
        <span className="mt-2 flex items-center gap-2 text-xs text-muted">
          <span className="flex -space-x-1.5" aria-hidden>
            {going.slice(0, 4).map((r) => (
              <Avatar key={r.id} profile={profileOf(r.user_id)} size="xs" className="ring-2 ring-surface" />
            ))}
          </span>
          {going.length} going{maybe > 0 && ` · ${maybe} maybe`}
        </span>
      </span>
      {mine && (
        <span className={cn('chip hidden sm:inline-flex', mine.status === 'going' && 'border-success/30 bg-success/10 text-green-300')}>
          {RSVP_LABELS[mine.status]}
        </span>
      )}
    </button>
  )
}
