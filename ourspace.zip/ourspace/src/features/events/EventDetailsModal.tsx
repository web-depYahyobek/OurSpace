import { useState } from 'react'
import { Clock, MapPin, Trash2 } from 'lucide-react'
import { useMe } from '../../contexts/AuthContext'
import { useGroup } from '../../contexts/GroupContext'
import { useToast } from '../../contexts/ToastContext'
import { supabase } from '../../lib/supabase'
import { friendlyError } from '../../lib/errors'
import { formatDateTime, formatTime, timeAgo } from '../../lib/format'
import { cn } from '../../lib/cn'
import type { EventWithRsvps, RsvpStatus } from '../../lib/types'
import { Avatar } from '../../components/ui/Avatar'
import { Button } from '../../components/ui/Button'
import { ConfirmDialog } from '../../components/ui/ConfirmDialog'
import { Modal } from '../../components/ui/Modal'
import { DateBadge } from './EventCard'
import { RSVP_LABELS, RSVP_ORDER, isUpcoming } from './rsvp'

export function EventDetailsModal({
  event,
  onClose,
  onChanged,
  onDeleted,
}: {
  event: EventWithRsvps | null
  onClose: () => void
  onChanged: (e: EventWithRsvps) => void
  onDeleted: (id: string) => void
}) {
  return (
    <Modal open={!!event} onClose={onClose} title={event?.title ?? 'Event'} size="lg">
      {event && <EventDetails event={event} onChanged={onChanged} onDeleted={onDeleted} />}
    </Modal>
  )
}

function EventDetails({
  event,
  onChanged,
  onDeleted,
}: {
  event: EventWithRsvps
  onChanged: (e: EventWithRsvps) => void
  onDeleted: (id: string) => void
}) {
  const me = useMe()
  const { profileOf, isAdmin } = useGroup()
  const toast = useToast()
  const [saving, setSaving] = useState<RsvpStatus | null>(null)
  const [confirmDelete, setConfirmDelete] = useState(false)
  const mine = event.event_rsvps.find((r) => r.user_id === me.id)
  const creator = profileOf(event.creator_id)
  const upcoming = isUpcoming(event)
  const canManage = event.creator_id === me.id || isAdmin

  const rsvp = async (status: RsvpStatus) => {
    setSaving(status)
    const { error } = await supabase.rpc('set_rsvp', { p_event_id: event.id, p_status: status })
    if (error) {
      setSaving(null)
      toast(friendlyError(error), 'error')
      return
    }
    const { data } = await supabase.from('events').select('*, event_rsvps(*)').eq('id', event.id).single()
    setSaving(null)
    if (data) onChanged(data as EventWithRsvps)
  }

  const deleteEvent = async () => {
    const { error } = await supabase.from('events').delete().eq('id', event.id)
    if (error) throw error
    toast('Event deleted')
    onDeleted(event.id)
  }

  const sameDay = event.ends_at && new Date(event.ends_at).toDateString() === new Date(event.starts_at).toDateString()

  return (
    <div className="space-y-6">
      <div className="flex items-start gap-4">
        <DateBadge iso={event.starts_at} past={!upcoming} />
        <div className="min-w-0 space-y-1.5 text-sm">
          <p className="flex items-start gap-2">
            <Clock className="mt-0.5 size-4 shrink-0 text-brand-400" aria-hidden />
            <span>
              {formatDateTime(event.starts_at)}
              {event.ends_at && <> – {sameDay ? formatTime(event.ends_at) : formatDateTime(event.ends_at)}</>}
            </span>
          </p>
          {event.location && (
            <p className="flex items-start gap-2">
              <MapPin className="mt-0.5 size-4 shrink-0 text-brand-400" aria-hidden />
              <span className="break-words">{event.location}</span>
            </p>
          )}
          <p className="text-xs text-muted">
            Planned by {creator?.display_name ?? 'a former member'} · {timeAgo(event.created_at)}
          </p>
        </div>
      </div>

      {event.description && <p className="text-[15px] break-words whitespace-pre-wrap text-ink">{event.description}</p>}

      {upcoming && (
        <fieldset>
          <legend className="label">Are you going?</legend>
          <div className="grid grid-cols-3 gap-2">
            {RSVP_ORDER.map((s) => (
              <Button
                key={s}
                variant={mine?.status === s ? 'primary' : 'secondary'}
                loading={saving === s}
                disabled={saving !== null}
                aria-pressed={mine?.status === s}
                onClick={() => void rsvp(s)}
              >
                {RSVP_LABELS[s]}
              </Button>
            ))}
          </div>
        </fieldset>
      )}

      <div className="grid gap-4 sm:grid-cols-3">
        {RSVP_ORDER.map((s) => {
          const people = event.event_rsvps.filter((r) => r.status === s)
          return (
            <section key={s} aria-label={RSVP_LABELS[s]}>
              <h3 className={cn('mb-2 text-sm font-semibold', s === 'going' ? 'text-green-300' : 'text-muted')}>
                {RSVP_LABELS[s]} · {people.length}
              </h3>
              {people.length === 0 ? (
                <p className="text-xs text-faint">Nobody yet</p>
              ) : (
                <ul className="space-y-2">
                  {people.map((r) => {
                    const p = profileOf(r.user_id)
                    return (
                      <li key={r.id} className="flex items-center gap-2 text-sm">
                        <Avatar profile={p} size="xs" />
                        <span className="truncate">{p?.display_name ?? 'Former member'}</span>
                      </li>
                    )
                  })}
                </ul>
              )}
            </section>
          )
        })}
      </div>

      {canManage && (
        <div className="border-t border-line pt-4">
          <Button variant="danger" size="sm" icon={<Trash2 className="size-4" />} onClick={() => setConfirmDelete(true)}>
            Delete event
          </Button>
        </div>
      )}

      <ConfirmDialog open={confirmDelete} onClose={() => setConfirmDelete(false)} title="Delete this event?" confirmLabel="Delete event" onConfirm={deleteEvent}>
        The event and everyone's RSVPs will be removed.
      </ConfirmDialog>
    </div>
  )
}
