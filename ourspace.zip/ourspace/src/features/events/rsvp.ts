import type { GroupEvent, RsvpStatus } from '../../lib/types'

export const RSVP_LABELS: Record<RsvpStatus, string> = {
  going: 'Going',
  maybe: 'Maybe',
  not_going: "Can't go",
}

export const RSVP_ORDER: RsvpStatus[] = ['going', 'maybe', 'not_going']

/** An event counts as upcoming until it ends (or 3 hours after it starts if no end time). */
export function isUpcoming(e: GroupEvent, now = Date.now()) {
  const end = e.ends_at ? new Date(e.ends_at).getTime() : new Date(e.starts_at).getTime() + 3 * 3600_000
  return end >= now
}
