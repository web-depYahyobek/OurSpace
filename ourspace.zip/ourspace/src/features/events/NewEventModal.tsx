import { useState, type FormEvent } from 'react'
import { useMe } from '../../contexts/AuthContext'
import { useCurrentGroup } from '../../contexts/GroupContext'
import { useToast } from '../../contexts/ToastContext'
import { supabase } from '../../lib/supabase'
import { friendlyError } from '../../lib/errors'
import { toLocalInputValue } from '../../lib/format'
import type { EventWithRsvps } from '../../lib/types'
import { Alert } from '../../components/ui/Alert'
import { Button } from '../../components/ui/Button'
import { TextAreaField, TextField } from '../../components/ui/Field'
import { Modal } from '../../components/ui/Modal'

export function NewEventModal({ open, onClose, onCreated }: { open: boolean; onClose: () => void; onCreated: (e: EventWithRsvps) => void }) {
  return (
    <Modal open={open} onClose={onClose} title="New event">
      <NewEventForm onDone={onClose} onCreated={onCreated} />
    </Modal>
  )
}

function defaultStart() {
  const d = new Date(Date.now() + 24 * 3600_000)
  d.setHours(19, 0, 0, 0)
  return toLocalInputValue(d)
}

function NewEventForm({ onDone, onCreated }: { onDone: () => void; onCreated: (e: EventWithRsvps) => void }) {
  const me = useMe()
  const group = useCurrentGroup()
  const toast = useToast()
  const initial = defaultStart()
  const [title, setTitle] = useState('')
  const [date, setDate] = useState(initial.slice(0, 10))
  const [time, setTime] = useState(initial.slice(11, 16))
  const [endTime, setEndTime] = useState('')
  const [location, setLocation] = useState('')
  const [description, setDescription] = useState('')
  const [errors, setErrors] = useState<{ title?: string; date?: string; endTime?: string }>({})
  const [formError, setFormError] = useState<string | null>(null)
  const [busy, setBusy] = useState(false)

  const submit = async (e: FormEvent) => {
    e.preventDefault()
    const start = new Date(`${date}T${time}`)
    let end: Date | null = endTime ? new Date(`${date}T${endTime}`) : null
    // An end time earlier than the start means it finishes after midnight.
    if (end && end <= start) end = new Date(end.getTime() + 24 * 3600_000)

    const next: typeof errors = {}
    if (!title.trim()) next.title = 'Give the event a title.'
    if (!date || !time || Number.isNaN(start.getTime())) next.date = 'Pick a date and start time.'
    setErrors(next)
    if (Object.keys(next).length) return

    setBusy(true)
    setFormError(null)
    const { data, error } = await supabase
      .from('events')
      .insert({
        group_id: group.id,
        creator_id: me.id,
        title: title.trim(),
        description: description.trim() || null,
        location: location.trim() || null,
        starts_at: start.toISOString(),
        ends_at: end ? end.toISOString() : null,
      })
      .select('*, event_rsvps(*)')
      .single()
    if (error) {
      setBusy(false)
      setFormError(friendlyError(error))
      return
    }
    // The organiser is going by default.
    await supabase.rpc('set_rsvp', { p_event_id: (data as EventWithRsvps).id, p_status: 'going' })
    const { data: fresh } = await supabase.from('events').select('*, event_rsvps(*)').eq('id', (data as EventWithRsvps).id).single()
    onCreated((fresh ?? data) as EventWithRsvps)
    toast('Event created')
    onDone()
  }

  return (
    <form onSubmit={submit} className="space-y-4" noValidate>
      {formError && <Alert>{formError}</Alert>}
      <TextField label="Title" placeholder="Group movie night" maxLength={100} value={title} error={errors.title} onChange={(e) => setTitle(e.target.value)} autoFocus />
      <div className="grid grid-cols-2 gap-3">
        <TextField label="Date" type="date" value={date} error={errors.date} onChange={(e) => setDate(e.target.value)} />
        <TextField label="Starts" type="time" value={time} onChange={(e) => setTime(e.target.value)} />
      </div>
      <TextField label="Ends" type="time" optional value={endTime} error={errors.endTime} onChange={(e) => setEndTime(e.target.value)} />
      <TextField label="Location" optional placeholder="Cinema, park, someone's place…" maxLength={200} value={location} onChange={(e) => setLocation(e.target.value)} />
      <TextAreaField label="Details" optional rows={3} maxLength={2000} value={description} onChange={(e) => setDescription(e.target.value)} />
      <div className="flex flex-col-reverse gap-2 sm:flex-row sm:justify-end">
        <Button variant="secondary" onClick={onDone} disabled={busy}>
          Cancel
        </Button>
        <Button type="submit" loading={busy}>
          Create event
        </Button>
      </div>
    </form>
  )
}
