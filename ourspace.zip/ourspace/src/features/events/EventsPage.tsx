import { useCallback, useEffect, useState } from 'react'
import { useSearchParams } from 'react-router-dom'
import { CalendarDays, CalendarPlus } from 'lucide-react'
import { useCurrentGroup } from '../../contexts/GroupContext'
import { supabase } from '../../lib/supabase'
import { friendlyError } from '../../lib/errors'
import type { EventWithRsvps } from '../../lib/types'
import { PageHeader } from '../../components/layout/PageHeader'
import { Alert } from '../../components/ui/Alert'
import { Button } from '../../components/ui/Button'
import { EmptyState } from '../../components/ui/EmptyState'
import { SkeletonCard } from '../../components/ui/Spinner'
import { EventCard } from './EventCard'
import { EventDetailsModal } from './EventDetailsModal'
import { NewEventModal } from './NewEventModal'
import { isUpcoming } from './rsvp'

export function EventsPage() {
  const group = useCurrentGroup()
  const [events, setEvents] = useState<EventWithRsvps[] | null>(null)
  const [error, setError] = useState<string | null>(null)
  const [creating, setCreating] = useState(false)
  const [params, setParams] = useSearchParams()
  const openId = params.get('open')

  const load = useCallback(async () => {
    const { data, error: err } = await supabase
      .from('events')
      .select('*, event_rsvps(*)')
      .eq('group_id', group.id)
      .order('starts_at', { ascending: true })
      .limit(200)
    if (err) setError(friendlyError(err))
    else {
      setError(null)
      setEvents((data ?? []) as EventWithRsvps[])
    }
  }, [group.id])

  useEffect(() => {
    void load()
  }, [load])

  const replace = (next: EventWithRsvps) =>
    setEvents((prev) => {
      const list = prev ?? []
      const exists = list.some((e) => e.id === next.id)
      return (exists ? list.map((e) => (e.id === next.id ? next : e)) : [...list, next]).sort((a, b) =>
        a.starts_at.localeCompare(b.starts_at),
      )
    })

  const setOpen = (id: string | null) => {
    const next = new URLSearchParams(params)
    if (id) next.set('open', id)
    else next.delete('open')
    setParams(next, { replace: true })
  }

  const upcoming = (events ?? []).filter((e) => isUpcoming(e))
  const past = (events ?? []).filter((e) => !isUpcoming(e)).reverse()
  const opened = events?.find((e) => e.id === openId) ?? null

  return (
    <div>
      <PageHeader
        title="Events"
        subtitle="Plan meetups and see who's coming."
        action={
          <Button icon={<CalendarPlus className="size-4" />} onClick={() => setCreating(true)}>
            New event
          </Button>
        }
      />

      {error && (
        <Alert className="mb-4" action={<Button size="sm" variant="secondary" onClick={() => void load()}>Retry</Button>}>
          {error}
        </Alert>
      )}

      {events === null && !error ? (
        <div className="space-y-4">
          <SkeletonCard lines={2} />
          <SkeletonCard lines={2} />
        </div>
      ) : events && events.length === 0 ? (
        <EmptyState
          icon={CalendarDays}
          title="Nothing planned yet"
          action={
            <Button icon={<CalendarPlus className="size-4" />} onClick={() => setCreating(true)}>
              Plan something
            </Button>
          }
        >
          Create an event and everyone can say if they're going.
        </EmptyState>
      ) : (
        <div className="space-y-8">
          <section aria-labelledby="upcoming-heading" className="space-y-3">
            <h2 id="upcoming-heading" className="text-sm font-semibold tracking-wide text-muted uppercase">
              Upcoming
            </h2>
            {upcoming.length === 0 ? (
              <p className="card px-4 py-6 text-center text-sm text-muted">No upcoming events. Time to plan the next one?</p>
            ) : (
              upcoming.map((e) => <EventCard key={e.id} event={e} onOpen={() => setOpen(e.id)} />)
            )}
          </section>
          {past.length > 0 && (
            <section aria-labelledby="past-heading" className="space-y-3">
              <h2 id="past-heading" className="text-sm font-semibold tracking-wide text-muted uppercase">
                Past
              </h2>
              {past.map((e) => (
                <EventCard key={e.id} event={e} past onOpen={() => setOpen(e.id)} />
              ))}
            </section>
          )}
        </div>
      )}

      <EventDetailsModal
        event={opened}
        onClose={() => setOpen(null)}
        onChanged={replace}
        onDeleted={(id) => {
          setOpen(null)
          setEvents((prev) => prev?.filter((e) => e.id !== id) ?? null)
        }}
      />
      <NewEventModal
        open={creating}
        onClose={() => setCreating(false)}
        onCreated={(e) => {
          replace(e)
          setOpen(e.id)
        }}
      />
    </div>
  )
}
