import { useCallback, useEffect, useState, type FormEvent } from 'react'
import { Check, Copy, Crown, Link2, Plus, Shield, ShieldOff, UserMinus } from 'lucide-react'
import { useMe } from '../../contexts/AuthContext'
import { useCurrentGroup, useGroup } from '../../contexts/GroupContext'
import { useToast } from '../../contexts/ToastContext'
import { supabase } from '../../lib/supabase'
import { friendlyError } from '../../lib/errors'
import { formatDate, plural, timeAgo, timeUntil } from '../../lib/format'
import type { GroupInvite, GroupMember } from '../../lib/types'
import { PageHeader } from '../../components/layout/PageHeader'
import { Alert } from '../../components/ui/Alert'
import { Avatar } from '../../components/ui/Avatar'
import { Button } from '../../components/ui/Button'
import { ConfirmDialog } from '../../components/ui/ConfirmDialog'
import { TextAreaField, TextField } from '../../components/ui/Field'
import { Modal } from '../../components/ui/Modal'
import { SkeletonCard } from '../../components/ui/Spinner'

type PendingAction =
  | { kind: 'remove'; member: GroupMember }
  | { kind: 'transfer'; member: GroupMember }
  | null

export function MembersPage() {
  const me = useMe()
  const group = useCurrentGroup()
  const { members, isAdmin, isOwner, refreshMembers, refresh } = useGroup()
  const toast = useToast()
  const [pending, setPending] = useState<PendingAction>(null)
  const [busyId, setBusyId] = useState<string | null>(null)

  useEffect(() => {
    void refreshMembers()
  }, [refreshMembers])

  const setRole = async (member: GroupMember, role: 'admin' | 'member') => {
    setBusyId(member.id)
    const { error } = await supabase.from('group_members').update({ role }).eq('id', member.id)
    setBusyId(null)
    if (error) {
      toast(friendlyError(error), 'error')
      return
    }
    toast(role === 'admin' ? `${member.profile.display_name} is now an admin` : `${member.profile.display_name} is no longer an admin`)
    await refreshMembers()
  }

  const removeMember = async (member: GroupMember) => {
    const { data, error } = await supabase.from('group_members').delete().eq('id', member.id).select('id')
    if (error) throw error
    if (!data?.length) throw new Error('You do not have permission to remove this member.')
    toast(`${member.profile.display_name} was removed`)
    await refreshMembers()
  }

  const transferOwnership = async (member: GroupMember) => {
    const { error } = await supabase.rpc('transfer_ownership', { p_group_id: group.id, p_new_owner: member.user_id })
    if (error) throw error
    toast(`${member.profile.display_name} is now the owner`)
    await Promise.all([refresh(), refreshMembers()])
  }

  const canRemove = (m: GroupMember) =>
    m.user_id !== me.id && m.role !== 'owner' && (isOwner || (isAdmin && m.role === 'member'))

  return (
    <div className="space-y-6">
      <PageHeader title="Members" subtitle={`${group.name} · ${plural(members.length, 'member')}`} />

      {isAdmin && <InvitesSection groupId={group.id} />}

      <section className="card divide-y divide-line" aria-label="Member list">
        {members.length === 0 ? (
          <div className="p-4">
            <SkeletonCard lines={1} />
          </div>
        ) : (
          members.map((m) => (
            <div key={m.id} className="flex flex-wrap items-center gap-3 p-4">
              <Avatar profile={m.profile} />
              <div className="min-w-0 flex-1">
                <p className="flex items-center gap-2 font-medium">
                  <span className="truncate">{m.profile.display_name}</span>
                  {m.user_id === me.id && <span className="text-xs text-faint">(you)</span>}
                </p>
                <p className="truncate text-sm text-muted">
                  @{m.profile.username} · joined {formatDate(m.joined_at)}
                </p>
              </div>
              <RoleBadge role={m.role} />
              {(isOwner || canRemove(m)) && m.user_id !== me.id && m.role !== 'owner' && (
                <div className="flex w-full flex-wrap justify-end gap-2 sm:w-auto">
                  {isOwner && (
                    <Button
                      size="sm"
                      variant="ghost"
                      loading={busyId === m.id}
                      icon={m.role === 'admin' ? <ShieldOff className="size-4" /> : <Shield className="size-4" />}
                      onClick={() => void setRole(m, m.role === 'admin' ? 'member' : 'admin')}
                    >
                      {m.role === 'admin' ? 'Remove admin' : 'Make admin'}
                    </Button>
                  )}
                  {isOwner && (
                    <Button size="sm" variant="ghost" icon={<Crown className="size-4" />} onClick={() => setPending({ kind: 'transfer', member: m })}>
                      Make owner
                    </Button>
                  )}
                  {canRemove(m) && (
                    <Button size="sm" variant="danger" icon={<UserMinus className="size-4" />} onClick={() => setPending({ kind: 'remove', member: m })}>
                      Remove
                    </Button>
                  )}
                </div>
              )}
            </div>
          ))
        )}
      </section>

      {isAdmin && <GroupSettings />}

      <ConfirmDialog
        open={pending?.kind === 'remove'}
        onClose={() => setPending(null)}
        title={`Remove ${pending?.member.profile.display_name ?? 'member'}?`}
        confirmLabel="Remove from group"
        onConfirm={() => removeMember(pending!.member)}
      >
        They will immediately lose access to the chat, photos, polls, events and announcements. Their past posts stay. They can only come
        back with a new invite.
      </ConfirmDialog>

      <ConfirmDialog
        open={pending?.kind === 'transfer'}
        onClose={() => setPending(null)}
        title={`Make ${pending?.member.profile.display_name ?? 'this member'} the owner?`}
        confirmLabel="Transfer ownership"
        onConfirm={() => transferOwnership(pending!.member)}
      >
        There can only be one owner. You will become an admin, and only the new owner can undo this.
      </ConfirmDialog>
    </div>
  )
}

function RoleBadge({ role }: { role: GroupMember['role'] }) {
  if (role === 'owner')
    return (
      <span className="chip border-amber-400/30 bg-amber-400/10 text-amber-300">
        <Crown className="size-3" aria-hidden /> Owner
      </span>
    )
  if (role === 'admin')
    return (
      <span className="chip border-brand-500/40 bg-brand-500/10 text-brand-300">
        <Shield className="size-3" aria-hidden /> Admin
      </span>
    )
  return null
}

// ---------------------------------------------------------------------------
// Invites (owners and admins)
// ---------------------------------------------------------------------------
const EXPIRY_OPTIONS = [
  { label: '1 day', days: 1 },
  { label: '7 days', days: 7 },
  { label: '30 days', days: 30 },
  { label: 'Never', days: 0 },
]
const USE_OPTIONS = [
  { label: 'Unlimited', uses: 0 },
  { label: '1 use', uses: 1 },
  { label: '5 uses', uses: 5 },
  { label: '10 uses', uses: 10 },
  { label: '25 uses', uses: 25 },
]

function inviteLink(code: string) {
  return `${window.location.origin}/join/${code}`
}

function isActive(inv: GroupInvite) {
  return (
    !inv.revoked_at &&
    (!inv.expires_at || new Date(inv.expires_at) > new Date()) &&
    (inv.max_uses === null || inv.use_count < inv.max_uses)
  )
}

function InvitesSection({ groupId }: { groupId: string }) {
  const toast = useToast()
  const [invites, setInvites] = useState<GroupInvite[] | null>(null)
  const [error, setError] = useState<string | null>(null)
  const [creating, setCreating] = useState(false)
  const [showForm, setShowForm] = useState(false)
  const [expiryDays, setExpiryDays] = useState(7)
  const [maxUses, setMaxUses] = useState(0)
  const [copied, setCopied] = useState<string | null>(null)
  const [revoking, setRevoking] = useState<GroupInvite | null>(null)

  const load = useCallback(async () => {
    const { data, error: err } = await supabase
      .from('group_invites')
      .select('*')
      .eq('group_id', groupId)
      .order('created_at', { ascending: false })
      .limit(50)
    if (err) setError(friendlyError(err))
    else {
      setError(null)
      setInvites((data ?? []) as GroupInvite[])
    }
  }, [groupId])

  useEffect(() => {
    void load()
  }, [load])

  const create = async (e: FormEvent) => {
    e.preventDefault()
    setCreating(true)
    const expires_at = expiryDays ? new Date(Date.now() + expiryDays * 86400_000).toISOString() : null
    const { data, error: err } = await supabase
      .from('group_invites')
      .insert({ group_id: groupId, expires_at, max_uses: maxUses || null })
      .select('*')
      .single()
    setCreating(false)
    if (err) {
      toast(friendlyError(err), 'error')
      return
    }
    setShowForm(false)
    await load()
    void copy((data as GroupInvite).code)
  }

  const copy = async (code: string) => {
    try {
      await navigator.clipboard.writeText(inviteLink(code))
      setCopied(code)
      toast('Invite link copied')
      setTimeout(() => setCopied((c) => (c === code ? null : c)), 2000)
    } catch {
      toast(`Copy this link: ${inviteLink(code)}`, 'error')
    }
  }

  const revoke = async (inv: GroupInvite) => {
    const { error: err } = await supabase.from('group_invites').update({ revoked_at: new Date().toISOString() }).eq('id', inv.id)
    if (err) throw err
    toast('Invite revoked')
    await load()
  }

  const active = (invites ?? []).filter(isActive)

  return (
    <section className="card p-5" aria-labelledby="invites-heading">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div>
          <h2 id="invites-heading" className="font-semibold">
            Invite friends
          </h2>
          <p className="mt-0.5 text-sm text-muted">Only people with a valid invite can join. Revoke a link at any time.</p>
        </div>
        <Button size="sm" icon={<Plus className="size-4" />} onClick={() => setShowForm(true)}>
          New invite link
        </Button>
      </div>

      {error && <Alert className="mt-4">{error}</Alert>}

      {invites === null && !error ? (
        <div className="mt-4 h-16 animate-pulse rounded-xl bg-surface-2" />
      ) : active.length === 0 ? (
        <p className="mt-4 rounded-xl border border-dashed border-line-strong px-4 py-5 text-center text-sm text-muted">
          No active invites. Create one to bring your friends in.
        </p>
      ) : (
        <ul className="mt-4 space-y-2">
          {active.map((inv) => (
            <li key={inv.id} className="flex flex-col gap-3 rounded-xl border border-line bg-surface-2 p-3 sm:flex-row sm:items-center">
              <div className="flex min-w-0 flex-1 items-start gap-3">
                <Link2 className="mt-1 size-5 shrink-0 text-brand-400" aria-hidden />
                <div className="min-w-0">
                  <p className="font-mono text-base font-semibold tracking-widest">{inv.code}</p>
                  <p className="text-xs text-muted">
                    {inv.max_uses ? `${inv.use_count}/${inv.max_uses} used` : `${plural(inv.use_count, 'join')}`}
                    {' · '}
                    {inv.expires_at ? `expires ${timeUntil(inv.expires_at)}` : 'never expires'}
                    {' · created '}
                    {timeAgo(inv.created_at)}
                  </p>
                </div>
              </div>
              <div className="flex gap-2">
                <Button
                  size="sm"
                  variant="secondary"
                  className="flex-1 sm:flex-none"
                  icon={copied === inv.code ? <Check className="size-4" /> : <Copy className="size-4" />}
                  onClick={() => void copy(inv.code)}
                >
                  {copied === inv.code ? 'Copied' : 'Copy link'}
                </Button>
                <Button size="sm" variant="ghost" onClick={() => setRevoking(inv)}>
                  Revoke
                </Button>
              </div>
            </li>
          ))}
        </ul>
      )}

      <Modal open={showForm} onClose={() => setShowForm(false)} title="New invite link">
        <form onSubmit={create} className="space-y-5">
          <fieldset>
            <legend className="label">Expires after</legend>
            <div className="flex flex-wrap gap-2">
              {EXPIRY_OPTIONS.map((o) => (
                <Choice key={o.label} name="expiry" checked={expiryDays === o.days} onChange={() => setExpiryDays(o.days)}>
                  {o.label}
                </Choice>
              ))}
            </div>
          </fieldset>
          <fieldset>
            <legend className="label">Can be used</legend>
            <div className="flex flex-wrap gap-2">
              {USE_OPTIONS.map((o) => (
                <Choice key={o.label} name="uses" checked={maxUses === o.uses} onChange={() => setMaxUses(o.uses)}>
                  {o.label}
                </Choice>
              ))}
            </div>
          </fieldset>
          <Button type="submit" className="w-full" loading={creating}>
            Create and copy link
          </Button>
        </form>
      </Modal>

      <ConfirmDialog
        open={!!revoking}
        onClose={() => setRevoking(null)}
        title="Revoke this invite?"
        confirmLabel="Revoke invite"
        onConfirm={() => revoke(revoking!)}
      >
        Nobody will be able to join with <span className="font-mono font-semibold text-ink">{revoking?.code}</span> any more. People who
        already joined stay in the group.
      </ConfirmDialog>
    </section>
  )
}

function Choice({ name, checked, onChange, children }: { name: string; checked: boolean; onChange: () => void; children: string }) {
  return (
    <label
      className={
        'cursor-pointer rounded-xl border px-3.5 py-2 text-sm font-medium transition-colors has-[:focus-visible]:ring-2 has-[:focus-visible]:ring-brand-400 ' +
        (checked ? 'border-brand-500 bg-brand-600/20 text-ink' : 'border-line bg-surface-2 text-muted hover:text-ink')
      }
    >
      <input type="radio" name={name} checked={checked} onChange={onChange} className="sr-only" />
      {children}
    </label>
  )
}

// ---------------------------------------------------------------------------
// Group settings (owners and admins)
// ---------------------------------------------------------------------------
function GroupSettings() {
  const group = useCurrentGroup()
  const { refresh } = useGroup()
  const toast = useToast()
  const [name, setName] = useState(group.name)
  const [description, setDescription] = useState(group.description ?? '')
  const [membersCanAnnounce, setMembersCanAnnounce] = useState(group.members_can_announce)
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState<string | null>(null)

  const dirty =
    name.trim() !== group.name || (description.trim() || null) !== group.description || membersCanAnnounce !== group.members_can_announce

  const save = async (e: FormEvent) => {
    e.preventDefault()
    if (!name.trim()) {
      setError('The group needs a name.')
      return
    }
    setBusy(true)
    setError(null)
    const { error: err } = await supabase
      .from('groups')
      .update({ name: name.trim(), description: description.trim() || null, members_can_announce: membersCanAnnounce })
      .eq('id', group.id)
    setBusy(false)
    if (err) {
      setError(friendlyError(err))
      return
    }
    toast('Group settings saved')
    await refresh()
  }

  return (
    <form onSubmit={save} className="card space-y-4 p-5" aria-labelledby="settings-heading" noValidate>
      <h2 id="settings-heading" className="font-semibold">
        Group settings
      </h2>
      {error && <Alert>{error}</Alert>}
      <TextField label="Group name" value={name} maxLength={60} onChange={(e) => setName(e.target.value)} />
      <TextAreaField
        label="Description"
        optional
        rows={2}
        className="min-h-16"
        maxLength={280}
        value={description}
        onChange={(e) => setDescription(e.target.value)}
      />
      <label className="flex cursor-pointer items-start gap-3 rounded-xl border border-line bg-surface-2 p-3.5">
        <input
          type="checkbox"
          checked={membersCanAnnounce}
          onChange={(e) => setMembersCanAnnounce(e.target.checked)}
          className="mt-0.5 size-5 accent-brand-500"
        />
        <span>
          <span className="block text-sm font-medium">Everyone can post announcements</span>
          <span className="block text-xs text-muted">When off, only the owner and admins can. Pinning is always admins only.</span>
        </span>
      </label>
      <div className="flex justify-end">
        <Button type="submit" loading={busy} disabled={!dirty}>
          Save settings
        </Button>
      </div>
    </form>
  )
}
