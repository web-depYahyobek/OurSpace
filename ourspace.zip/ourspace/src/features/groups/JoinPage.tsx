import { useEffect, useState } from 'react'
import { Link, useNavigate, useParams } from 'react-router-dom'
import { Lock, Users } from 'lucide-react'
import { useGroup } from '../../contexts/GroupContext'
import { useToast } from '../../contexts/ToastContext'
import { supabase } from '../../lib/supabase'
import { friendlyError } from '../../lib/errors'
import { plural } from '../../lib/format'
import type { InvitePreview } from '../../lib/types'
import { LogoMark } from '../../components/layout/Logo'
import { Alert } from '../../components/ui/Alert'
import { Button } from '../../components/ui/Button'
import { PageLoader } from '../../components/ui/Spinner'

export function JoinPage() {
  const { code = '' } = useParams()
  const navigate = useNavigate()
  const toast = useToast()
  const { refresh, selectGroup, memberships } = useGroup()
  const [preview, setPreview] = useState<InvitePreview | null>(null)
  const [state, setState] = useState<'loading' | 'ready' | 'invalid' | 'error'>('loading')
  const [error, setError] = useState<string | null>(null)
  const [joining, setJoining] = useState(false)

  useEffect(() => {
    let active = true
    setState('loading')
    supabase.rpc('preview_invite', { p_code: code }).then(({ data, error: err }) => {
      if (!active) return
      if (err) {
        setError(friendlyError(err))
        setState('error')
        return
      }
      const row = ((data ?? []) as InvitePreview[])[0]
      if (!row) {
        setState('invalid')
        return
      }
      setPreview(row)
      setState('ready')
    })
    return () => {
      active = false
    }
  }, [code])

  const join = async () => {
    setJoining(true)
    setError(null)
    const { data, error: err } = await supabase.rpc('join_group', { p_code: code })
    if (err) {
      setError(friendlyError(err))
      setJoining(false)
      return
    }
    await refresh()
    selectGroup(data as string)
    toast(`Welcome to ${preview?.group_name ?? 'the group'}!`)
    navigate('/', { replace: true })
  }

  const goToGroup = () => {
    if (!preview) return
    selectGroup(preview.group_id)
    navigate('/', { replace: true })
  }

  if (state === 'loading') return <PageLoader label="Checking invite" />

  return (
    <main className="mx-auto flex min-h-dvh max-w-md flex-col justify-center px-5 py-10">
      <div className="card animate-rise p-7 text-center">
        <LogoMark className="mx-auto size-16" />
        {state === 'ready' && preview ? (
          <>
            <p className="mt-6 text-sm font-medium text-brand-400">You're invited to join</p>
            <h1 className="mt-1 text-2xl font-bold tracking-tight">{preview.group_name}</h1>
            {preview.group_description && <p className="mt-2 text-sm text-muted">{preview.group_description}</p>}
            <p className="mt-4 inline-flex items-center gap-2 text-sm text-muted">
              <Users className="size-4" aria-hidden /> {plural(Number(preview.member_count), 'member')}
            </p>
            {error && (
              <Alert className="mt-5 text-left">{error}</Alert>
            )}
            {preview.already_member ? (
              <Button className="mt-6 w-full" onClick={goToGroup}>
                You're already a member. Open group
              </Button>
            ) : (
              <Button className="mt-6 w-full" loading={joining} onClick={() => void join()}>
                Join group
              </Button>
            )}
            <p className="mt-4 flex items-center justify-center gap-1.5 text-xs text-faint">
              <Lock className="size-3.5" aria-hidden /> Only members can see what's shared inside.
            </p>
          </>
        ) : (
          <>
            <h1 className="mt-6 text-xl font-bold">This invite doesn't work</h1>
            <p className="mt-2 text-sm text-muted">
              {state === 'error'
                ? error
                : 'It may have expired, been used up, or been revoked. Ask your friend for a new invite.'}
            </p>
            <Link to={memberships.length ? '/' : '/onboarding'} className="btn btn-secondary mt-6 w-full">
              {memberships.length ? 'Back to your group' : 'Enter a different code'}
            </Link>
          </>
        )}
      </div>
    </main>
  )
}
