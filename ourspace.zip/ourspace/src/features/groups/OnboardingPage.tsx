import { useState, type FormEvent } from 'react'
import { Link, Navigate, useLocation, useNavigate } from 'react-router-dom'
import { ArrowLeft, KeyRound, Sparkles } from 'lucide-react'
import { useAuth, useMe } from '../../contexts/AuthContext'
import { useGroup } from '../../contexts/GroupContext'
import { useToast } from '../../contexts/ToastContext'
import { supabase } from '../../lib/supabase'
import { friendlyError } from '../../lib/errors'
import { LogoMark } from '../../components/layout/Logo'
import { Alert } from '../../components/ui/Alert'
import { Button } from '../../components/ui/Button'
import { TextAreaField, TextField } from '../../components/ui/Field'
import { PageLoader } from '../../components/ui/Spinner'

/** Accepts a bare code or a pasted invite link. */
export function extractInviteCode(input: string): string {
  const trimmed = input.trim()
  const match = trimmed.match(/\/join\/([A-Za-z0-9]+)/)
  return (match ? match[1] : trimmed).replace(/[^A-Za-z0-9]/g, '').toUpperCase()
}

export function OnboardingPage() {
  const me = useMe()
  const { signOut } = useAuth()
  const { memberships, loading, refresh, selectGroup } = useGroup()
  const toast = useToast()
  const navigate = useNavigate()
  const { search } = useLocation()
  const adding = new URLSearchParams(search).has('add')

  const [name, setName] = useState('')
  const [description, setDescription] = useState('')
  const [nameError, setNameError] = useState<string | null>(null)
  const [createError, setCreateError] = useState<string | null>(null)
  const [creating, setCreating] = useState(false)

  const [code, setCode] = useState('')
  const [codeError, setCodeError] = useState<string | null>(null)

  if (loading) return <PageLoader />
  if (memberships.length > 0 && !adding) return <Navigate to="/" replace />

  const onCreate = async (e: FormEvent) => {
    e.preventDefault()
    if (!name.trim()) {
      setNameError('Give your group a name.')
      return
    }
    setNameError(null)
    setCreating(true)
    setCreateError(null)
    const { data, error } = await supabase.rpc('create_group', {
      p_name: name.trim(),
      p_description: description.trim() || null,
    })
    if (error) {
      setCreateError(friendlyError(error))
      setCreating(false)
      return
    }
    await refresh()
    selectGroup(data as string)
    toast('Group created. Now invite your friends!')
    navigate('/members', { replace: true })
  }

  const onJoin = (e: FormEvent) => {
    e.preventDefault()
    const clean = extractInviteCode(code)
    if (clean.length < 6) {
      setCodeError('Enter the invite code or paste the invite link you received.')
      return
    }
    navigate(`/join/${clean}`)
  }

  return (
    <main className="mx-auto min-h-dvh max-w-4xl px-5 py-10">
      <header className="mb-10 flex items-center justify-between">
        <span className="flex items-center gap-3">
          <LogoMark className="size-10" />
          <span className="text-xl font-bold tracking-tight">OurSpace</span>
        </span>
        {adding ? (
          <Link to="/profile" className="btn btn-ghost btn-sm">
            <ArrowLeft className="size-4" aria-hidden /> Back
          </Link>
        ) : (
          <button className="btn btn-ghost btn-sm" onClick={() => void signOut()}>
            Sign out
          </button>
        )}
      </header>

      <h1 className="text-3xl font-bold tracking-tight">
        {adding ? 'Add a group' : `Welcome, ${me.display_name.split(' ')[0]}!`}
      </h1>
      <p className="mt-2 text-muted">
        {adding
          ? 'Start another private group or join one with an invite.'
          : 'OurSpace is invite-only. Join your friends with their invite, or start a new group and invite them.'}
      </p>

      <div className="mt-8 grid gap-5 md:grid-cols-2">
        <section className="card p-6" aria-labelledby="join-heading">
          <span className="mb-4 flex size-11 items-center justify-center rounded-xl bg-brand-600/15 text-brand-400">
            <KeyRound className="size-5" aria-hidden />
          </span>
          <h2 id="join-heading" className="text-lg font-semibold">
            Join with an invite
          </h2>
          <p className="mt-1 text-sm text-muted">Paste the link or type the 8-character code a friend sent you.</p>
          <form onSubmit={onJoin} className="mt-5 space-y-4">
            <TextField
              label="Invite code or link"
              placeholder="e.g. K7PQ2MXA"
              autoCapitalize="characters"
              spellCheck={false}
              value={code}
              error={codeError}
              onChange={(e) => setCode(e.target.value)}
            />
            <Button type="submit" variant="secondary" className="w-full">
              Continue
            </Button>
          </form>
        </section>

        <section className="card p-6" aria-labelledby="create-heading">
          <span className="mb-4 flex size-11 items-center justify-center rounded-xl bg-brand-600/15 text-brand-400">
            <Sparkles className="size-5" aria-hidden />
          </span>
          <h2 id="create-heading" className="text-lg font-semibold">
            Start a new group
          </h2>
          <p className="mt-1 text-sm text-muted">You'll be the owner and can invite people right after.</p>
          <form onSubmit={onCreate} className="mt-5 space-y-4" noValidate>
            {createError && <Alert>{createError}</Alert>}
            <TextField
              label="Group name"
              placeholder="e.g. 9-A Friends"
              maxLength={60}
              value={name}
              error={nameError}
              onChange={(e) => setName(e.target.value)}
            />
            <TextAreaField
              label="Description"
              optional
              maxLength={280}
              rows={2}
              className="min-h-16"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
            />
            <Button type="submit" className="w-full" loading={creating}>
              Create group
            </Button>
          </form>
        </section>
      </div>
    </main>
  )
}
