import { useCallback, useEffect, useRef, useState } from 'react'
import type { RealtimeChannel } from '@supabase/supabase-js'
import { supabase } from '../../lib/supabase'
import { friendlyError } from '../../lib/errors'
import { MEDIA_BUCKET, groupMediaPath, uploadImage } from '../../lib/media'
import type { Message } from '../../lib/types'

const PAGE = 50

export interface ChatMessage extends Message {
  /** Only on messages this device is still sending. */
  pending?: {
    status: 'sending' | 'failed'
    error?: string
    file?: File | null
    previewUrl?: string | null
    progress?: number
  }
}

export type Connection = 'connecting' | 'live' | 'offline'

const byTime = (a: ChatMessage, b: ChatMessage) =>
  a.created_at === b.created_at ? a.id.localeCompare(b.id) : a.created_at < b.created_at ? -1 : 1

export function useChat(groupId: string, userId: string) {
  const [messages, setMessages] = useState<ChatMessage[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [hasOlder, setHasOlder] = useState(false)
  const [loadingOlder, setLoadingOlder] = useState(false)
  const [connection, setConnection] = useState<Connection>('connecting')
  const [reconnectKey, setReconnectKey] = useState(0)
  const messagesRef = useRef<ChatMessage[]>([])
  messagesRef.current = messages

  const merge = useCallback((incoming: Message[]) => {
    if (!incoming.length) return
    setMessages((prev) => {
      const map = new Map(prev.map((m) => [m.id, m]))
      for (const m of incoming) map.set(m.id, { ...m })
      return Array.from(map.values()).sort(byTime)
    })
  }, [])

  // Initial load (and reload when the group changes).
  const loadLatest = useCallback(async () => {
    setLoading(true)
    const { data, error: err } = await supabase
      .from('messages')
      .select('*')
      .eq('group_id', groupId)
      .order('created_at', { ascending: false })
      .limit(PAGE)
    if (err) {
      setError(friendlyError(err))
    } else {
      setError(null)
      const rows = ((data ?? []) as Message[]).reverse()
      setMessages((prev) => [...rows, ...prev.filter((m) => m.pending)].sort(byTime))
      setHasOlder(rows.length === PAGE)
    }
    setLoading(false)
  }, [groupId])

  useEffect(() => {
    setMessages([])
    void loadLatest()
  }, [loadLatest])

  // After a dropped connection, fetch anything we missed.
  const catchUp = useCallback(async () => {
    const confirmed = messagesRef.current.filter((m) => !m.pending)
    const last = confirmed[confirmed.length - 1]
    let query = supabase.from('messages').select('*').eq('group_id', groupId).order('created_at', { ascending: true }).limit(200)
    if (last) query = query.gte('created_at', last.created_at)
    const { data, error: err } = await query
    if (!err) merge((data ?? []) as Message[])
  }, [groupId, merge])

  // Realtime subscription. Postgres Changes applies RLS, so only members receive rows.
  useEffect(() => {
    let channel: RealtimeChannel | null = null
    let disposed = false
    let wasOffline = reconnectKey > 0
    setConnection('connecting')

    channel = supabase
      .channel(`chat:${groupId}:${reconnectKey}`)
      .on(
        'postgres_changes',
        { event: 'INSERT', schema: 'public', table: 'messages', filter: `group_id=eq.${groupId}` },
        (payload) => merge([payload.new as Message]),
      )
      // DELETE events cannot be filtered or checked against RLS, so Realtime
      // sends only the deleted row's id. We just drop that id if we have it.
      .on(
        'postgres_changes',
        { event: 'DELETE', schema: 'public', table: 'messages' },
        (payload) => {
          const id = (payload.old as { id?: string }).id
          if (id) setMessages((prev) => prev.filter((m) => m.id !== id))
        },
      )
      .subscribe((status) => {
        if (disposed) return
        if (status === 'SUBSCRIBED') {
          setConnection('live')
          if (wasOffline) void catchUp()
          wasOffline = false
        } else if (status === 'CHANNEL_ERROR' || status === 'TIMED_OUT' || status === 'CLOSED') {
          setConnection('offline')
          wasOffline = true
        }
      })

    return () => {
      disposed = true
      if (channel) void supabase.removeChannel(channel)
    }
  }, [groupId, reconnectKey, merge, catchUp])

  useEffect(() => {
    const onOnline = () => setReconnectKey((k) => k + 1)
    window.addEventListener('online', onOnline)
    return () => window.removeEventListener('online', onOnline)
  }, [])

  const reconnect = useCallback(() => setReconnectKey((k) => k + 1), [])

  const loadOlder = useCallback(async () => {
    const oldest = messagesRef.current.find((m) => !m.pending)
    if (!oldest) return
    setLoadingOlder(true)
    const { data, error: err } = await supabase
      .from('messages')
      .select('*')
      .eq('group_id', groupId)
      .lt('created_at', oldest.created_at)
      .order('created_at', { ascending: false })
      .limit(PAGE)
    setLoadingOlder(false)
    if (err) {
      setError(friendlyError(err))
      return
    }
    const rows = (data ?? []) as Message[]
    merge(rows)
    setHasOlder(rows.length === PAGE)
  }, [groupId, merge])

  const patchPending = (tempId: string, pending: ChatMessage['pending']) =>
    setMessages((prev) => prev.map((m) => (m.id === tempId ? { ...m, pending: pending && { ...m.pending, ...pending } } : m)))

  const deliver = useCallback(
    async (tempId: string, body: string | null, file: File | null) => {
      try {
        let attachment_path: string | null = null
        if (file) {
          attachment_path = groupMediaPath(groupId, userId, file)
          await uploadImage({
            bucket: MEDIA_BUCKET,
            path: attachment_path,
            file,
            onProgress: (p) => patchPending(tempId, { status: 'sending', progress: p }),
          })
        }
        const { data, error: err } = await supabase
          .from('messages')
          .insert({ group_id: groupId, sender_id: userId, body, attachment_path })
          .select('*')
          .single()
        if (err) throw err
        const saved = data as Message
        setMessages((prev) => {
          const temp = prev.find((m) => m.id === tempId)
          if (temp?.pending?.previewUrl) URL.revokeObjectURL(temp.pending.previewUrl)
          const rest = prev.filter((m) => m.id !== tempId && m.id !== saved.id)
          return [...rest, saved].sort(byTime)
        })
      } catch (e) {
        patchPending(tempId, { status: 'failed', error: friendlyError(e, 'Not sent.') })
      }
    },
    [groupId, userId],
  )

  const send = useCallback(
    (text: string, file: File | null) => {
      const body = text.trim() || null
      if (!body && !file) return
      const tempId = `temp-${crypto.randomUUID()}`
      const optimistic: ChatMessage = {
        id: tempId,
        group_id: groupId,
        sender_id: userId,
        body,
        attachment_path: null,
        created_at: new Date().toISOString(),
        pending: { status: 'sending', file, previewUrl: file ? URL.createObjectURL(file) : null, progress: 0 },
      }
      setMessages((prev) => [...prev, optimistic])
      void deliver(tempId, body, file)
    },
    [groupId, userId, deliver],
  )

  const retry = useCallback(
    (tempId: string) => {
      const m = messagesRef.current.find((x) => x.id === tempId)
      if (!m?.pending) return
      patchPending(tempId, { status: 'sending', error: undefined })
      void deliver(tempId, m.body, m.pending.file ?? null)
    },
    [deliver],
  )

  const discard = useCallback((tempId: string) => {
    setMessages((prev) => {
      const m = prev.find((x) => x.id === tempId)
      if (m?.pending?.previewUrl) URL.revokeObjectURL(m.pending.previewUrl)
      return prev.filter((x) => x.id !== tempId)
    })
  }, [])

  const remove = useCallback(async (id: string) => {
    const { error: err } = await supabase.from('messages').delete().eq('id', id)
    if (err) throw err
    setMessages((prev) => prev.filter((m) => m.id !== id))
  }, [])

  return { messages, loading, error, hasOlder, loadingOlder, connection, reconnect, loadOlder, send, retry, discard, remove, reload: loadLatest }
}
