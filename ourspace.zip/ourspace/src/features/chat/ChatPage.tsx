import { Fragment, useEffect, useLayoutEffect, useRef, useState, type FormEvent, type KeyboardEvent } from 'react'
import { ArrowDown, CircleAlert, MessageCircle, Paperclip, RefreshCw, SendHorizontal, Trash2, WifiOff, X } from 'lucide-react'
import { useMe } from '../../contexts/AuthContext'
import { useCurrentGroup, useGroup } from '../../contexts/GroupContext'
import { useToast } from '../../contexts/ToastContext'
import { friendlyError } from '../../lib/errors'
import { dayLabel, formatTime, plural } from '../../lib/format'
import { IMAGE_TYPES, validateImage } from '../../lib/media'
import { cn } from '../../lib/cn'
import type { ProfileSummary } from '../../lib/types'
import { Alert } from '../../components/ui/Alert'
import { Avatar } from '../../components/ui/Avatar'
import { Button } from '../../components/ui/Button'
import { Modal } from '../../components/ui/Modal'
import { SignedImage } from '../../components/ui/SignedImage'
import { Spinner } from '../../components/ui/Spinner'
import { useChat, type ChatMessage } from './useChat'

const GROUP_WINDOW_MS = 5 * 60 * 1000

export function ChatPage() {
  const me = useMe()
  const group = useCurrentGroup()
  const { members, profileOf, isAdmin } = useGroup()
  const toast = useToast()
  const chat = useChat(group.id, me.id)

  const scrollerRef = useRef<HTMLDivElement>(null)
  const atBottomRef = useRef(true)
  const lastIdRef = useRef<string | null>(null)
  const prependHeightRef = useRef<number | null>(null)
  const [showJump, setShowJump] = useState(false)
  const [viewing, setViewing] = useState<ChatMessage | null>(null)

  const scrollToBottom = (smooth = false) => {
    const el = scrollerRef.current
    if (el) el.scrollTo({ top: el.scrollHeight, behavior: smooth ? 'smooth' : 'auto' })
  }

  const onScroll = () => {
    const el = scrollerRef.current
    if (!el) return
    atBottomRef.current = el.scrollHeight - el.scrollTop - el.clientHeight < 80
    if (atBottomRef.current) setShowJump(false)
  }

  // Keep the view pinned to the newest message unless the reader scrolled up.
  useLayoutEffect(() => {
    const el = scrollerRef.current
    if (!el) return
    if (prependHeightRef.current !== null) {
      el.scrollTop += el.scrollHeight - prependHeightRef.current
      prependHeightRef.current = null
      return
    }
    const last = chat.messages[chat.messages.length - 1]
    if (!last || last.id === lastIdRef.current) return
    const first = lastIdRef.current === null
    lastIdRef.current = last.id
    if (first || atBottomRef.current || last.sender_id === me.id) scrollToBottom(!first)
    else setShowJump(true)
  }, [chat.messages, me.id])

  const loadOlder = async () => {
    prependHeightRef.current = scrollerRef.current?.scrollHeight ?? null
    await chat.loadOlder()
  }

  const deleteMessage = async (m: ChatMessage) => {
    try {
      await chat.remove(m.id)
    } catch (e) {
      toast(friendlyError(e), 'error')
    }
  }

  return (
    <div className="chat-height -mx-4 flex flex-col lg:mx-0">
      <header className="flex items-center gap-3 border-b border-line px-4 py-3 lg:pt-8">
        <div className="flex -space-x-2" aria-hidden>
          {members.slice(0, 3).map((m) => (
            <Avatar key={m.id} profile={m.profile} size="sm" className="ring-2 ring-bg" />
          ))}
        </div>
        <div className="min-w-0 flex-1">
          <h1 className="truncate font-semibold">Group chat</h1>
          <p className="text-xs text-muted">{plural(members.length, 'member')}</p>
        </div>
        <ConnectionBadge state={chat.connection} />
      </header>

      {chat.connection === 'offline' && (
        <div className="flex items-center gap-2 border-b border-warning/30 bg-warning/10 px-4 py-2 text-sm text-amber-200" role="status">
          <WifiOff className="size-4 shrink-0" aria-hidden />
          <span className="flex-1">Live updates paused. New messages may be delayed.</span>
          <button onClick={chat.reconnect} className="font-semibold underline-offset-4 hover:underline">
            Reconnect
          </button>
        </div>
      )}

      <div ref={scrollerRef} onScroll={onScroll} className="relative flex-1 overflow-y-auto px-4 py-4">
        {chat.error && (
          <Alert className="mb-4" action={<Button size="sm" variant="secondary" onClick={() => void chat.reload()}>Retry</Button>}>
            {chat.error}
          </Alert>
        )}

        {chat.loading ? (
          <div className="flex h-full items-center justify-center">
            <Spinner className="size-7" label="Loading messages" />
          </div>
        ) : chat.messages.length === 0 && !chat.error ? (
          <div className="flex h-full flex-col items-center justify-center text-center">
            <span className="mb-4 flex size-14 items-center justify-center rounded-2xl border border-brand-500/30 bg-brand-500/10">
              <MessageCircle className="size-7 text-brand-400" aria-hidden />
            </span>
            <p className="font-semibold">No messages yet</p>
            <p className="mt-1 max-w-xs text-sm text-muted">Say hi to {group.name}. Everyone in the group will see it instantly.</p>
          </div>
        ) : (
          <>
            {chat.hasOlder && (
              <div className="mb-4 flex justify-center">
                <Button size="sm" variant="secondary" loading={chat.loadingOlder} onClick={() => void loadOlder()}>
                  Load earlier messages
                </Button>
              </div>
            )}
            <ol className="space-y-0.5" aria-label="Messages">
              {chat.messages.map((m, i) => {
                const prev = chat.messages[i - 1]
                const newDay = !prev || new Date(prev.created_at).toDateString() !== new Date(m.created_at).toDateString()
                const continued =
                  !newDay &&
                  prev.sender_id === m.sender_id &&
                  new Date(m.created_at).getTime() - new Date(prev.created_at).getTime() < GROUP_WINDOW_MS
                return (
                  <Fragment key={m.id}>
                    {newDay && (
                      <li className="my-4 flex justify-center" aria-hidden>
                        <span className="chip">{dayLabel(m.created_at)}</span>
                      </li>
                    )}
                    <MessageRow
                      message={m}
                      mine={m.sender_id === me.id}
                      continued={continued}
                      sender={profileOf(m.sender_id)}
                      canDelete={!m.pending && (m.sender_id === me.id || isAdmin)}
                      onRetry={() => chat.retry(m.id)}
                      onDiscard={() => chat.discard(m.id)}
                      onDelete={() => void deleteMessage(m)}
                      onOpenImage={() => setViewing(m)}
                    />
                  </Fragment>
                )
              })}
            </ol>
          </>
        )}
      </div>

      {showJump && (
        <div className="pointer-events-none relative">
          <button
            onClick={() => {
              scrollToBottom(true)
              setShowJump(false)
            }}
            className="pointer-events-auto absolute -top-14 left-1/2 flex -translate-x-1/2 items-center gap-1.5 rounded-full bg-brand-600 px-4 py-2 text-sm font-semibold text-white shadow-glow"
          >
            <ArrowDown className="size-4" aria-hidden /> New messages
          </button>
        </div>
      )}

      <Composer onSend={chat.send} />

      <Modal open={!!viewing} onClose={() => setViewing(null)} title="Image" size="xl" bare>
        {viewing &&
          (viewing.pending?.previewUrl ? (
            <img src={viewing.pending.previewUrl} alt="" className="max-h-[85dvh] w-full object-contain" />
          ) : viewing.attachment_path ? (
            <SignedImage path={viewing.attachment_path} alt="Shared image" className="min-h-64" imgClassName="object-contain max-h-[85dvh]" />
          ) : null)}
      </Modal>
    </div>
  )
}

function ConnectionBadge({ state }: { state: 'connecting' | 'live' | 'offline' }) {
  const label = state === 'live' ? 'Live' : state === 'connecting' ? 'Connecting' : 'Offline'
  return (
    <span className="chip" title={state === 'live' ? 'New messages appear instantly' : undefined}>
      <span
        className={cn(
          'size-2 rounded-full',
          state === 'live' && 'bg-success',
          state === 'connecting' && 'animate-pulse bg-warning',
          state === 'offline' && 'bg-danger',
        )}
        aria-hidden
      />
      {label}
    </span>
  )
}

function MessageRow({
  message: m,
  mine,
  continued,
  sender,
  canDelete,
  onRetry,
  onDiscard,
  onDelete,
  onOpenImage,
}: {
  message: ChatMessage
  mine: boolean
  continued: boolean
  sender: ProfileSummary | null
  canDelete: boolean
  onRetry: () => void
  onDiscard: () => void
  onDelete: () => void
  onOpenImage: () => void
}) {
  const failed = m.pending?.status === 'failed'
  const sending = m.pending?.status === 'sending'
  const hasImage = !!m.attachment_path || !!m.pending?.previewUrl

  return (
    // tabIndex -1 lets a tap focus the row on touch screens, which reveals the delete button.
    <li tabIndex={-1} className={cn('group/msg flex items-end gap-2 outline-none', mine && 'flex-row-reverse', !continued && 'mt-3')}>
      {!mine && (
        <div className="w-8 shrink-0">{!continued && <Avatar profile={sender} size="sm" />}</div>
      )}
      <div className={cn('flex max-w-[78%] flex-col sm:max-w-[65%]', mine ? 'items-end' : 'items-start')}>
        {!mine && !continued && (
          <span className="mb-1 ml-3 text-xs font-medium text-muted">{sender?.display_name ?? 'Former member'}</span>
        )}
        <div
          className={cn(
            'overflow-hidden rounded-2xl text-[15px] leading-snug break-words whitespace-pre-wrap',
            mine ? 'rounded-br-md bg-brand-600 text-white' : 'rounded-bl-md border border-line bg-surface-2 text-ink',
            sending && 'opacity-70',
            failed && 'ring-2 ring-danger/60',
          )}
        >
          {hasImage && (
            <button onClick={onOpenImage} className="block w-full" aria-label="Open image">
              {m.pending?.previewUrl ? (
                <img src={m.pending.previewUrl} alt="" className="max-h-72 w-full object-cover" />
              ) : (
                <SignedImage path={m.attachment_path!} alt="Shared image" className="h-56 w-64 max-w-full" />
              )}
            </button>
          )}
          {m.body && <p className="px-3.5 py-2">{m.body}</p>}
        </div>
        <div className={cn('mt-0.5 flex items-center gap-2 px-1 text-[11px] text-faint', mine && 'flex-row-reverse')}>
          {failed ? (
            <span className="flex items-center gap-2 text-danger">
              <CircleAlert className="size-3.5" aria-hidden />
              {m.pending?.error ?? 'Not sent'}
              <button onClick={onRetry} className="inline-flex items-center gap-1 font-semibold underline-offset-2 hover:underline">
                <RefreshCw className="size-3" aria-hidden /> Retry
              </button>
              <button onClick={onDiscard} className="inline-flex items-center gap-1 font-semibold underline-offset-2 hover:underline">
                <X className="size-3" aria-hidden /> Discard
              </button>
            </span>
          ) : sending ? (
            <span>
              {m.pending?.file && (m.pending.progress ?? 0) < 1
                ? `Uploading ${Math.round((m.pending.progress ?? 0) * 100)}%`
                : 'Sending…'}
            </span>
          ) : (
            <time dateTime={m.created_at}>{formatTime(m.created_at)}</time>
          )}
          {canDelete && (
            <button
              onClick={onDelete}
              className="rounded p-0.5 opacity-0 transition-opacity group-hover/msg:opacity-100 group-focus-within/msg:opacity-100 hover:text-danger focus:opacity-100"
              aria-label="Delete message"
            >
              <Trash2 className="size-3.5" />
            </button>
          )}
        </div>
      </div>
    </li>
  )
}

function Composer({ onSend }: { onSend: (text: string, file: File | null) => void }) {
  const [text, setText] = useState('')
  const [file, setFile] = useState<File | null>(null)
  const [preview, setPreview] = useState<string | null>(null)
  const [fileError, setFileError] = useState<string | null>(null)
  const textRef = useRef<HTMLTextAreaElement>(null)
  const fileRef = useRef<HTMLInputElement>(null)

  useEffect(() => {
    if (!file) {
      setPreview(null)
      return
    }
    const url = URL.createObjectURL(file)
    setPreview(url)
    return () => URL.revokeObjectURL(url)
  }, [file])

  // Grow with the text, up to about five lines.
  useLayoutEffect(() => {
    const el = textRef.current
    if (!el) return
    el.style.height = 'auto'
    el.style.height = `${Math.min(el.scrollHeight, 140)}px`
  }, [text])

  const canSend = !!text.trim() || !!file

  const submit = (e?: FormEvent) => {
    e?.preventDefault()
    if (!canSend) return
    onSend(text, file)
    setText('')
    setFile(null)
    textRef.current?.focus()
  }

  const onKeyDown = (e: KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && !e.shiftKey && !e.nativeEvent.isComposing) {
      e.preventDefault()
      submit()
    }
  }

  return (
    <form onSubmit={submit} className="border-t border-line bg-bg/80 px-3 py-3 backdrop-blur lg:pb-6">
      {(preview || fileError) && (
        <div className="mb-2 flex items-center gap-3 px-1">
          {preview && (
            <div className="relative">
              <img src={preview} alt="Attachment preview" className="size-16 rounded-xl object-cover" />
              <button
                type="button"
                onClick={() => setFile(null)}
                className="absolute -top-2 -right-2 flex size-6 items-center justify-center rounded-full bg-surface-3 text-ink ring-2 ring-bg"
                aria-label="Remove attachment"
              >
                <X className="size-3.5" />
              </button>
            </div>
          )}
          {fileError && <p className="text-sm text-danger">{fileError}</p>}
        </div>
      )}
      <div className="flex items-end gap-2">
        <button type="button" onClick={() => fileRef.current?.click()} className="icon-btn shrink-0" aria-label="Attach an image">
          <Paperclip className="size-5" />
        </button>
        <input
          ref={fileRef}
          type="file"
          accept={IMAGE_TYPES.join(',')}
          className="sr-only"
          tabIndex={-1}
          aria-hidden
          onChange={(e) => {
            const f = e.target.files?.[0]
            e.target.value = ''
            if (!f) return
            const problem = validateImage(f)
            setFileError(problem)
            if (!problem) setFile(f)
          }}
        />
        <label htmlFor="chat-input" className="sr-only">
          Message
        </label>
        <textarea
          id="chat-input"
          ref={textRef}
          rows={1}
          value={text}
          maxLength={4000}
          onChange={(e) => setText(e.target.value)}
          onKeyDown={onKeyDown}
          placeholder="Message…"
          className="input max-h-36 min-h-11 flex-1 resize-none rounded-2xl py-2.5"
        />
        <button
          type="submit"
          disabled={!canSend}
          className="flex size-11 shrink-0 items-center justify-center rounded-full bg-brand-600 text-white shadow-glow transition-all hover:bg-brand-500 active:scale-95 disabled:bg-surface-3 disabled:text-faint disabled:shadow-none"
          aria-label="Send message"
        >
          <SendHorizontal className="size-5" />
        </button>
      </div>
    </form>
  )
}
