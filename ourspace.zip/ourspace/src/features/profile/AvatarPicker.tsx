import { useEffect, useId, useState } from 'react'
import { Camera } from 'lucide-react'
import { Avatar } from '../../components/ui/Avatar'
import { AVATAR_TYPES, MAX_AVATAR_BYTES, validateImage } from '../../lib/media'
import type { ProfileSummary } from '../../lib/types'

/** Avatar preview with a "choose photo" control. Uploading is left to the caller. */
export function AvatarPicker({
  profile,
  file,
  onFile,
  onRemove,
  disabled,
}: {
  profile: ProfileSummary | null
  file: File | null
  onFile: (file: File | null) => void
  onRemove?: () => void
  disabled?: boolean
}) {
  const id = useId()
  const [preview, setPreview] = useState<string | null>(null)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    if (!file) {
      setPreview(null)
      return
    }
    const url = URL.createObjectURL(file)
    setPreview(url)
    return () => URL.revokeObjectURL(url)
  }, [file])

  return (
    <div className="flex items-center gap-4">
      {preview ? (
        <img src={preview} alt="New profile photo preview" className="size-20 rounded-full object-cover ring-2 ring-brand-500" />
      ) : (
        <Avatar profile={profile} size="xl" />
      )}
      <div className="space-y-2">
        <div className="flex flex-wrap gap-2">
          <label htmlFor={id} className="btn btn-secondary btn-sm cursor-pointer has-[:focus-visible]:ring-2 has-[:focus-visible]:ring-brand-400">
            <Camera className="size-4" aria-hidden /> {file || profile?.avatar_path ? 'Change photo' : 'Add photo'}
            <input
              id={id}
              type="file"
              accept={AVATAR_TYPES.join(',')}
              className="sr-only"
              disabled={disabled}
              onChange={(e) => {
                const f = e.target.files?.[0]
                e.target.value = ''
                if (!f) return
                const problem = validateImage(f, { types: AVATAR_TYPES, maxBytes: MAX_AVATAR_BYTES })
                setError(problem)
                if (!problem) onFile(f)
              }}
            />
          </label>
          {file && (
            <button type="button" className="btn btn-ghost btn-sm" onClick={() => onFile(null)} disabled={disabled}>
              Undo
            </button>
          )}
          {!file && profile?.avatar_path && onRemove && (
            <button type="button" className="btn btn-ghost btn-sm" onClick={onRemove} disabled={disabled}>
              Remove
            </button>
          )}
        </div>
        {error ? <p className="text-sm text-danger">{error}</p> : <p className="text-xs text-faint">JPG, PNG or WebP, up to 2 MB.</p>}
      </div>
    </div>
  )
}
