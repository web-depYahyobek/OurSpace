import { useState, type FormEvent } from 'react'
import { Navigate, useLocation } from 'react-router-dom'
import { useAuth } from '../../contexts/AuthContext'
import { supabase } from '../../lib/supabase'
import { friendlyError } from '../../lib/errors'
import { AVATAR_BUCKET, avatarPath, uploadImage } from '../../lib/media'
import { safeNext } from '../../lib/navigation'
import { Alert } from '../../components/ui/Alert'
import { Button } from '../../components/ui/Button'
import { TextField } from '../../components/ui/Field'
import { AuthLayout } from '../auth/AuthLayout'
import { AvatarPicker } from './AvatarPicker'
import { suggestUsername, validateDisplayName, validateUsername } from './profileValidation'

export function ProfileSetupPage() {
  const { user, profile, refreshProfile, signOut } = useAuth()
  const { search } = useLocation()
  const [displayName, setDisplayName] = useState('')
  const [username, setUsername] = useState('')
  const [usernameTouched, setUsernameTouched] = useState(false)
  const [avatar, setAvatar] = useState<File | null>(null)
  const [errors, setErrors] = useState<{ displayName?: string | null; username?: string | null }>({})
  const [formError, setFormError] = useState<string | null>(null)
  const [busy, setBusy] = useState(false)

  if (profile) return <Navigate to={safeNext(search)} replace />
  if (!user) return null

  const onSubmit = async (e: FormEvent) => {
    e.preventDefault()
    const next = { displayName: validateDisplayName(displayName), username: validateUsername(username) }
    setErrors(next)
    if (next.displayName || next.username) return

    setBusy(true)
    setFormError(null)
    try {
      let avatar_path: string | null = null
      if (avatar) {
        avatar_path = avatarPath(user.id, avatar)
        await uploadImage({ bucket: AVATAR_BUCKET, path: avatar_path, file: avatar })
      }
      const { error } = await supabase
        .from('profiles')
        .insert({ id: user.id, username, display_name: displayName.trim(), avatar_path })
      if (error) throw error
      await refreshProfile()
    } catch (err) {
      const message = friendlyError(err)
      if (/username/i.test(message)) setErrors((p) => ({ ...p, username: message }))
      else setFormError(message)
      setBusy(false)
    }
  }

  return (
    <AuthLayout
      title="Set up your profile"
      subtitle="This is how your friends will see you."
      footer={
        <button className="text-muted underline-offset-4 hover:text-ink hover:underline" onClick={() => void signOut()}>
          Sign out
        </button>
      }
    >
      <form onSubmit={onSubmit} className="space-y-5" noValidate>
        {formError && <Alert>{formError}</Alert>}
        <AvatarPicker
          profile={displayName ? { id: user.id, username, display_name: displayName, avatar_path: null } : null}
          file={avatar}
          onFile={setAvatar}
          disabled={busy}
        />
        <TextField
          label="Your name"
          autoComplete="name"
          value={displayName}
          maxLength={50}
          error={errors.displayName}
          onChange={(e) => {
            setDisplayName(e.target.value)
            if (!usernameTouched) setUsername(suggestUsername(e.target.value))
          }}
        />
        <TextField
          label="Username"
          autoComplete="username"
          autoCapitalize="none"
          spellCheck={false}
          value={username}
          maxLength={20}
          error={errors.username}
          hint="3–20 lowercase letters, numbers or underscores."
          onChange={(e) => {
            setUsernameTouched(true)
            setUsername(e.target.value.toLowerCase().replace(/\s/g, '_'))
          }}
        />
        <Button type="submit" className="w-full" loading={busy}>
          Continue
        </Button>
      </form>
    </AuthLayout>
  )
}
