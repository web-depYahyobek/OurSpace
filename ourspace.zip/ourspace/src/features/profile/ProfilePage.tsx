import { useState, type FormEvent } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { Check, DoorOpen, LogOut, Plus } from 'lucide-react'
import { useAuth, useMe } from '../../contexts/AuthContext'
import { useGroup } from '../../contexts/GroupContext'
import { useToast } from '../../contexts/ToastContext'
import { supabase } from '../../lib/supabase'
import { friendlyError } from '../../lib/errors'
import { AVATAR_BUCKET, avatarPath, removeFile, uploadImage } from '../../lib/media'
import { cn } from '../../lib/cn'
import { PageHeader } from '../../components/layout/PageHeader'
import { Alert } from '../../components/ui/Alert'
import { Button } from '../../components/ui/Button'
import { ConfirmDialog } from '../../components/ui/ConfirmDialog'
import { TextField } from '../../components/ui/Field'
import { AvatarPicker } from './AvatarPicker'
import { validateDisplayName, validateUsername } from './profileValidation'

export function ProfilePage() {
  const me = useMe()
  const { refreshProfile, signOut } = useAuth()
  const { group, role, memberships, selectGroup, refresh } = useGroup()
  const toast = useToast()
  const navigate = useNavigate()

  const [displayName, setDisplayName] = useState(me.display_name)
  const [username, setUsername] = useState(me.username)
  const [avatar, setAvatar] = useState<File | null>(null)
  const [removeAvatar, setRemoveAvatar] = useState(false)
  const [errors, setErrors] = useState<{ displayName?: string | null; username?: string | null }>({})
  const [formError, setFormError] = useState<string | null>(null)
  const [busy, setBusy] = useState(false)
  const [confirmLeave, setConfirmLeave] = useState(false)

  const dirty = displayName.trim() !== me.display_name || username !== me.username || !!avatar || removeAvatar

  const onSave = async (e: FormEvent) => {
    e.preventDefault()
    const next = { displayName: validateDisplayName(displayName), username: validateUsername(username) }
    setErrors(next)
    if (next.displayName || next.username) return

    setBusy(true)
    setFormError(null)
    const oldPath = me.avatar_path
    let newPath: string | null = removeAvatar ? null : oldPath
    try {
      if (avatar) {
        newPath = avatarPath(me.id, avatar)
        await uploadImage({ bucket: AVATAR_BUCKET, path: newPath, file: avatar })
      }
      const { error } = await supabase
        .from('profiles')
        .update({ display_name: displayName.trim(), username, avatar_path: newPath })
        .eq('id', me.id)
      if (error) throw error
      if (oldPath && oldPath !== newPath) await removeFile(AVATAR_BUCKET, oldPath).catch(() => undefined)
      await refreshProfile()
      setAvatar(null)
      setRemoveAvatar(false)
      toast('Profile saved')
    } catch (err) {
      const message = friendlyError(err)
      if (/username/i.test(message)) setErrors((p) => ({ ...p, username: message }))
      else setFormError(message)
    } finally {
      setBusy(false)
    }
  }

  const leaveGroup = async () => {
    if (!group) return
    const { error } = await supabase.from('group_members').delete().eq('group_id', group.id).eq('user_id', me.id)
    if (error) throw error
    toast(`You left ${group.name}`)
    await refresh()
    navigate('/', { replace: true })
  }

  return (
    <div className="space-y-6">
      <PageHeader title="Profile" subtitle="How your friends see you." />

      <form onSubmit={onSave} className="card space-y-5 p-5" noValidate>
        {formError && <Alert>{formError}</Alert>}
        <AvatarPicker
          profile={removeAvatar ? { ...me, avatar_path: null } : me}
          file={avatar}
          onFile={(f) => {
            setAvatar(f)
            if (f) setRemoveAvatar(false)
          }}
          onRemove={() => setRemoveAvatar(true)}
          disabled={busy}
        />
        <div className="grid gap-4 sm:grid-cols-2">
          <TextField
            label="Your name"
            value={displayName}
            maxLength={50}
            error={errors.displayName}
            onChange={(e) => setDisplayName(e.target.value)}
          />
          <TextField
            label="Username"
            value={username}
            maxLength={20}
            autoCapitalize="none"
            spellCheck={false}
            error={errors.username}
            onChange={(e) => setUsername(e.target.value.toLowerCase().replace(/\s/g, '_'))}
          />
        </div>
        <div className="flex justify-end">
          <Button type="submit" loading={busy} disabled={!dirty}>
            Save changes
          </Button>
        </div>
      </form>

      <section className="card p-5" aria-labelledby="groups-heading">
        <div className="mb-4 flex items-center justify-between gap-3">
          <h2 id="groups-heading" className="font-semibold">
            Your groups
          </h2>
          <Link to="/onboarding?add=1" className="btn btn-secondary btn-sm">
            <Plus className="size-4" aria-hidden /> Create or join
          </Link>
        </div>
        <ul className="space-y-2">
          {memberships.map((m) => {
            const active = m.group.id === group?.id
            return (
              <li key={m.group.id}>
                <button
                  onClick={() => {
                    selectGroup(m.group.id)
                    if (!active) navigate('/')
                  }}
                  className={cn(
                    'flex w-full items-center justify-between gap-3 rounded-xl border px-4 py-3 text-left transition-colors',
                    active ? 'border-brand-500/50 bg-brand-600/10' : 'border-line hover:bg-surface-2',
                  )}
                  aria-current={active ? 'true' : undefined}
                >
                  <span>
                    <span className="block font-medium">{m.group.name}</span>
                    <span className="block text-xs text-muted capitalize">{m.role}</span>
                  </span>
                  {active && <Check className="size-5 text-brand-400" aria-label="Current group" />}
                </button>
              </li>
            )
          })}
        </ul>
        {group && (
          <div className="mt-4 border-t border-line pt-4">
            {role === 'owner' ? (
              <p className="text-xs text-faint">
                You own {group.name}. To leave, first make someone else the owner on the Members page.
              </p>
            ) : (
              <Button variant="danger" size="sm" icon={<DoorOpen className="size-4" />} onClick={() => setConfirmLeave(true)}>
                Leave {group.name}
              </Button>
            )}
          </div>
        )}
      </section>

      <Button variant="secondary" className="w-full lg:hidden" icon={<LogOut className="size-4" />} onClick={() => void signOut()}>
        Sign out
      </Button>

      <ConfirmDialog
        open={confirmLeave}
        onClose={() => setConfirmLeave(false)}
        title={`Leave ${group?.name ?? 'group'}?`}
        confirmLabel="Leave group"
        onConfirm={leaveGroup}
      >
        You will lose access to the chat, photos and everything else right away. You'll need a new invite to come back.
      </ConfirmDialog>
    </div>
  )
}
