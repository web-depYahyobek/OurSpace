export const USERNAME_PATTERN = /^[a-z0-9_]{3,20}$/

export function validateUsername(value: string): string | null {
  if (!value) return 'Choose a username.'
  if (value.length < 3) return 'Use at least 3 characters.'
  if (value.length > 20) return 'Use at most 20 characters.'
  if (!USERNAME_PATTERN.test(value)) return 'Use lowercase letters, numbers and underscores only.'
  return null
}

export function validateDisplayName(value: string): string | null {
  const v = value.trim()
  if (!v) return 'Enter your name.'
  if (v.length > 50) return 'Use at most 50 characters.'
  return null
}

/** "Sardor Karimov" -> "sardor_karimov" */
export function suggestUsername(displayName: string): string {
  return displayName
    .normalize('NFKD')
    .replace(/[̀-ͯ]/g, '')
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '_')
    .replace(/^_+|_+$/g, '')
    .slice(0, 20)
}
