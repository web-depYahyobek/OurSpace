import { useState } from 'react'
import { Heart, ImagePlus, Images, MessageCircle } from 'lucide-react'
import { useMe } from '../../contexts/AuthContext'
import { useCurrentGroup, useGroup } from '../../contexts/GroupContext'
import { formatDate } from '../../lib/format'
import { PageHeader } from '../../components/layout/PageHeader'
import { Alert } from '../../components/ui/Alert'
import { Button } from '../../components/ui/Button'
import { EmptyState } from '../../components/ui/EmptyState'
import { Modal } from '../../components/ui/Modal'
import { SignedImage } from '../../components/ui/SignedImage'
import { NewPostModal } from './NewPostModal'
import { PostCard } from './PostCard'
import { usePosts } from './usePosts'

export function GalleryPage() {
  const me = useMe()
  const group = useCurrentGroup()
  const { profileOf } = useGroup()
  const gallery = usePosts(group.id, me.id, 30)
  const [openId, setOpenId] = useState<string | null>(null)
  const [composing, setComposing] = useState(false)
  const open = gallery.posts.find((p) => p.id === openId) ?? null

  return (
    <div>
      <PageHeader
        title="Photos"
        subtitle="Every photo shared in the group."
        action={
          <Button icon={<ImagePlus className="size-4" />} onClick={() => setComposing(true)}>
            <span className="hidden sm:inline">Add photo</span>
            <span className="sm:hidden">Add</span>
          </Button>
        }
      />

      {gallery.error && (
        <Alert className="mb-4" action={<Button size="sm" variant="secondary" onClick={() => void gallery.reload()}>Retry</Button>}>
          {gallery.error}
        </Alert>
      )}

      {gallery.loading ? (
        <div className="grid grid-cols-3 gap-1 sm:gap-2" aria-hidden>
          {Array.from({ length: 9 }, (_, i) => (
            <div key={i} className="aspect-square animate-pulse rounded-lg bg-surface-2" />
          ))}
        </div>
      ) : gallery.posts.length === 0 && !gallery.error ? (
        <EmptyState
          icon={Images}
          title="No photos yet"
          action={
            <Button icon={<ImagePlus className="size-4" />} onClick={() => setComposing(true)}>
              Add the first photo
            </Button>
          }
        >
          Shared photos collect here so you can look back on them together.
        </EmptyState>
      ) : (
        <>
          <ul className="grid grid-cols-3 gap-1 sm:gap-2">
            {gallery.posts.map((p) => {
              const author = profileOf(p.author_id)
              return (
                <li key={p.id}>
                  <button
                    onClick={() => setOpenId(p.id)}
                    className="group relative block aspect-square w-full overflow-hidden rounded-md sm:rounded-xl"
                    aria-label={`Open photo by ${author?.display_name ?? 'a member'} from ${formatDate(p.created_at)}`}
                  >
                    <SignedImage path={p.image_path} alt="" className="size-full" imgClassName="transition-transform duration-300 group-hover:scale-105" />
                    <span className="absolute inset-0 hidden items-center justify-center gap-4 bg-black/50 text-sm font-semibold text-white group-hover:flex group-focus-visible:flex">
                      <span className="flex items-center gap-1">
                        <Heart className="size-4 fill-current" aria-hidden /> {p.like_count}
                      </span>
                      <span className="flex items-center gap-1">
                        <MessageCircle className="size-4 fill-current" aria-hidden /> {p.comment_count}
                      </span>
                    </span>
                  </button>
                </li>
              )
            })}
          </ul>
          {gallery.hasMore && (
            <Button variant="secondary" className="mt-5 w-full" loading={gallery.loadingMore} onClick={() => void gallery.loadMore()}>
              Load more photos
            </Button>
          )}
        </>
      )}

      <Modal open={!!open} onClose={() => setOpenId(null)} title="Photo" size="lg" bare>
        {open && (
          <PostCard
            post={open}
            fit="contain"
            inModal
            defaultShowComments
            onChange={(patch) => gallery.update(open.id, patch)}
            onDeleted={() => {
              setOpenId(null)
              gallery.remove(open.id)
            }}
          />
        )}
      </Modal>

      <NewPostModal open={composing} onClose={() => setComposing(false)} onCreated={gallery.prepend} />
    </div>
  )
}
