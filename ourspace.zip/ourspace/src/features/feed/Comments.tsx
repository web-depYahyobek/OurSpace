import { useEffect, useState, type FormEvent } from 'react'
import { SendHorizontal, Trash2 } from 'lucide-react'
import { useMe } from '../../contexts/AuthContext'
import { useGroup } from '../../contexts/GroupContext'
import { useToast } from '../../contexts/ToastContext'
import { supabase } from '../../lib/supabase'
import { friendlyError } from '../../lib/errors'
import { timeAgo } from '../../lib/format'
import type { Comment } from '../../lib/types'
import { Avatar } from '../../components/ui/Avatar'
import { Spinner } from '../../components/ui/Spinner'

export function Comments({ postId, onCountChange }: { postId: string; onCountChange: (delta: number) => void }) {
  const me = useMe()
  const { profileOf, isAdmin } = useGroup()
  const toast = useToast()
  const [comments, setComments] = useState<Comment[] | null>(null)
  const [error, setError] = useState<string | null>(null)
  const [body, setBody] = useState('')
  const [sending, setSending] = useState(false)

  useEffect(() => {
    let active = true
    supabase
      .from('comments')
      .select('*')
      .eq('post_id', postId)
      .order('created_at', { ascending: true })
      .limit(200)
      .then(({ data, error: err }) => {
        if (!active) return
        if (err) setError(friendlyError(err))
        else setComments((data ?? []) as Comment[])
      })
    return () => {
      active = false
    }
  }, [postId])

  const submit = async (e: FormEvent) => {
    e.preventDefault()
    const text = body.trim()
    if (!text) return
    setSending(true)
    const { data, error: err } = await supabase
      .from('comments')
      .insert({ post_id: postId, author_id: me.id, body: text })
      .select('*')
      .single()
    setSending(false)
    if (err) {
      toast(friendlyError(err), 'error')
      return
    }
    setComments((prev) => [...(prev ?? []), data as Comment])
    setBody('')
    onCountChange(1)
  }

  const remove = async (c: Comment) => {
    const { error: err } = await supabase.from('comments').delete().eq('id', c.id)
    if (err) {
      toast(friendlyError(err), 'error')
      return
    }
    setComments((prev) => (prev ?? []).filter((x) => x.id !== c.id))
    onCountChange(-1)
  }

  return (
    <div className="border-t border-line px-4 pt-3 pb-4">
      {error && <p className="mb-2 text-sm text-danger">{error}</p>}
      {comments === null && !error ? (
        <div className="flex justify-center py-3">
          <Spinner />
        </div>
      ) : comments && comments.length > 0 ? (
        <ul className="mb-3 space-y-3">
          {comments.map((c) => {
            const author = profileOf(c.author_id)
            return (
              <li key={c.id} tabIndex={-1} className="group/comment flex gap-2.5 outline-none">
                <Avatar profile={author} size="sm" />
                <div className="min-w-0 flex-1 rounded-2xl bg-surface-2 px-3 py-2">
                  <p className="text-xs">
                    <span className="font-semibold text-ink">{author?.display_name ?? 'Former member'}</span>
                    <span className="ml-2 text-faint">{timeAgo(c.created_at)}</span>
                  </p>
                  <p className="mt-0.5 text-sm break-words whitespace-pre-wrap text-ink">{c.body}</p>
                </div>
                {(c.author_id === me.id || isAdmin) && (
                  <button
                    onClick={() => void remove(c)}
                    className="self-center rounded-lg p-1.5 text-faint opacity-0 transition-opacity group-hover/comment:opacity-100 group-focus-within/comment:opacity-100 hover:text-danger focus:opacity-100"
                    aria-label="Delete comment"
                  >
                    <Trash2 className="size-4" />
                  </button>
                )}
              </li>
            )
          })}
        </ul>
      ) : (
        <p className="mb-3 text-sm text-faint">No comments yet. Say something nice.</p>
      )}

      <form onSubmit={submit} className="flex items-center gap-2">
        <Avatar profile={me} size="sm" />
        <label className="sr-only" htmlFor={`comment-${postId}`}>
          Add a comment
        </label>
        <input
          id={`comment-${postId}`}
          className="input min-h-10 flex-1 rounded-full py-2"
          placeholder="Add a comment…"
          maxLength={1000}
          value={body}
          onChange={(e) => setBody(e.target.value)}
          disabled={sending}
        />
        <button type="submit" className="icon-btn text-brand-400" disabled={!body.trim() || sending} aria-label="Post comment">
          {sending ? <Spinner className="size-4" /> : <SendHorizontal className="size-5" />}
        </button>
      </form>
    </div>
  )
}
