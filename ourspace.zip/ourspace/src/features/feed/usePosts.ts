import { useCallback, useEffect, useRef, useState } from 'react'
import { supabase } from '../../lib/supabase'
import { friendlyError } from '../../lib/errors'
import type { Post, PostWithStats } from '../../lib/types'

type Row = Post & { likes: { count: number }[]; comments: { count: number }[] }

/** Paged, newest-first posts for a group with like/comment counts and your own likes. */
export function usePosts(groupId: string, userId: string, pageSize = 10) {
  const [posts, setPosts] = useState<PostWithStats[]>([])
  const [loading, setLoading] = useState(true)
  const [loadingMore, setLoadingMore] = useState(false)
  const [hasMore, setHasMore] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const generation = useRef(0)

  const fetchPage = useCallback(
    async (from: number): Promise<PostWithStats[] | null> => {
      const { data, error: err } = await supabase
        .from('posts')
        .select('*, likes:post_likes(count), comments(count)')
        .eq('group_id', groupId)
        .order('created_at', { ascending: false })
        .range(from, from + pageSize - 1)
      if (err) {
        setError(friendlyError(err))
        return null
      }
      const rows = (data ?? []) as unknown as Row[]
      const ids = rows.map((r) => r.id)
      let liked = new Set<string>()
      if (ids.length) {
        const { data: mine } = await supabase.from('post_likes').select('post_id').eq('user_id', userId).in('post_id', ids)
        liked = new Set((mine ?? []).map((l: { post_id: string }) => l.post_id))
      }
      setError(null)
      setHasMore(rows.length === pageSize)
      return rows.map(({ likes, comments, ...p }) => ({
        ...p,
        like_count: likes?.[0]?.count ?? 0,
        comment_count: comments?.[0]?.count ?? 0,
        liked_by_me: liked.has(p.id),
      }))
    },
    [groupId, userId, pageSize],
  )

  const reload = useCallback(async () => {
    const gen = ++generation.current
    setLoading(true)
    const page = await fetchPage(0)
    if (gen !== generation.current) return
    if (page) setPosts(page)
    setLoading(false)
  }, [fetchPage])

  useEffect(() => {
    void reload()
  }, [reload])

  const loadMore = useCallback(async () => {
    setLoadingMore(true)
    const page = await fetchPage(posts.length)
    if (page) {
      setPosts((prev) => {
        const seen = new Set(prev.map((p) => p.id))
        return [...prev, ...page.filter((p) => !seen.has(p.id))]
      })
    }
    setLoadingMore(false)
  }, [fetchPage, posts.length])

  const prepend = useCallback((post: Post) => {
    setPosts((prev) => [{ ...post, like_count: 0, comment_count: 0, liked_by_me: false }, ...prev])
  }, [])

  const update = useCallback((id: string, patch: Partial<PostWithStats>) => {
    setPosts((prev) => prev.map((p) => (p.id === id ? { ...p, ...patch } : p)))
  }, [])

  const remove = useCallback((id: string) => {
    setPosts((prev) => prev.filter((p) => p.id !== id))
  }, [])

  return { posts, loading, loadingMore, hasMore, error, reload, loadMore, prepend, update, remove }
}
