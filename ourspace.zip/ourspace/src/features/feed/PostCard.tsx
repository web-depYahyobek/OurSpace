import { useState } from 'react'
import { Heart, MessageCircle, Trash2 } from 'lucide-react'
import { useMe } from '../../contexts/AuthContext'
import { useGroup } from '../../contexts/GroupContext'
import { useToast } from '../../contexts/ToastContext'
import { supabase } from '../../lib/supabase'
import { friendlyError } from '../../lib/errors'
import { formatDateTime, timeAgo } from '../../lib/format'
import { MEDIA_BUCKET, removeFile } from '../../lib/media'
import { cn } from '../../lib/cn'
import type { PostWithStats } from '../../lib/types'
import { Avatar } from '../../components/ui/Avatar'
import { ConfirmDialog } from '../../components/ui/ConfirmDialog'
import { SignedImage } from '../../components/ui/SignedImage'
import { Comments } from './Comments'

export function PostCard({
  post,
  onChange,
  onDeleted,
  defaultShowComments = false,
  fit = 'cover',
  inModal = false,
}: {
  post: PostWithStats
  onChange: (patch: Partial<PostWithStats>) => void
  onDeleted: () => void
  defaultShowComments?: boolean
  fit?: 'cover' | 'contain'
  /** Rendered inside a bare modal: no card chrome, room for the close button. */
  inModal?: boolean
}) {
  const me = useMe()
  const { profileOf, isAdmin } = useGroup()
  const toast = useToast()
  const [showComments, setShowComments] = useState(defaultShowComments)
  const [confirmDelete, setConfirmDelete] = useState(false)
  const [liking, setLiking] = useState(false)
  const author = profileOf(post.author_id)
  const canDelete = post.author_id === me.id || isAdmin

  const toggleLike = async () => {
    if (liking) return
    const liked = !post.liked_by_me
    setLiking(true)
    onChange({ liked_by_me: liked, like_count: Math.max(0, post.like_count + (liked ? 1 : -1)) })
    const { error } = liked
      ? await supabase.from('post_likes').insert({ post_id: post.id, user_id: me.id })
      : await supabase.from('post_likes').delete().eq('post_id', post.id).eq('user_id', me.id)
    setLiking(false)
    if (error && !(liked && error.code === '23505')) {
      onChange({ liked_by_me: !liked, like_count: post.like_count })
      toast(friendlyError(error), 'error')
    }
  }

  const deletePost = async () => {
    const { error } = await supabase.from('posts').delete().eq('id', post.id)
    if (error) throw error
    await removeFile(MEDIA_BUCKET, post.image_path).catch(() => undefined)
    toast('Post deleted')
    onDeleted()
  }

  return (
    <article className={cn(inModal ? 'overflow-hidden' : 'card overflow-hidden')} aria-label={`Post by ${author?.display_name ?? 'a former member'}`}>
      <header className={cn('flex items-center gap-3 px-4 py-3', inModal && 'pr-16')}>
        <Avatar profile={author} />
        <div className="min-w-0 flex-1">
          <p className="truncate font-semibold">{author?.display_name ?? 'Former member'}</p>
          <p className="text-xs text-muted">
            <time dateTime={post.created_at} title={formatDateTime(post.created_at)}>
              {timeAgo(post.created_at)}
            </time>
          </p>
        </div>
        {canDelete && (
          <button onClick={() => setConfirmDelete(true)} className="icon-btn -mr-2" aria-label="Delete post">
            <Trash2 className="size-5" />
          </button>
        )}
      </header>

      <SignedImage
        path={post.image_path}
        alt={post.caption ? `Photo: ${post.caption}` : `Photo shared by ${author?.display_name ?? 'a member'}`}
        className={cn(fit === 'cover' ? 'aspect-[4/3]' : 'max-h-[70dvh] min-h-64')}
        imgClassName={fit === 'contain' ? 'object-contain max-h-[70dvh]' : undefined}
      />

      <div className="flex items-center gap-1 px-2 pt-2">
        <button
          onClick={() => void toggleLike()}
          className={cn('btn btn-ghost btn-sm gap-1.5 px-2.5', post.liked_by_me && 'text-pink-400 hover:text-pink-300')}
          aria-pressed={post.liked_by_me}
          aria-label={post.liked_by_me ? 'Unlike' : 'Like'}
        >
          <Heart className={cn('size-5 transition-transform', post.liked_by_me && 'scale-110 fill-current')} aria-hidden />
          <span className="tabular-nums">{post.like_count}</span>
        </button>
        <button
          onClick={() => setShowComments((s) => !s)}
          className={cn('btn btn-ghost btn-sm gap-1.5 px-2.5', showComments && 'text-ink')}
          aria-expanded={showComments}
          aria-label={`${showComments ? 'Hide' : 'Show'} comments`}
        >
          <MessageCircle className="size-5" aria-hidden />
          <span className="tabular-nums">{post.comment_count}</span>
        </button>
      </div>

      {post.caption && (
        <p className="px-4 pt-1 pb-3 text-[15px] break-words whitespace-pre-wrap">
          <span className="mr-2 font-semibold">{author?.display_name ?? 'Former member'}</span>
          {post.caption}
        </p>
      )}
      {!post.caption && <div className="h-2" />}

      {showComments && (
        <Comments postId={post.id} onCountChange={(d) => onChange({ comment_count: Math.max(0, post.comment_count + d) })} />
      )}

      <ConfirmDialog
        open={confirmDelete}
        onClose={() => setConfirmDelete(false)}
        title="Delete this post?"
        confirmLabel="Delete post"
        onConfirm={deletePost}
      >
        The photo, its likes and comments will be removed for everyone.
      </ConfirmDialog>
    </article>
  )
}
