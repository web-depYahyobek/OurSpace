import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import { CalendarDays, ImagePlus, Images, Pin, Plus } from 'lucide-react'
import { useMe } from '../../contexts/AuthContext'
import { useCurrentGroup, useGroup } from '../../contexts/GroupContext'
import { supabase } from '../../lib/supabase'
import { formatDateTime, timeUntil } from '../../lib/format'
import type { Announcement, GroupEvent } from '../../lib/types'
import { Alert } from '../../components/ui/Alert'
import { Avatar } from '../../components/ui/Avatar'
import { Button } from '../../components/ui/Button'
import { EmptyState } from '../../components/ui/EmptyState'
import { SkeletonCard } from '../../components/ui/Spinner'
import { NewPostModal } from './NewPostModal'
import { PostCard } from './PostCard'
import { usePosts } from './usePosts'

export function FeedPage() {
  const me = useMe()
  const group = useCurrentGroup()
  const feed = usePosts(group.id, me.id)
  const [composing, setComposing] = useState(false)

  return (
    <div className="space-y-5">
      <h1 className="sr-only">{group.name} home</h1>
      <MembersStrip />
      <Highlights groupId={group.id} />

      <button
        onClick={() => setComposing(true)}
        className="card flex w-full items-center gap-3 p-3 text-left transition-colors hover:border-line-strong hover:bg-surface-2"
      >
        <Avatar profile={me} />
        <span className="flex-1 text-muted">Share a photo with the group…</span>
        <span className="flex size-10 items-center justify-center rounded-xl bg-brand-600 text-white shadow-glow">
          <ImagePlus className="size-5" aria-hidden />
        </span>
      </button>

      {feed.error && (
        <Alert action={<Button size="sm" variant="secondary" onClick={() => void feed.reload()}>Retry</Button>}>{feed.error}</Alert>
      )}

      {feed.loading ? (
        <div className="space-y-5">
          <SkeletonCard media lines={2} />
          <SkeletonCard media lines={1} />
        </div>
      ) : feed.posts.length === 0 && !feed.error ? (
        <EmptyState
          icon={Images}
          title="No posts yet"
          action={
            <Button icon={<ImagePlus className="size-4" />} onClick={() => setComposing(true)}>
              Share the first photo
            </Button>
          }
        >
          Photos your group shares will show up here, newest first.
        </EmptyState>
      ) : (
        <div className="space-y-5">
          {feed.posts.map((post) => (
            <PostCard
              key={post.id}
              post={post}
              onChange={(patch) => feed.update(post.id, patch)}
              onDeleted={() => feed.remove(post.id)}
            />
          ))}
          {feed.hasMore && (
            <Button variant="secondary" className="w-full" loading={feed.loadingMore} onClick={() => void feed.loadMore()}>
              Load older posts
            </Button>
          )}
        </div>
      )}

      <NewPostModal open={composing} onClose={() => setComposing(false)} onCreated={feed.prepend} />
    </div>
  )
}

function MembersStrip() {
  const { members, isAdmin } = useGroup()
  if (members.length === 0) return null
  return (
    <section aria-label="Members" className="-mx-4 lg:mx-0">
      <ul className="scrollbar-none flex gap-4 overflow-x-auto px-4 pb-1 lg:px-0">
        {isAdmin && (
          <li>
            <Link to="/members" className="flex w-16 flex-col items-center gap-1.5 text-center">
              <span className="flex size-14 items-center justify-center rounded-full border-2 border-dashed border-brand-500/60 bg-brand-600/10 text-brand-400">
                <Plus className="size-6" aria-hidden />
              </span>
              <span className="w-full truncate text-xs text-muted">Invite</span>
            </Link>
          </li>
        )}
        {members.map((m) => (
          <li key={m.id} className="flex w-16 flex-col items-center gap-1.5 text-center">
            <Avatar profile={m.profile} size="lg" ring />
            <span className="w-full truncate text-xs text-muted">{m.profile.display_name.split(' ')[0]}</span>
          </li>
        ))}
      </ul>
    </section>
  )
}

function Highlights({ groupId }: { groupId: string }) {
  const [pinned, setPinned] = useState<Announcement | null>(null)
  const [nextEvent, setNextEvent] = useState<GroupEvent | null>(null)

  useEffect(() => {
    let active = true
    void Promise.all([
      supabase
        .from('announcements')
        .select('*')
        .eq('group_id', groupId)
        .eq('is_pinned', true)
        .order('created_at', { ascending: false })
        .limit(1)
        .maybeSingle(),
      supabase
        .from('events')
        .select('*')
        .eq('group_id', groupId)
        .gte('starts_at', new Date().toISOString())
        .order('starts_at', { ascending: true })
        .limit(1)
        .maybeSingle(),
    ]).then(([a, e]) => {
      if (!active) return
      setPinned((a.data as Announcement | null) ?? null)
      setNextEvent((e.data as GroupEvent | null) ?? null)
    })
    return () => {
      active = false
    }
  }, [groupId])

  if (!pinned && !nextEvent) return null

  return (
    <div className="grid gap-3 sm:grid-cols-2">
      {pinned && (
        <Link
          to="/announcements"
          className="card group flex gap-3 border-brand-500/30 bg-gradient-to-br from-brand-600/15 to-surface p-4 transition-colors hover:border-brand-500/60 sm:col-span-1"
        >
          <Pin className="mt-0.5 size-5 shrink-0 text-brand-400" aria-hidden />
          <span className="min-w-0">
            <span className="block text-xs font-medium text-brand-300">Pinned</span>
            <span className="block truncate font-semibold">{pinned.title}</span>
            <span className="line-clamp-2 text-sm text-muted">{pinned.body}</span>
          </span>
        </Link>
      )}
      {nextEvent && (
        <Link
          to={`/events?open=${nextEvent.id}`}
          className="card flex gap-3 p-4 transition-colors hover:border-line-strong hover:bg-surface-2"
        >
          <CalendarDays className="mt-0.5 size-5 shrink-0 text-brand-400" aria-hidden />
          <span className="min-w-0">
            <span className="block text-xs font-medium text-brand-300">Next up · {timeUntil(nextEvent.starts_at)}</span>
            <span className="block truncate font-semibold">{nextEvent.title}</span>
            <span className="block truncate text-sm text-muted">{formatDateTime(nextEvent.starts_at)}</span>
          </span>
        </Link>
      )}
    </div>
  )
}
