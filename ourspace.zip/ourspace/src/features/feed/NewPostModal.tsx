import { useState, type FormEvent } from 'react'
import { useMe } from '../../contexts/AuthContext'
import { useCurrentGroup } from '../../contexts/GroupContext'
import { useToast } from '../../contexts/ToastContext'
import { supabase } from '../../lib/supabase'
import { friendlyError } from '../../lib/errors'
import { MEDIA_BUCKET, groupMediaPath, removeFile, uploadImage } from '../../lib/media'
import type { Post } from '../../lib/types'
import { Alert } from '../../components/ui/Alert'
import { Button } from '../../components/ui/Button'
import { TextAreaField } from '../../components/ui/Field'
import { ImagePicker, UploadProgress } from '../../components/ui/ImagePicker'
import { Modal } from '../../components/ui/Modal'

export function NewPostModal({ open, onClose, onCreated }: { open: boolean; onClose: () => void; onCreated: (post: Post) => void }) {
  return (
    <Modal open={open} onClose={onClose} title="Share a photo">
      <NewPostForm onDone={onClose} onCreated={onCreated} />
    </Modal>
  )
}

function NewPostForm({ onDone, onCreated }: { onDone: () => void; onCreated: (post: Post) => void }) {
  const me = useMe()
  const group = useCurrentGroup()
  const toast = useToast()
  const [file, setFile] = useState<File | null>(null)
  const [caption, setCaption] = useState('')
  const [progress, setProgress] = useState<number | null>(null)
  const [error, setError] = useState<string | null>(null)

  const submit = async (e: FormEvent) => {
    e.preventDefault()
    if (!file) {
      setError('Choose a photo to share.')
      return
    }
    setError(null)
    setProgress(0)
    const path = groupMediaPath(group.id, me.id, file)
    try {
      await uploadImage({ bucket: MEDIA_BUCKET, path, file, onProgress: setProgress })
      const { data, error: err } = await supabase
        .from('posts')
        .insert({ group_id: group.id, author_id: me.id, caption: caption.trim() || null, image_path: path })
        .select('*')
        .single()
      if (err) {
        await removeFile(MEDIA_BUCKET, path).catch(() => undefined)
        throw err
      }
      onCreated(data as Post)
      toast('Photo shared')
      onDone()
    } catch (err) {
      setProgress(null)
      setError(friendlyError(err, 'Upload failed. Please try again.'))
    }
  }

  const busy = progress !== null

  return (
    <form onSubmit={submit} className="space-y-4">
      {error && <Alert>{error}</Alert>}
      <ImagePicker file={file} onChange={setFile} disabled={busy} />
      <TextAreaField
        label="Caption"
        optional
        rows={3}
        maxLength={2200}
        value={caption}
        disabled={busy}
        onChange={(e) => setCaption(e.target.value)}
        placeholder="What's happening?"
      />
      {busy && <UploadProgress value={progress} />}
      <div className="flex flex-col-reverse gap-2 sm:flex-row sm:justify-end">
        <Button variant="secondary" onClick={onDone} disabled={busy}>
          Cancel
        </Button>
        <Button type="submit" loading={busy} disabled={!file}>
          Share
        </Button>
      </div>
    </form>
  )
}
