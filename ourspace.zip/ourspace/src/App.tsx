import { BrowserRouter, Navigate, Outlet, Route, Routes, useLocation } from 'react-router-dom'
import { AuthProvider, useAuth } from './contexts/AuthContext'
import { GroupProvider, useGroup } from './contexts/GroupContext'
import { ToastProvider } from './contexts/ToastContext'
import { isSupabaseConfigured } from './lib/supabase'
import { safeNext } from './lib/navigation'
import { AppShell } from './components/layout/AppShell'
import { Alert } from './components/ui/Alert'
import { Button } from './components/ui/Button'
import { PageLoader } from './components/ui/Spinner'
import { SetupNeeded } from './features/SetupNeeded'
import { NotFoundPage } from './features/NotFoundPage'
import { WelcomePage } from './features/auth/WelcomePage'
import { SignInPage } from './features/auth/SignInPage'
import { SignUpPage } from './features/auth/SignUpPage'
import { ProfileSetupPage } from './features/profile/ProfileSetupPage'
import { ProfilePage } from './features/profile/ProfilePage'
import { OnboardingPage } from './features/groups/OnboardingPage'
import { JoinPage } from './features/groups/JoinPage'
import { MembersPage } from './features/groups/MembersPage'
import { FeedPage } from './features/feed/FeedPage'
import { GalleryPage } from './features/feed/GalleryPage'
import { ChatPage } from './features/chat/ChatPage'
import { PollsPage } from './features/polls/PollsPage'
import { EventsPage } from './features/events/EventsPage'
import { AnnouncementsPage } from './features/announcements/AnnouncementsPage'

export default function App() {
  if (!isSupabaseConfigured) return <SetupNeeded />

  return (
    <BrowserRouter>
      <ToastProvider>
        <AuthProvider>
          <GroupProvider>
            <Routes>
              <Route element={<PublicOnly />}>
                <Route path="/welcome" element={<WelcomePage />} />
                <Route path="/sign-in" element={<SignInPage />} />
                <Route path="/sign-up" element={<SignUpPage />} />
              </Route>

              <Route element={<RequireAuth />}>
                <Route path="/setup-profile" element={<ProfileSetupPage />} />
                <Route element={<RequireProfile />}>
                  <Route path="/join/:code" element={<JoinPage />} />
                  <Route path="/onboarding" element={<OnboardingPage />} />
                  <Route element={<RequireGroup />}>
                    <Route element={<AppShell />}>
                      <Route index element={<FeedPage />} />
                      <Route path="chat" element={<ChatPage />} />
                      <Route path="photos" element={<GalleryPage />} />
                      <Route path="polls" element={<PollsPage />} />
                      <Route path="events" element={<EventsPage />} />
                      <Route path="announcements" element={<AnnouncementsPage />} />
                      <Route path="members" element={<MembersPage />} />
                      <Route path="profile" element={<ProfilePage />} />
                    </Route>
                  </Route>
                </Route>
              </Route>

              <Route path="*" element={<NotFoundPage />} />
            </Routes>
          </GroupProvider>
        </AuthProvider>
      </ToastProvider>
    </BrowserRouter>
  )
}

// These guards shape the navigation only. Data access is enforced by the
// database's Row Level Security policies, not here.

function PublicOnly() {
  const { session, loading } = useAuth()
  const location = useLocation()
  if (loading) return <PageLoader />
  if (session) return <Navigate to={safeNext(location.search)} replace />
  return <Outlet />
}

function RequireAuth() {
  const { session, loading } = useAuth()
  const location = useLocation()
  if (loading) return <PageLoader />
  if (!session) {
    if (location.pathname === '/') return <Navigate to="/welcome" replace />
    const next = encodeURIComponent(location.pathname + location.search)
    return <Navigate to={`/sign-in?next=${next}`} replace />
  }
  return <Outlet />
}

function RequireProfile() {
  const { profile, profileError, refreshProfile } = useAuth()
  const location = useLocation()
  if (profileError) {
    return (
      <div className="mx-auto max-w-md p-6 pt-24">
        <Alert action={<Button size="sm" variant="secondary" onClick={() => void refreshProfile()}>Retry</Button>}>
          {profileError}
        </Alert>
      </div>
    )
  }
  if (!profile) {
    const next = encodeURIComponent(location.pathname + location.search)
    return <Navigate to={`/setup-profile?next=${next}`} replace />
  }
  return <Outlet />
}

function RequireGroup() {
  const { loading, group, error, refresh } = useGroup()
  if (loading) return <PageLoader label="Loading your group" />
  if (error && !group) {
    return (
      <div className="mx-auto max-w-md p-6 pt-24">
        <Alert action={<Button size="sm" variant="secondary" onClick={() => void refresh()}>Retry</Button>}>{error}</Alert>
      </div>
    )
  }
  if (!group) return <Navigate to="/onboarding" replace />
  return <Outlet />
}
