import { useEffect, useState } from 'react'
import { SUPABASE_ANON_KEY, SUPABASE_URL, supabase } from './supabase'

export const MEDIA_BUCKET = 'group-media'
export const AVATAR_BUCKET = 'avatars'

export const IMAGE_TYPES = ['image/jpeg', 'image/png', 'image/webp', 'image/gif']
export const AVATAR_TYPES = ['image/jpeg', 'image/png', 'image/webp']
export const MAX_IMAGE_BYTES = 10 * 1024 * 1024
export const MAX_AVATAR_BYTES = 2 * 1024 * 1024

const EXTENSIONS: Record<string, string> = {
  'image/jpeg': 'jpg',
  'image/png': 'png',
  'image/webp': 'webp',
  'image/gif': 'gif',
}

/** Returns an error message, or null when the file is acceptable. These limits match the bucket settings. */
export function validateImage(
  file: File,
  { types = IMAGE_TYPES, maxBytes = MAX_IMAGE_BYTES }: { types?: string[]; maxBytes?: number } = {},
): string | null {
  if (!types.includes(file.type)) {
    const names = types.map((t) => EXTENSIONS[t]?.toUpperCase()).join(', ')
    return `Please choose an image file (${names}).`
  }
  if (file.size > maxBytes) {
    return `That image is ${(file.size / 1024 / 1024).toFixed(1)} MB. The limit is ${Math.round(maxBytes / 1024 / 1024)} MB.`
  }
  return null
}

/** '<group>/<user>/<random>.<ext>': the folder layout the storage policies expect. */
export function groupMediaPath(groupId: string, userId: string, file: File): string {
  return `${groupId}/${userId}/${crypto.randomUUID()}.${EXTENSIONS[file.type] ?? 'bin'}`
}

export function avatarPath(userId: string, file: File): string {
  return `${userId}/${crypto.randomUUID()}.${EXTENSIONS[file.type] ?? 'bin'}`
}

/**
 * Uploads straight to the Storage REST endpoint with XMLHttpRequest, because
 * supabase-js does not report upload progress. Same auth and policies apply.
 */
export async function uploadImage(opts: {
  bucket: string
  path: string
  file: File
  onProgress?: (fraction: number) => void
  signal?: AbortSignal
}): Promise<void> {
  const { data } = await supabase.auth.getSession()
  const token = data.session?.access_token
  if (!token) throw new Error('Your session expired. Please sign in again.')

  const encodedPath = opts.path.split('/').map(encodeURIComponent).join('/')
  const url = `${SUPABASE_URL}/storage/v1/object/${opts.bucket}/${encodedPath}`

  await new Promise<void>((resolve, reject) => {
    const xhr = new XMLHttpRequest()
    xhr.open('POST', url)
    xhr.setRequestHeader('Authorization', `Bearer ${token}`)
    xhr.setRequestHeader('apikey', SUPABASE_ANON_KEY)
    xhr.setRequestHeader('x-upsert', 'false')
    xhr.setRequestHeader('cache-control', 'max-age=3600')
    xhr.setRequestHeader('Content-Type', opts.file.type)

    xhr.upload.onprogress = (e) => {
      if (e.lengthComputable) opts.onProgress?.(e.loaded / e.total)
    }
    xhr.onload = () => {
      if (xhr.status >= 200 && xhr.status < 300) {
        opts.onProgress?.(1)
        resolve()
        return
      }
      let message = `Upload failed (${xhr.status}).`
      try {
        const body = JSON.parse(xhr.responseText) as { message?: string; error?: string }
        message = body.message || body.error || message
      } catch {
        /* keep the generic message */
      }
      if (xhr.status === 413) message = 'That file is too large.'
      if (xhr.status === 403) message = 'You do not have permission to upload here.'
      reject(new Error(message))
    }
    xhr.onerror = () => reject(new Error('Failed to fetch'))
    xhr.onabort = () => reject(new DOMException('Upload cancelled', 'AbortError'))
    opts.signal?.addEventListener('abort', () => xhr.abort(), { once: true })

    xhr.send(opts.file)
  })
}

export async function removeFile(bucket: string, path: string): Promise<void> {
  await supabase.storage.from(bucket).remove([path])
}

// ---------------------------------------------------------------------------
// Signed URLs: private buckets are read through short-lived links. Requests
// made in the same tick are batched into one createSignedUrls call, and links
// are cached until shortly before they expire.
// ---------------------------------------------------------------------------
const SIGNED_URL_TTL = 60 * 60 // seconds
const cache = new Map<string, { url: string; expiresAt: number }>()
type Waiter = { resolve: (url: string | null) => void }
const queue = new Map<string, Map<string, Waiter[]>>()
let flushScheduled = false

function flush() {
  flushScheduled = false
  const batches = Array.from(queue.entries())
  queue.clear()
  for (const [bucket, byPath] of batches) {
    const paths = Array.from(byPath.keys())
    supabase.storage
      .from(bucket)
      .createSignedUrls(paths, SIGNED_URL_TTL)
      .then(({ data, error }) => {
        const results = new Map<string, string>()
        if (!error && data) {
          for (const item of data) {
            if (item.path && item.signedUrl && !item.error) results.set(item.path, item.signedUrl)
          }
        }
        for (const [path, waiters] of byPath) {
          const url = results.get(path) ?? null
          if (url) cache.set(`${bucket}:${path}`, { url, expiresAt: Date.now() + (SIGNED_URL_TTL - 120) * 1000 })
          waiters.forEach((w) => w.resolve(url))
        }
      })
      .catch(() => {
        for (const waiters of byPath.values()) waiters.forEach((w) => w.resolve(null))
      })
  }
}

export function getSignedUrl(bucket: string, path: string): Promise<string | null> {
  const hit = cache.get(`${bucket}:${path}`)
  if (hit && hit.expiresAt > Date.now()) return Promise.resolve(hit.url)
  return new Promise((resolve) => {
    let byPath = queue.get(bucket)
    if (!byPath) queue.set(bucket, (byPath = new Map()))
    const waiters = byPath.get(path) ?? []
    waiters.push({ resolve })
    byPath.set(path, waiters)
    if (!flushScheduled) {
      flushScheduled = true
      setTimeout(flush, 0)
    }
  })
}

export function peekSignedUrl(bucket: string, path: string): string | null {
  const hit = cache.get(`${bucket}:${path}`)
  return hit && hit.expiresAt > Date.now() ? hit.url : null
}

/** Resolves a private storage path to a temporary URL. */
export function useSignedUrl(bucket: string, path: string | null | undefined) {
  const [state, setState] = useState<{ url: string | null; failed: boolean }>(() => ({
    url: path ? peekSignedUrl(bucket, path) : null,
    failed: false,
  }))

  useEffect(() => {
    if (!path) {
      setState({ url: null, failed: false })
      return
    }
    const cached = peekSignedUrl(bucket, path)
    if (cached) {
      setState({ url: cached, failed: false })
      return
    }
    let active = true
    setState({ url: null, failed: false })
    getSignedUrl(bucket, path).then((url) => {
      if (active) setState({ url, failed: url === null })
    })
    return () => {
      active = false
    }
  }, [bucket, path])

  return { url: state.url, failed: state.failed, loading: !!path && !state.url && !state.failed }
}
