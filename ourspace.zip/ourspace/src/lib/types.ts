// Row types for the tables in supabase/migrations. Kept by hand so the app
// builds without the Supabase CLI; regenerate with `supabase gen types` if
// you prefer generated types.

export type GroupRole = 'owner' | 'admin' | 'member'
export type RsvpStatus = 'going' | 'maybe' | 'not_going'

export interface Profile {
  id: string
  username: string
  display_name: string
  avatar_path: string | null
  created_at: string
  updated_at: string
}

export type ProfileSummary = Pick<Profile, 'id' | 'username' | 'display_name' | 'avatar_path'>

export interface Group {
  id: string
  name: string
  description: string | null
  owner_id: string
  members_can_announce: boolean
  created_at: string
}

export interface GroupMember {
  id: string
  group_id: string
  user_id: string
  role: GroupRole
  joined_at: string
  profile: ProfileSummary
}

export interface GroupInvite {
  id: string
  group_id: string
  code: string
  created_by: string
  created_at: string
  expires_at: string | null
  max_uses: number | null
  use_count: number
  revoked_at: string | null
}

export interface InvitePreview {
  group_id: string
  group_name: string
  group_description: string | null
  member_count: number
  already_member: boolean
}

export interface Message {
  id: string
  group_id: string
  sender_id: string
  body: string | null
  attachment_path: string | null
  created_at: string
}

export interface Post {
  id: string
  group_id: string
  author_id: string
  caption: string | null
  image_path: string
  created_at: string
}

export interface PostWithStats extends Post {
  like_count: number
  comment_count: number
  liked_by_me: boolean
}

export interface Comment {
  id: string
  post_id: string
  author_id: string
  body: string
  created_at: string
}

export interface Poll {
  id: string
  group_id: string
  creator_id: string
  question: string
  ends_at: string | null
  is_closed: boolean
  show_results_before_vote: boolean
  created_at: string
}

export interface PollOption {
  id: string
  poll_id: string
  option_text: string
  position: number
}

export interface PollVote {
  id: string
  poll_id: string
  option_id: string
  user_id: string
}

export interface PollWithDetails extends Poll {
  poll_options: PollOption[]
  poll_votes: PollVote[]
}

export interface GroupEvent {
  id: string
  group_id: string
  creator_id: string
  title: string
  description: string | null
  starts_at: string
  ends_at: string | null
  location: string | null
  created_at: string
}

export interface EventRsvp {
  id: string
  event_id: string
  user_id: string
  status: RsvpStatus
  updated_at: string
}

export interface EventWithRsvps extends GroupEvent {
  event_rsvps: EventRsvp[]
}

export interface Announcement {
  id: string
  group_id: string
  author_id: string
  title: string
  body: string
  is_pinned: boolean
  created_at: string
  updated_at: string
}
