/** Where to go after signing in: a safe in-app path from ?next=, else home. */
export function safeNext(search: string): string {
  const next = new URLSearchParams(search).get('next')
  return next && next.startsWith('/') && !next.startsWith('//') && !next.startsWith('/\\') ? next : '/'
}
