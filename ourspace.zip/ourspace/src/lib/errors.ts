/** Turns Supabase/Postgres/network errors into a sentence a person can act on. */
export function friendlyError(error: unknown, fallback = 'Something went wrong. Please try again.'): string {
  if (!error) return fallback
  const e = error as { message?: string; code?: string; status?: number; name?: string }
  const msg = e.message ?? (typeof error === 'string' ? error : '')

  if (e.name === 'TypeError' && /fetch/i.test(msg)) return 'Could not reach the server. Check your connection and try again.'
  if (/Failed to fetch|NetworkError|Load failed/i.test(msg)) return 'Could not reach the server. Check your connection and try again.'

  // Auth
  if (/Invalid login credentials/i.test(msg)) return 'That email and password do not match.'
  if (/Email not confirmed/i.test(msg)) return 'Please confirm your email first. Check your inbox for the link.'
  if (/User already registered/i.test(msg)) return 'An account with this email already exists. Try signing in.'
  if (/Password should be at least/i.test(msg)) return msg
  if (/rate limit/i.test(msg)) return 'Too many attempts. Please wait a minute and try again.'

  // Postgres
  switch (e.code) {
    case '23505':
      if (/username/i.test(msg)) return 'That username is taken. Try another one.'
      if (/post_likes/i.test(msg)) return 'You already liked this.'
      return 'That already exists.'
    case '23514':
      if (/username/i.test(msg)) return 'Usernames use 3–20 lowercase letters, numbers or underscores.'
      if (/end_after_start/i.test(msg)) return 'The end time must be after the start time.'
      return 'Some of the details are not valid. Please check and try again.'
    case '42501':
      return /pin/i.test(msg) ? msg : 'You do not have permission to do that.'
    case 'P0001':
      return msg
    case 'PGRST301':
    case '28000':
      return 'Your session expired. Please sign in again.'
  }
  if (/row-level security/i.test(msg)) return 'You do not have permission to do that.'
  if (/permission denied/i.test(msg)) return 'You do not have permission to do that.'
  if (/Payload too large|exceeded the maximum allowed size/i.test(msg)) return 'That file is too large.'
  if (/mime type .* is not supported/i.test(msg)) return 'That file type is not supported.'

  return msg || fallback
}
