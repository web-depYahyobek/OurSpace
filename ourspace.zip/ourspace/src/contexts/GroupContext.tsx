import { createContext, useCallback, useContext, useEffect, useMemo, useState, type ReactNode } from 'react'
import { supabase } from '../lib/supabase'
import { friendlyError } from '../lib/errors'
import type { Group, GroupMember, GroupRole, ProfileSummary } from '../lib/types'
import { useAuth } from './AuthContext'

const STORAGE_KEY = 'ourspace.groupId'

interface Membership {
  role: GroupRole
  group: Group
}

interface GroupState {
  loading: boolean
  error: string | null
  memberships: Membership[]
  group: Group | null
  role: GroupRole | null
  isAdmin: boolean
  isOwner: boolean
  members: GroupMember[]
  /** Look up a member's profile by user id (for chat, posts, comments...). */
  profileOf: (userId: string) => ProfileSummary | null
  selectGroup: (groupId: string) => void
  refresh: () => Promise<void>
  refreshMembers: () => Promise<void>
}

const GroupContext = createContext<GroupState | null>(null)

function readStoredGroupId(): string | null {
  try {
    return localStorage.getItem(STORAGE_KEY)
  } catch {
    return null
  }
}

export function GroupProvider({ children }: { children: ReactNode }) {
  const { user, profile } = useAuth()
  const userId = user?.id ?? null

  const [memberships, setMemberships] = useState<Membership[]>([])
  const [loadedFor, setLoadedFor] = useState<string | null>(null)
  const [error, setError] = useState<string | null>(null)
  const [selectedId, setSelectedId] = useState<string | null>(readStoredGroupId)
  const [members, setMembers] = useState<GroupMember[]>([])

  const loadMemberships = useCallback(async (uid: string) => {
    const { data, error: err } = await supabase
      .from('group_members')
      .select('role, group:groups(*)')
      .eq('user_id', uid)
      .order('joined_at', { ascending: true })
    if (err) {
      setError(friendlyError(err))
    } else {
      setError(null)
      const rows = (data ?? []) as unknown as Array<{ role: GroupRole; group: Group | null }>
      setMemberships(rows.filter((r): r is Membership => r.group !== null))
    }
    setLoadedFor(uid)
  }, [])

  useEffect(() => {
    if (!userId || !profile) {
      setMemberships([])
      setLoadedFor(null)
      return
    }
    void loadMemberships(userId)
  }, [userId, profile, loadMemberships])

  // Membership can change elsewhere (removed by an admin, joined on another
  // device), so re-check when the tab regains focus.
  useEffect(() => {
    if (!userId || !profile) return
    const onFocus = () => void loadMemberships(userId)
    window.addEventListener('focus', onFocus)
    return () => window.removeEventListener('focus', onFocus)
  }, [userId, profile, loadMemberships])

  const current = memberships.find((m) => m.group.id === selectedId) ?? memberships[0] ?? null
  const groupId = current?.group.id ?? null

  const loadMembers = useCallback(async (gid: string) => {
    const { data, error: err } = await supabase
      .from('group_members')
      .select('id, group_id, user_id, role, joined_at, profile:profiles(id, username, display_name, avatar_path)')
      .eq('group_id', gid)
      .order('joined_at', { ascending: true })
    if (err) {
      setError(friendlyError(err))
      return
    }
    setMembers(((data ?? []) as unknown as GroupMember[]).filter((m) => m.profile))
  }, [])

  useEffect(() => {
    if (!groupId) {
      setMembers([])
      return
    }
    void loadMembers(groupId)
  }, [groupId, loadMembers])

  const selectGroup = useCallback((id: string) => {
    setSelectedId(id)
    try {
      localStorage.setItem(STORAGE_KEY, id)
    } catch {
      /* storage unavailable */
    }
  }, [])

  const refresh = useCallback(async () => {
    if (userId) await loadMemberships(userId)
  }, [userId, loadMemberships])

  const refreshMembers = useCallback(async () => {
    if (groupId) await loadMembers(groupId)
  }, [groupId, loadMembers])

  const byId = useMemo(() => new Map(members.map((m) => [m.user_id, m.profile])), [members])
  const profileOf = useCallback(
    (id: string) => {
      if (profile && id === profile.id) return profile
      return byId.get(id) ?? null
    },
    [byId, profile],
  )

  const role = current?.role ?? null
  const loading = !!userId && !!profile && loadedFor !== userId

  const value = useMemo<GroupState>(
    () => ({
      loading,
      error,
      memberships,
      group: current?.group ?? null,
      role,
      isAdmin: role === 'owner' || role === 'admin',
      isOwner: role === 'owner',
      members,
      profileOf,
      selectGroup,
      refresh,
      refreshMembers,
    }),
    [loading, error, memberships, current, role, members, profileOf, selectGroup, refresh, refreshMembers],
  )

  return <GroupContext.Provider value={value}>{children}</GroupContext.Provider>
}

export function useGroup(): GroupState {
  const ctx = useContext(GroupContext)
  if (!ctx) throw new Error('useGroup must be used inside <GroupProvider>')
  return ctx
}

/** For screens rendered inside the app shell, where a group is guaranteed. */
export function useCurrentGroup(): Group {
  const { group } = useGroup()
  if (!group) throw new Error('useCurrentGroup called without a group')
  return group
}
