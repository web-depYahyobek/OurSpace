import { createContext, useCallback, useContext, useEffect, useMemo, useState, type ReactNode } from 'react'
import type { Session, User } from '@supabase/supabase-js'
import { supabase } from '../lib/supabase'
import { friendlyError } from '../lib/errors'
import type { Profile } from '../lib/types'

interface AuthState {
  session: Session | null
  user: User | null
  profile: Profile | null
  /** True until we know whether someone is signed in and have loaded their profile. */
  loading: boolean
  profileError: string | null
  refreshProfile: () => Promise<void>
  signOut: () => Promise<void>
}

const AuthContext = createContext<AuthState | null>(null)

export function AuthProvider({ children }: { children: ReactNode }) {
  const [session, setSession] = useState<Session | null>(null)
  const [sessionLoaded, setSessionLoaded] = useState(false)
  const [profile, setProfile] = useState<Profile | null>(null)
  const [profileLoadedFor, setProfileLoadedFor] = useState<string | null>(null)
  const [profileError, setProfileError] = useState<string | null>(null)

  useEffect(() => {
    supabase.auth.getSession().then(({ data }) => {
      setSession(data.session)
      setSessionLoaded(true)
    })
    // Only set state here: calling Supabase inside this callback can deadlock.
    const { data } = supabase.auth.onAuthStateChange((_event, next) => {
      setSession(next)
      setSessionLoaded(true)
    })
    return () => data.subscription.unsubscribe()
  }, [])

  const userId = session?.user.id ?? null

  const loadProfile = useCallback(async (uid: string) => {
    const { data, error } = await supabase.from('profiles').select('*').eq('id', uid).maybeSingle()
    if (error) {
      setProfileError(friendlyError(error))
    } else {
      setProfileError(null)
      setProfile((data as Profile | null) ?? null)
    }
    setProfileLoadedFor(uid)
  }, [])

  useEffect(() => {
    if (!userId) {
      setProfile(null)
      setProfileLoadedFor(null)
      return
    }
    void loadProfile(userId)
  }, [userId, loadProfile])

  const refreshProfile = useCallback(async () => {
    if (userId) await loadProfile(userId)
  }, [userId, loadProfile])

  const signOut = useCallback(async () => {
    await supabase.auth.signOut()
    try {
      localStorage.removeItem('ourspace.groupId')
    } catch {
      /* storage unavailable */
    }
  }, [])

  const loading = !sessionLoaded || (!!userId && profileLoadedFor !== userId)

  const value = useMemo<AuthState>(
    () => ({ session, user: session?.user ?? null, profile, loading, profileError, refreshProfile, signOut }),
    [session, profile, loading, profileError, refreshProfile, signOut],
  )

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>
}

export function useAuth(): AuthState {
  const ctx = useContext(AuthContext)
  if (!ctx) throw new Error('useAuth must be used inside <AuthProvider>')
  return ctx
}

/** For screens that only render once a profile exists (guarded by routing). */
export function useMe(): Profile {
  const { profile } = useAuth()
  if (!profile) throw new Error('useMe called without a profile')
  return profile
}
