import { useEffect, useRef, type ReactNode } from 'react'
import { X } from 'lucide-react'
import { cn } from '../../lib/cn'

/**
 * Accessible modal built on <dialog>: focus is trapped and Escape closes it.
 * On phones it opens as a bottom sheet.
 */
export function Modal({
  open,
  onClose,
  title,
  children,
  size = 'md',
  bare = false,
}: {
  open: boolean
  onClose: () => void
  title: string
  children: ReactNode
  size?: 'md' | 'lg' | 'xl'
  /** Hide the visible header (title is still announced to screen readers). */
  bare?: boolean
}) {
  const ref = useRef<HTMLDialogElement>(null)

  useEffect(() => {
    const dialog = ref.current
    if (!dialog) return
    if (open && !dialog.open) {
      dialog.showModal()
      document.body.style.overflow = 'hidden'
    } else if (!open && dialog.open) {
      dialog.close()
    }
    return () => {
      document.body.style.overflow = ''
    }
  }, [open])

  return (
    <dialog
      ref={ref}
      aria-label={title}
      onCancel={(e) => {
        e.preventDefault()
        onClose()
      }}
      onClick={(e) => {
        if (e.target === ref.current) onClose()
      }}
      className={cn(
        'fixed inset-x-0 bottom-0 top-auto m-0 mx-auto max-h-[92dvh] w-full max-w-none overflow-hidden rounded-t-3xl border border-line bg-surface p-0 text-ink shadow-2xl',
        'backdrop:bg-black/70 backdrop:backdrop-blur-sm open:animate-rise',
        'sm:inset-0 sm:m-auto sm:h-fit sm:w-[calc(100%-2rem)] sm:rounded-3xl',
        size === 'md' && 'sm:max-w-lg',
        size === 'lg' && 'sm:max-w-2xl',
        size === 'xl' && 'sm:max-w-4xl',
      )}
    >
      {open && (
        <div className="flex max-h-[92dvh] flex-col">
          {bare ? (
            <button onClick={onClose} className="icon-btn absolute top-2 right-2 z-10 bg-black/40 text-white" aria-label="Close">
              <X className="size-5" />
            </button>
          ) : (
            <div className="flex items-center justify-between gap-4 border-b border-line px-5 py-3">
              <h2 className="text-lg font-semibold">{title}</h2>
              <button onClick={onClose} className="icon-btn -mr-2" aria-label="Close">
                <X className="size-5" />
              </button>
            </div>
          )}
          <div className={cn('overflow-y-auto', !bare && 'px-5 py-5 pb-safe')}>{children}</div>
        </div>
      )}
    </dialog>
  )
}
