import { cn } from '../../lib/cn'
import { initials } from '../../lib/format'
import { AVATAR_BUCKET, useSignedUrl } from '../../lib/media'
import type { ProfileSummary } from '../../lib/types'

const sizes = {
  xs: 'size-6 text-[10px]',
  sm: 'size-8 text-xs',
  md: 'size-10 text-sm',
  lg: 'size-14 text-lg',
  xl: 'size-20 text-2xl',
}

// Stable per-person fallback colour.
const tints = [
  'from-violet-500 to-fuchsia-600',
  'from-indigo-500 to-violet-600',
  'from-purple-500 to-pink-600',
  'from-fuchsia-500 to-purple-700',
  'from-violet-400 to-indigo-700',
  'from-sky-500 to-violet-600',
]
function tintFor(id: string) {
  let h = 0
  for (let i = 0; i < id.length; i++) h = (h * 31 + id.charCodeAt(i)) | 0
  return tints[Math.abs(h) % tints.length]
}

export function Avatar({
  profile,
  size = 'md',
  ring = false,
  className,
}: {
  profile: ProfileSummary | null | undefined
  size?: keyof typeof sizes
  ring?: boolean
  className?: string
}) {
  const { url } = useSignedUrl(AVATAR_BUCKET, profile?.avatar_path)
  const name = profile?.display_name ?? 'Former member'
  return (
    <span
      className={cn(
        'relative inline-flex shrink-0 items-center justify-center overflow-hidden rounded-full bg-gradient-to-br font-semibold text-white select-none',
        profile ? tintFor(profile.id) : 'from-zinc-600 to-zinc-700',
        ring && 'ring-2 ring-brand-500 ring-offset-2 ring-offset-bg',
        sizes[size],
        className,
      )}
    >
      {url ? <img src={url} alt="" className="size-full object-cover" /> : <span aria-hidden>{initials(name)}</span>}
      <span className="sr-only">{name}</span>
    </span>
  )
}
