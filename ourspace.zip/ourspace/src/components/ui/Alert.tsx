import type { ReactNode } from 'react'
import { CircleAlert, CircleCheck, Info } from 'lucide-react'
import { cn } from '../../lib/cn'

const styles = {
  error: { box: 'border-danger/40 bg-danger/10 text-red-200', icon: CircleAlert, iconClass: 'text-danger' },
  success: { box: 'border-success/30 bg-success/10 text-green-200', icon: CircleCheck, iconClass: 'text-success' },
  info: { box: 'border-brand-500/30 bg-brand-500/10 text-brand-300', icon: Info, iconClass: 'text-brand-400' },
}

export function Alert({
  kind = 'error',
  children,
  action,
  className,
}: {
  kind?: keyof typeof styles
  children: ReactNode
  action?: ReactNode
  className?: string
}) {
  const s = styles[kind]
  const Icon = s.icon
  return (
    <div
      role={kind === 'error' ? 'alert' : 'status'}
      className={cn('flex items-start gap-3 rounded-xl border px-4 py-3 text-sm', s.box, className)}
    >
      <Icon className={cn('mt-0.5 size-4 shrink-0', s.iconClass)} aria-hidden />
      <div className="flex-1">{children}</div>
      {action}
    </div>
  )
}
