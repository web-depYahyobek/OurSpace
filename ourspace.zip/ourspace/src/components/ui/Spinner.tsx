import { LoaderCircle } from 'lucide-react'
import { cn } from '../../lib/cn'

export function Spinner({ className, label = 'Loading' }: { className?: string; label?: string }) {
  return (
    <span role="status" className="inline-flex">
      <LoaderCircle className={cn('size-5 animate-spin text-brand-400', className)} aria-hidden />
      <span className="sr-only">{label}</span>
    </span>
  )
}

export function PageLoader({ label = 'Loading' }: { label?: string }) {
  return (
    <div className="flex min-h-[40vh] items-center justify-center">
      <Spinner className="size-7" label={label} />
    </div>
  )
}

/** Grey placeholder blocks shown while lists load. */
export function SkeletonCard({ lines = 3, media = false }: { lines?: number; media?: boolean }) {
  return (
    <div className="card animate-pulse p-4" aria-hidden>
      <div className="flex items-center gap-3">
        <div className="size-10 rounded-full bg-surface-3" />
        <div className="flex-1 space-y-2">
          <div className="h-3 w-1/3 rounded bg-surface-3" />
          <div className="h-2.5 w-1/5 rounded bg-surface-3" />
        </div>
      </div>
      {media && <div className="mt-4 aspect-[4/3] rounded-xl bg-surface-3" />}
      <div className="mt-4 space-y-2">
        {Array.from({ length: lines }, (_, i) => (
          <div key={i} className="h-2.5 rounded bg-surface-3" style={{ width: `${90 - i * 18}%` }} />
        ))}
      </div>
    </div>
  )
}
