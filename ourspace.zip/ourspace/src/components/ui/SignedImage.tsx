import { useState } from 'react'
import { ImageOff } from 'lucide-react'
import { cn } from '../../lib/cn'
import { MEDIA_BUCKET, useSignedUrl } from '../../lib/media'

/** Shows an image from a private bucket, with a placeholder while the link and pixels load. */
export function SignedImage({
  path,
  alt,
  bucket = MEDIA_BUCKET,
  className,
  imgClassName,
}: {
  path: string
  alt: string
  bucket?: string
  className?: string
  imgClassName?: string
}) {
  const { url, failed } = useSignedUrl(bucket, path)
  const [loaded, setLoaded] = useState(false)
  const [broken, setBroken] = useState(false)

  return (
    <div className={cn('relative overflow-hidden bg-surface-3', className)}>
      {(failed || broken) && (
        <div className="absolute inset-0 flex flex-col items-center justify-center gap-2 text-faint">
          <ImageOff className="size-6" aria-hidden />
          <span className="text-xs">Image unavailable</span>
        </div>
      )}
      {!loaded && !failed && !broken && <div className="absolute inset-0 animate-pulse bg-surface-3" aria-hidden />}
      {url && !broken && (
        <img
          src={url}
          alt={alt}
          loading="lazy"
          decoding="async"
          onLoad={() => setLoaded(true)}
          onError={() => setBroken(true)}
          className={cn('size-full object-cover transition-opacity duration-300', loaded ? 'opacity-100' : 'opacity-0', imgClassName)}
        />
      )}
    </div>
  )
}
