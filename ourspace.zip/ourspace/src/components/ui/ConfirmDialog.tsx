import { useState, type ReactNode } from 'react'
import { friendlyError } from '../../lib/errors'
import { Alert } from './Alert'
import { Button } from './Button'
import { Modal } from './Modal'

/** Asks before a destructive action; shows the error inline if it fails. */
export function ConfirmDialog({
  open,
  onClose,
  title,
  children,
  confirmLabel,
  danger = true,
  onConfirm,
}: {
  open: boolean
  onClose: () => void
  title: string
  children: ReactNode
  confirmLabel: string
  danger?: boolean
  onConfirm: () => Promise<void>
}) {
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState<string | null>(null)

  const close = () => {
    if (busy) return
    setError(null)
    onClose()
  }

  return (
    <Modal open={open} onClose={close} title={title}>
      <div className="space-y-5">
        <div className="text-sm text-muted">{children}</div>
        {error && <Alert>{error}</Alert>}
        <div className="flex flex-col-reverse gap-2 sm:flex-row sm:justify-end">
          <Button variant="secondary" onClick={close} disabled={busy}>
            Cancel
          </Button>
          <Button
            variant={danger ? 'danger' : 'primary'}
            loading={busy}
            onClick={async () => {
              setBusy(true)
              setError(null)
              try {
                await onConfirm()
                setBusy(false)
                onClose()
              } catch (e) {
                setBusy(false)
                setError(friendlyError(e))
              }
            }}
          >
            {confirmLabel}
          </Button>
        </div>
      </div>
    </Modal>
  )
}
