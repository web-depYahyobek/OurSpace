import { useEffect, useId, useRef, useState } from 'react'
import { ImagePlus, X } from 'lucide-react'
import { IMAGE_TYPES, MAX_IMAGE_BYTES, validateImage } from '../../lib/media'

/** Choose one image, preview it, and validate type and size before upload. */
export function ImagePicker({
  file,
  onChange,
  disabled,
  label = 'Photo',
}: {
  file: File | null
  onChange: (file: File | null) => void
  disabled?: boolean
  label?: string
}) {
  const inputId = useId()
  const inputRef = useRef<HTMLInputElement>(null)
  const [error, setError] = useState<string | null>(null)
  const [preview, setPreview] = useState<string | null>(null)

  useEffect(() => {
    if (!file) {
      setPreview(null)
      return
    }
    const url = URL.createObjectURL(file)
    setPreview(url)
    return () => URL.revokeObjectURL(url)
  }, [file])

  const pick = (f: File | undefined) => {
    if (!f) return
    const problem = validateImage(f)
    setError(problem)
    if (!problem) onChange(f)
    if (inputRef.current) inputRef.current.value = ''
  }

  return (
    <div>
      <span className="label" id={`${inputId}-label`}>
        {label}
      </span>
      {preview ? (
        <div className="relative overflow-hidden rounded-2xl border border-line bg-surface-3">
          <img src={preview} alt="Selected photo preview" className="max-h-80 w-full object-contain" />
          {!disabled && (
            <button
              type="button"
              onClick={() => onChange(null)}
              className="icon-btn absolute top-2 right-2 bg-black/60 text-white hover:bg-black/80"
              aria-label="Remove photo"
            >
              <X className="size-5" />
            </button>
          )}
        </div>
      ) : (
        <label
          htmlFor={inputId}
          onDragOver={(e) => e.preventDefault()}
          onDrop={(e) => {
            e.preventDefault()
            pick(e.dataTransfer.files[0])
          }}
          className="flex cursor-pointer flex-col items-center justify-center gap-2 rounded-2xl border-2 border-dashed border-line-strong bg-surface-2 px-4 py-10 text-center transition-colors hover:border-brand-500/60 hover:bg-surface-3 has-[:focus-visible]:border-brand-400"
        >
          <ImagePlus className="size-8 text-brand-400" aria-hidden />
          <span className="text-sm font-medium text-ink">Choose a photo or drop it here</span>
          <span className="text-xs text-faint">JPG, PNG, WebP or GIF · up to {MAX_IMAGE_BYTES / 1024 / 1024} MB</span>
        </label>
      )}
      <input
        ref={inputRef}
        id={inputId}
        type="file"
        accept={IMAGE_TYPES.join(',')}
        className="sr-only"
        disabled={disabled}
        aria-labelledby={`${inputId}-label`}
        onChange={(e) => pick(e.target.files?.[0])}
      />
      {error && <p className="mt-1.5 text-sm text-danger">{error}</p>}
    </div>
  )
}

export function UploadProgress({ value }: { value: number }) {
  const pct = Math.round(value * 100)
  return (
    <div>
      <div className="mb-1 flex justify-between text-xs text-muted">
        <span>{pct < 100 ? 'Uploading…' : 'Saving…'}</span>
        <span>{pct}%</span>
      </div>
      <div className="h-2 overflow-hidden rounded-full bg-surface-3" role="progressbar" aria-valuenow={pct} aria-valuemin={0} aria-valuemax={100}>
        <div className="h-full rounded-full bg-gradient-to-r from-brand-600 to-brand-400 transition-[width] duration-200" style={{ width: `${pct}%` }} />
      </div>
    </div>
  )
}
