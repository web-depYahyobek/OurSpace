import { NavLink, Outlet, Link, useLocation } from 'react-router-dom'
import {
  CalendarDays,
  House,
  Images,
  LogOut,
  Megaphone,
  MessageCircle,
  Users,
  Vote,
  type LucideIcon,
} from 'lucide-react'
import { useAuth, useMe } from '../../contexts/AuthContext'
import { useCurrentGroup, useGroup } from '../../contexts/GroupContext'
import { cn } from '../../lib/cn'
import { Avatar } from '../ui/Avatar'
import { LogoMark } from './Logo'

interface NavItem {
  to: string
  label: string
  icon: LucideIcon
  end?: boolean
}

const primaryNav: NavItem[] = [
  { to: '/', label: 'Home', icon: House, end: true },
  { to: '/chat', label: 'Chat', icon: MessageCircle },
  { to: '/photos', label: 'Photos', icon: Images },
  { to: '/polls', label: 'Polls', icon: Vote },
  { to: '/events', label: 'Events', icon: CalendarDays },
]

const secondaryNav: NavItem[] = [
  { to: '/announcements', label: 'Announcements', icon: Megaphone },
  { to: '/members', label: 'Members', icon: Users },
]

export function AppShell() {
  const me = useMe()
  const group = useCurrentGroup()
  const { members } = useGroup()
  const { signOut } = useAuth()
  const location = useLocation()
  const isChat = location.pathname.startsWith('/chat')

  return (
    <div className="min-h-dvh lg:pl-72">
      <a href="#main" className="sr-only focus:not-sr-only focus:fixed focus:top-2 focus:left-2 focus:z-[70] focus:rounded-lg focus:bg-brand-600 focus:px-3 focus:py-2">
        Skip to content
      </a>

      {/* Desktop sidebar */}
      <aside className="fixed inset-y-0 left-0 z-30 hidden w-72 flex-col border-r border-line bg-surface/80 backdrop-blur-xl lg:flex">
        <div className="flex items-center gap-3 px-5 pt-6 pb-5">
          <LogoMark className="size-10" />
          <div className="min-w-0">
            <p className="truncate font-bold tracking-tight">{group.name}</p>
            <p className="text-xs text-muted">
              {members.length} {members.length === 1 ? 'member' : 'members'} · private
            </p>
          </div>
        </div>
        <nav aria-label="Main" className="flex-1 space-y-1 overflow-y-auto px-3">
          {primaryNav.map((item) => (
            <SideLink key={item.to} item={item} />
          ))}
          <div className="my-3 border-t border-line" />
          {secondaryNav.map((item) => (
            <SideLink key={item.to} item={item} />
          ))}
        </nav>
        <div className="border-t border-line p-3">
          <div className="flex items-center gap-2">
            <Link to="/profile" className="flex min-w-0 flex-1 items-center gap-3 rounded-xl p-2 transition-colors hover:bg-surface-2">
              <Avatar profile={me} size="sm" />
              <span className="min-w-0">
                <span className="block truncate text-sm font-semibold">{me.display_name}</span>
                <span className="block truncate text-xs text-muted">@{me.username}</span>
              </span>
            </Link>
            <button onClick={() => void signOut()} className="icon-btn" aria-label="Sign out" title="Sign out">
              <LogOut className="size-5" />
            </button>
          </div>
        </div>
      </aside>

      {/* Mobile top bar */}
      <header className="sticky top-0 z-30 flex h-14 items-center gap-2 border-b border-line bg-bg/85 px-3 backdrop-blur-xl lg:hidden">
        <Link to="/" className="flex min-w-0 flex-1 items-center gap-2" aria-label={`${group.name} home`}>
          <LogoMark className="size-8 shrink-0" />
          <span className="truncate text-lg font-bold tracking-tight">{group.name}</span>
        </Link>
        <NavLink to="/announcements" className={({ isActive }) => cn('icon-btn', isActive && 'text-brand-400')} aria-label="Announcements">
          <Megaphone className="size-5" />
        </NavLink>
        <NavLink to="/members" className={({ isActive }) => cn('icon-btn', isActive && 'text-brand-400')} aria-label="Members">
          <Users className="size-5" />
        </NavLink>
        <Link to="/profile" className="ml-1 rounded-full" aria-label="Your profile">
          <Avatar profile={me} size="sm" ring={location.pathname === '/profile'} />
        </Link>
      </header>

      <main
        id="main"
        className={cn(
          'mx-auto w-full max-w-3xl px-4 lg:px-8',
          isChat ? 'pt-0 pb-0 lg:pt-0' : 'pt-5 pb-28 lg:pt-10 lg:pb-12',
        )}
      >
        <Outlet />
      </main>

      {/* Mobile bottom navigation */}
      <nav
        aria-label="Main"
        className="fixed inset-x-0 bottom-0 z-30 border-t border-line bg-bg/90 pb-safe backdrop-blur-xl lg:hidden"
      >
        <ul className="mx-auto flex h-16 max-w-md items-stretch justify-around">
          {primaryNav.map(({ to, label, icon: Icon, end }) => (
            <li key={to} className="flex-1">
              <NavLink
                to={to}
                end={end}
                className={({ isActive }) =>
                  cn(
                    'flex h-full flex-col items-center justify-center gap-0.5 text-[11px] font-medium transition-colors',
                    isActive ? 'text-brand-400' : 'text-faint hover:text-ink',
                  )
                }
              >
                {({ isActive }) => (
                  <>
                    <Icon className={cn('size-6', isActive && 'drop-shadow-[0_0_8px_rgb(139_92_246/0.6)]')} aria-hidden />
                    {label}
                  </>
                )}
              </NavLink>
            </li>
          ))}
        </ul>
      </nav>
    </div>
  )
}

function SideLink({ item }: { item: NavItem }) {
  const { to, label, icon: Icon, end } = item
  return (
    <NavLink
      to={to}
      end={end}
      className={({ isActive }) =>
        cn(
          'flex min-h-11 items-center gap-3 rounded-xl px-3 text-sm font-medium transition-colors',
          isActive ? 'bg-brand-600/15 text-ink ring-1 ring-brand-500/30' : 'text-muted hover:bg-surface-2 hover:text-ink',
        )
      }
    >
      {({ isActive }) => (
        <>
          <Icon className={cn('size-5', isActive ? 'text-brand-400' : '')} aria-hidden />
          {label}
        </>
      )}
    </NavLink>
  )
}
