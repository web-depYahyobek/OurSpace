import { useId } from 'react'
import { cn } from '../../lib/cn'

export function LogoMark({ className }: { className?: string }) {
  const id = useId().replace(/:/g, '')
  return (
    <svg viewBox="0 0 64 64" className={cn('size-10', className)} aria-hidden>
      <defs>
        <linearGradient id={`${id}bg`} x1="0" y1="0" x2="1" y2="1">
          <stop offset="0" stopColor="#24154a" />
          <stop offset="1" stopColor="#0e0a1c" />
        </linearGradient>
        <linearGradient id={`${id}rim`} x1="0" y1="0" x2="1" y2="1">
          <stop offset="0" stopColor="#a78bfa" />
          <stop offset="1" stopColor="#6d28d9" />
        </linearGradient>
        <linearGradient id={`${id}ppl`} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#ffffff" />
          <stop offset="1" stopColor="#d4c8ff" />
        </linearGradient>
      </defs>
      <rect x="2" y="2" width="60" height="60" rx="16" fill={`url(#${id}bg)`} stroke={`url(#${id}rim)`} strokeWidth="2.5" />
      <g fill="#c4b5fd" opacity="0.9">
        <circle cx="19" cy="27" r="5" />
        <path d="M10 45.5c0-5.5 4-9.5 9-9.5s9 4 9 9.5V47H10z" />
        <circle cx="45" cy="27" r="5" />
        <path d="M36 45.5c0-5.5 4-9.5 9-9.5s9 4 9 9.5V47H36z" />
      </g>
      <g fill={`url(#${id}ppl)`}>
        <circle cx="32" cy="23.5" r="6.5" />
        <path d="M20 48c0-7.5 5.4-13 12-13s12 5.5 12 13v1.5H20z" />
      </g>
      <path fill="#a78bfa" d="M50 9.5l1.4 3.6 3.6 1.4-3.6 1.4-1.4 3.6-1.4-3.6-3.6-1.4 3.6-1.4z" />
    </svg>
  )
}

export function Wordmark({ className }: { className?: string }) {
  return (
    <span className={cn('flex items-center gap-2.5', className)}>
      <LogoMark className="size-9" />
      <span className="text-lg font-bold tracking-tight">OurSpace</span>
    </span>
  )
}
