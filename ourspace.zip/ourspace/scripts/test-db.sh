#!/usr/bin/env bash
# Runs the migrations and the RLS privacy tests against a throwaway local
# PostgreSQL (no Supabase account needed). Requires PostgreSQL 15+ binaries
# (initdb, pg_ctl, psql) on PATH or in /usr/lib/postgresql/<version>/bin.
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"

if ! command -v initdb >/dev/null 2>&1; then
  PGBIN="$(ls -d /usr/lib/postgresql/*/bin 2>/dev/null | sort -V | tail -1 || true)"
  [ -n "$PGBIN" ] && export PATH="$PGBIN:$PATH"
fi
command -v initdb >/dev/null || { echo "PostgreSQL binaries not found (initdb)"; exit 1; }

TMP="$(mktemp -d)"
PORT="${PGPORT_TEST:-55432}"
cleanup() { pg_ctl -D "$TMP/data" -m immediate stop >/dev/null 2>&1 || true; rm -rf "$TMP"; }
trap cleanup EXIT

initdb -D "$TMP/data" -U postgres --auth=trust >/dev/null
pg_ctl -D "$TMP/data" -o "-p $PORT -k $TMP -c listen_addresses=''" -l "$TMP/log" -w start >/dev/null

PSQL=(psql -h "$TMP" -p "$PORT" -U postgres -d postgres -v ON_ERROR_STOP=1 -q)

"${PSQL[@]}" -f "$ROOT/supabase/tests/supabase_stub.sql"
for f in "$ROOT"/supabase/migrations/*.sql; do
  echo "Applying $(basename "$f")"
  "${PSQL[@]}" -f "$f"
done
echo
set +e
"${PSQL[@]}" -t -o /dev/null -f "$ROOT/supabase/tests/rls_test.sql" > "$TMP/out" 2>&1
STATUS=$?
set -e
sed -e 's/^psql:[^ ]* NOTICE:  //' -e 's/^NOTICE:  //' "$TMP/out" | grep -v '^\s*$'
exit $STATUS
