-- OurSpace: Row Level Security and privileges.
--
-- Model: every piece of group content is readable only by members of that
-- group. Users create content only as themselves. Owners/admins manage
-- membership, invites and pinned announcements. The anon role gets nothing.
--
-- Privileges are granted per column where it matters, so a client cannot
-- (for example) move a post to another group or edit someone's role by
-- sending extra fields.

-- ---------------------------------------------------------------------------
-- Start from zero: Supabase grants ALL to anon/authenticated by default.
-- ---------------------------------------------------------------------------
revoke all on all tables in schema public from anon, authenticated;
revoke execute on all functions in schema public from public, anon, authenticated;

-- Helpers used inside policies must be executable by the caller.
grant execute on function
  public.is_group_member(uuid),
  public.group_role_of(uuid),
  public.is_group_admin(uuid),
  public.shares_group_with(uuid),
  public.post_group_id(uuid),
  public.poll_group_id(uuid),
  public.event_group_id(uuid),
  public.poll_accepts_votes(uuid),
  public.has_voted(uuid),
  public.poll_results_visible(uuid),
  public.try_uuid(text),
  public.generate_invite_code()
to authenticated;

-- RPCs the app calls.
grant execute on function
  public.create_group(text, text),
  public.preview_invite(text),
  public.join_group(text),
  public.create_poll(uuid, text, text[], timestamptz, boolean),
  public.cast_vote(uuid, uuid),
  public.set_rsvp(uuid, public.rsvp_status),
  public.set_announcement_pinned(uuid, boolean),
  public.transfer_ownership(uuid, uuid)
to authenticated;

-- ---------------------------------------------------------------------------
-- Enable RLS everywhere
-- ---------------------------------------------------------------------------
alter table public.profiles      enable row level security;
alter table public.groups        enable row level security;
alter table public.group_members enable row level security;
alter table public.group_invites enable row level security;
alter table public.messages      enable row level security;
alter table public.posts         enable row level security;
alter table public.post_likes    enable row level security;
alter table public.comments      enable row level security;
alter table public.polls         enable row level security;
alter table public.poll_options  enable row level security;
alter table public.poll_votes    enable row level security;
alter table public.events        enable row level security;
alter table public.event_rsvps   enable row level security;
alter table public.announcements enable row level security;

-- ---------------------------------------------------------------------------
-- profiles: you, plus people you share a group with
-- ---------------------------------------------------------------------------
grant select on public.profiles to authenticated;
grant insert (id, username, display_name, avatar_path) on public.profiles to authenticated;
grant update (username, display_name, avatar_path) on public.profiles to authenticated;

create policy profiles_select on public.profiles for select to authenticated
  using (id = (select auth.uid()) or public.shares_group_with(id));

create policy profiles_insert on public.profiles for insert to authenticated
  with check (id = (select auth.uid()));

create policy profiles_update on public.profiles for update to authenticated
  using (id = (select auth.uid()))
  with check (id = (select auth.uid()));

-- ---------------------------------------------------------------------------
-- groups: created only through create_group()
-- ---------------------------------------------------------------------------
grant select, delete on public.groups to authenticated;
grant update (name, description, members_can_announce) on public.groups to authenticated;

create policy groups_select on public.groups for select to authenticated
  using (public.is_group_member(id));

create policy groups_update on public.groups for update to authenticated
  using (public.is_group_admin(id))
  with check (public.is_group_admin(id));

create policy groups_delete on public.groups for delete to authenticated
  using (owner_id = (select auth.uid()));

-- ---------------------------------------------------------------------------
-- group_members: joined only through create_group() / join_group()
-- ---------------------------------------------------------------------------
grant select, delete on public.group_members to authenticated;
grant update (role) on public.group_members to authenticated;

create policy group_members_select on public.group_members for select to authenticated
  using (public.is_group_member(group_id));

-- Only the owner changes roles, never their own and never to/from 'owner'
-- (use transfer_ownership() for that).
create policy group_members_update on public.group_members for update to authenticated
  using (public.group_role_of(group_id) = 'owner' and role <> 'owner')
  with check (public.group_role_of(group_id) = 'owner' and role in ('admin', 'member'));

-- Members may leave (the owner must transfer ownership first).
-- Admins may remove plain members; the owner may remove admins too.
create policy group_members_delete on public.group_members for delete to authenticated
  using (
    role <> 'owner'
    and (
      user_id = (select auth.uid())
      or (role = 'member' and public.is_group_admin(group_id))
      or public.group_role_of(group_id) = 'owner'
    )
  );

-- ---------------------------------------------------------------------------
-- group_invites: owners/admins only
-- ---------------------------------------------------------------------------
grant select, delete on public.group_invites to authenticated;
grant insert (group_id, expires_at, max_uses) on public.group_invites to authenticated;
grant update (revoked_at) on public.group_invites to authenticated;

create policy group_invites_select on public.group_invites for select to authenticated
  using (public.is_group_admin(group_id));

create policy group_invites_insert on public.group_invites for insert to authenticated
  with check (public.is_group_admin(group_id) and created_by = (select auth.uid()));

create policy group_invites_update on public.group_invites for update to authenticated
  using (public.is_group_admin(group_id))
  with check (public.is_group_admin(group_id));

create policy group_invites_delete on public.group_invites for delete to authenticated
  using (public.is_group_admin(group_id));

-- ---------------------------------------------------------------------------
-- messages
-- ---------------------------------------------------------------------------
grant select, delete on public.messages to authenticated;
grant insert (group_id, sender_id, body, attachment_path) on public.messages to authenticated;

create policy messages_select on public.messages for select to authenticated
  using (public.is_group_member(group_id));

create policy messages_insert on public.messages for insert to authenticated
  with check (
    sender_id = (select auth.uid())
    and public.is_group_member(group_id)
    and (attachment_path is null
         or attachment_path like group_id::text || '/' || (select auth.uid())::text || '/%')
  );

create policy messages_delete on public.messages for delete to authenticated
  using (sender_id = (select auth.uid()) or public.is_group_admin(group_id));

-- ---------------------------------------------------------------------------
-- posts
-- ---------------------------------------------------------------------------
grant select, delete on public.posts to authenticated;
grant insert (group_id, author_id, caption, image_path) on public.posts to authenticated;
grant update (caption) on public.posts to authenticated;

create policy posts_select on public.posts for select to authenticated
  using (public.is_group_member(group_id));

create policy posts_insert on public.posts for insert to authenticated
  with check (
    author_id = (select auth.uid())
    and public.is_group_member(group_id)
    and image_path like group_id::text || '/' || (select auth.uid())::text || '/%'
  );

create policy posts_update on public.posts for update to authenticated
  using (author_id = (select auth.uid()))
  with check (author_id = (select auth.uid()));

create policy posts_delete on public.posts for delete to authenticated
  using (author_id = (select auth.uid()) or public.is_group_admin(group_id));

-- ---------------------------------------------------------------------------
-- post_likes
-- ---------------------------------------------------------------------------
grant select, delete on public.post_likes to authenticated;
grant insert (post_id, user_id) on public.post_likes to authenticated;

create policy post_likes_select on public.post_likes for select to authenticated
  using (public.is_group_member(public.post_group_id(post_id)));

create policy post_likes_insert on public.post_likes for insert to authenticated
  with check (user_id = (select auth.uid()) and public.is_group_member(public.post_group_id(post_id)));

create policy post_likes_delete on public.post_likes for delete to authenticated
  using (user_id = (select auth.uid()));

-- ---------------------------------------------------------------------------
-- comments
-- ---------------------------------------------------------------------------
grant select, delete on public.comments to authenticated;
grant insert (post_id, author_id, body) on public.comments to authenticated;

create policy comments_select on public.comments for select to authenticated
  using (public.is_group_member(public.post_group_id(post_id)));

create policy comments_insert on public.comments for insert to authenticated
  with check (author_id = (select auth.uid()) and public.is_group_member(public.post_group_id(post_id)));

create policy comments_delete on public.comments for delete to authenticated
  using (author_id = (select auth.uid()) or public.is_group_admin(public.post_group_id(post_id)));

-- ---------------------------------------------------------------------------
-- polls / options / votes
-- ---------------------------------------------------------------------------
-- Polls and their options are created only through create_poll().
grant select, delete on public.polls to authenticated;
grant update (is_closed) on public.polls to authenticated;

create policy polls_select on public.polls for select to authenticated
  using (public.is_group_member(group_id));

create policy polls_update on public.polls for update to authenticated
  using (creator_id = (select auth.uid()) or public.is_group_admin(group_id))
  with check (creator_id = (select auth.uid()) or public.is_group_admin(group_id));

create policy polls_delete on public.polls for delete to authenticated
  using (creator_id = (select auth.uid()) or public.is_group_admin(group_id));

grant select on public.poll_options to authenticated;
create policy poll_options_select on public.poll_options for select to authenticated
  using (public.is_group_member(public.poll_group_id(poll_id)));

grant select, delete on public.poll_votes to authenticated;
grant insert (poll_id, option_id, user_id) on public.poll_votes to authenticated;
grant update (option_id) on public.poll_votes to authenticated;

-- Your own vote is always visible; everyone else's only once results are.
create policy poll_votes_select on public.poll_votes for select to authenticated
  using (
    public.is_group_member(public.poll_group_id(poll_id))
    and (user_id = (select auth.uid()) or public.poll_results_visible(poll_id))
  );

create policy poll_votes_insert on public.poll_votes for insert to authenticated
  with check (
    user_id = (select auth.uid())
    and public.is_group_member(public.poll_group_id(poll_id))
    and public.poll_accepts_votes(poll_id)
  );

create policy poll_votes_update on public.poll_votes for update to authenticated
  using (user_id = (select auth.uid()) and public.poll_accepts_votes(poll_id))
  with check (user_id = (select auth.uid()) and public.poll_accepts_votes(poll_id));

create policy poll_votes_delete on public.poll_votes for delete to authenticated
  using (user_id = (select auth.uid()) and public.poll_accepts_votes(poll_id));

-- ---------------------------------------------------------------------------
-- events / RSVPs
-- ---------------------------------------------------------------------------
grant select, delete on public.events to authenticated;
grant insert (group_id, creator_id, title, description, starts_at, ends_at, location) on public.events to authenticated;
grant update (title, description, starts_at, ends_at, location) on public.events to authenticated;

create policy events_select on public.events for select to authenticated
  using (public.is_group_member(group_id));

create policy events_insert on public.events for insert to authenticated
  with check (creator_id = (select auth.uid()) and public.is_group_member(group_id));

create policy events_update on public.events for update to authenticated
  using (creator_id = (select auth.uid()) or public.is_group_admin(group_id))
  with check (creator_id = (select auth.uid()) or public.is_group_admin(group_id));

create policy events_delete on public.events for delete to authenticated
  using (creator_id = (select auth.uid()) or public.is_group_admin(group_id));

grant select, delete on public.event_rsvps to authenticated;
grant insert (event_id, user_id, status) on public.event_rsvps to authenticated;
grant update (status) on public.event_rsvps to authenticated;

create policy event_rsvps_select on public.event_rsvps for select to authenticated
  using (public.is_group_member(public.event_group_id(event_id)));

create policy event_rsvps_insert on public.event_rsvps for insert to authenticated
  with check (user_id = (select auth.uid()) and public.is_group_member(public.event_group_id(event_id)));

create policy event_rsvps_update on public.event_rsvps for update to authenticated
  using (user_id = (select auth.uid()))
  with check (user_id = (select auth.uid()));

create policy event_rsvps_delete on public.event_rsvps for delete to authenticated
  using (user_id = (select auth.uid()));

-- ---------------------------------------------------------------------------
-- announcements
-- Publishing: owners/admins, or any member if the group allows it.
-- Pinning: only through set_announcement_pinned() (admins).
-- ---------------------------------------------------------------------------
grant select, delete on public.announcements to authenticated;
grant insert (group_id, author_id, title, body, is_pinned) on public.announcements to authenticated;
grant update (title, body) on public.announcements to authenticated;

create policy announcements_select on public.announcements for select to authenticated
  using (public.is_group_member(group_id));

create policy announcements_insert on public.announcements for insert to authenticated
  with check (
    author_id = (select auth.uid())
    and (
      public.is_group_admin(group_id)
      or (public.is_group_member(group_id)
          and exists (select 1 from public.groups g where g.id = group_id and g.members_can_announce)
          and not is_pinned)
    )
  );

create policy announcements_update on public.announcements for update to authenticated
  using (author_id = (select auth.uid()) or public.is_group_admin(group_id))
  with check (author_id = (select auth.uid()) or public.is_group_admin(group_id));

create policy announcements_delete on public.announcements for delete to authenticated
  using (author_id = (select auth.uid()) or public.is_group_admin(group_id));
