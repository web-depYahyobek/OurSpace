-- OurSpace: helper functions used by RLS policies, plus RPCs for actions that
-- must be atomic or need to bypass RLS in a controlled way.
--
-- Helper functions are SECURITY DEFINER so policies can check membership
-- without recursing into group_members' own policies. Each one only answers
-- questions about the *calling* user, so nothing private leaks through them.

-- ---------------------------------------------------------------------------
-- Membership helpers
-- ---------------------------------------------------------------------------
create or replace function public.is_group_member(gid uuid)
returns boolean
language sql
stable
security definer
set search_path = ''
as $$
  select exists (
    select 1 from public.group_members m
    where m.group_id = gid and m.user_id = (select auth.uid())
  );
$$;

create or replace function public.group_role_of(gid uuid)
returns public.group_role
language sql
stable
security definer
set search_path = ''
as $$
  select m.role from public.group_members m
  where m.group_id = gid and m.user_id = (select auth.uid());
$$;

create or replace function public.is_group_admin(gid uuid)
returns boolean
language sql
stable
security definer
set search_path = ''
as $$
  select coalesce(public.group_role_of(gid) in ('owner', 'admin'), false);
$$;

create or replace function public.shares_group_with(other uuid)
returns boolean
language sql
stable
security definer
set search_path = ''
as $$
  select exists (
    select 1
    from public.group_members mine
    join public.group_members theirs on theirs.group_id = mine.group_id
    where mine.user_id = (select auth.uid()) and theirs.user_id = other
  );
$$;

-- Parent lookups (child tables don't carry group_id themselves).
create or replace function public.post_group_id(pid uuid)
returns uuid language sql stable security definer set search_path = ''
as $$ select p.group_id from public.posts p where p.id = pid; $$;

create or replace function public.poll_group_id(pid uuid)
returns uuid language sql stable security definer set search_path = ''
as $$ select p.group_id from public.polls p where p.id = pid; $$;

create or replace function public.event_group_id(eid uuid)
returns uuid language sql stable security definer set search_path = ''
as $$ select e.group_id from public.events e where e.id = eid; $$;

create or replace function public.poll_accepts_votes(pid uuid)
returns boolean language sql stable security definer set search_path = ''
as $$
  select exists (
    select 1 from public.polls p
    where p.id = pid and not p.is_closed and (p.ends_at is null or p.ends_at > now())
  );
$$;

create or replace function public.has_voted(pid uuid)
returns boolean language sql stable security definer set search_path = ''
as $$
  select exists (
    select 1 from public.poll_votes v where v.poll_id = pid and v.user_id = (select auth.uid())
  );
$$;

-- Results are visible once you have voted, when the creator chose public
-- results, or after the poll has closed or ended.
create or replace function public.poll_results_visible(pid uuid)
returns boolean language sql stable security definer set search_path = ''
as $$
  select exists (
    select 1 from public.polls p
    where p.id = pid
      and (p.show_results_before_vote
           or p.is_closed
           or (p.ends_at is not null and p.ends_at <= now()))
  ) or public.has_voted(pid);
$$;

-- Storage paths are '<uuid>/<uuid>/<file>'. A malformed segment must make a
-- policy return false, not throw.
create or replace function public.try_uuid(value text)
returns uuid language plpgsql immutable set search_path = ''
as $$
begin
  return value::uuid;
exception when others then
  return null;
end;
$$;

-- ---------------------------------------------------------------------------
-- RPC: create a group and make the caller its owner
-- ---------------------------------------------------------------------------
create or replace function public.create_group(p_name text, p_description text default null)
returns uuid
language plpgsql
security definer
set search_path = ''
as $$
declare
  uid uuid := auth.uid();
  new_id uuid;
begin
  if uid is null then
    raise exception 'Not signed in' using errcode = '28000';
  end if;
  if not exists (select 1 from public.profiles where id = uid) then
    raise exception 'Create your profile first' using errcode = 'P0001';
  end if;

  insert into public.groups (name, description, owner_id)
  values (btrim(p_name), nullif(btrim(p_description), ''), uid)
  returning id into new_id;

  insert into public.group_members (group_id, user_id, role)
  values (new_id, uid, 'owner');

  return new_id;
end;
$$;

-- ---------------------------------------------------------------------------
-- RPC: look at an invite before joining (non-members cannot read groups)
-- Returns no row when the code is unknown, revoked, expired or used up.
-- ---------------------------------------------------------------------------
create or replace function public.preview_invite(p_code text)
returns table (group_id uuid, group_name text, group_description text, member_count bigint, already_member boolean)
language sql
stable
security definer
set search_path = ''
as $$
  select g.id, g.name, g.description,
         (select count(*) from public.group_members m where m.group_id = g.id),
         exists (select 1 from public.group_members m where m.group_id = g.id and m.user_id = (select auth.uid()))
  from public.group_invites i
  join public.groups g on g.id = i.group_id
  where i.code = upper(btrim(p_code))
    and i.revoked_at is null
    and (i.expires_at is null or i.expires_at > now())
    and (i.max_uses is null or i.use_count < i.max_uses);
$$;

-- ---------------------------------------------------------------------------
-- RPC: join a group with an invite code
-- ---------------------------------------------------------------------------
create or replace function public.join_group(p_code text)
returns uuid
language plpgsql
security definer
set search_path = ''
as $$
declare
  uid uuid := auth.uid();
  inv public.group_invites%rowtype;
begin
  if uid is null then
    raise exception 'Not signed in' using errcode = '28000';
  end if;
  if not exists (select 1 from public.profiles where id = uid) then
    raise exception 'Create your profile first' using errcode = 'P0001';
  end if;

  select * into inv from public.group_invites
  where code = upper(btrim(p_code))
  for update;

  if not found
     or inv.revoked_at is not null
     or (inv.expires_at is not null and inv.expires_at <= now())
     or (inv.max_uses is not null and inv.use_count >= inv.max_uses) then
    raise exception 'This invite is invalid or has expired' using errcode = 'P0001';
  end if;

  if exists (select 1 from public.group_members where group_id = inv.group_id and user_id = uid) then
    return inv.group_id;
  end if;

  insert into public.group_members (group_id, user_id, role) values (inv.group_id, uid, 'member');
  update public.group_invites set use_count = use_count + 1 where id = inv.id;

  return inv.group_id;
end;
$$;

-- ---------------------------------------------------------------------------
-- RPC: create a poll and its options in one transaction. This is the only way
-- to create polls and options (no direct insert grants), so options can never
-- be added after people have voted.
-- ---------------------------------------------------------------------------
create or replace function public.create_poll(
  p_group_id uuid,
  p_question text,
  p_options text[],
  p_ends_at timestamptz default null,
  p_show_results_before_vote boolean default false
)
returns uuid
language plpgsql
security definer
set search_path = ''
as $$
declare
  new_id uuid;
  cleaned text[];
begin
  if not public.is_group_member(p_group_id) then
    raise exception 'You are not a member of this group' using errcode = '42501';
  end if;
  if nullif(btrim(p_question), '') is null then
    raise exception 'Write a question' using errcode = 'P0001';
  end if;

  -- Trim, drop blanks, and drop case-insensitive duplicates (first one wins).
  select array_agg(t order by ord) into cleaned
  from (
    select distinct on (lower(btrim(o))) btrim(o) as t, ord
    from unnest(p_options) with ordinality as u(o, ord)
    where nullif(btrim(o), '') is not null
    order by lower(btrim(o)), ord
  ) s;

  if cleaned is null or array_length(cleaned, 1) < 2 then
    raise exception 'A poll needs at least two different options' using errcode = 'P0001';
  end if;
  if array_length(cleaned, 1) > 10 then
    raise exception 'A poll can have at most 10 options' using errcode = 'P0001';
  end if;
  if p_ends_at is not null and p_ends_at <= now() then
    raise exception 'The closing time must be in the future' using errcode = 'P0001';
  end if;

  insert into public.polls (group_id, creator_id, question, ends_at, show_results_before_vote)
  values (p_group_id, auth.uid(), btrim(p_question), p_ends_at, coalesce(p_show_results_before_vote, false))
  returning id into new_id;

  insert into public.poll_options (poll_id, option_text, position)
  select new_id, t, (ord - 1)::smallint
  from unnest(cleaned) with ordinality as u(t, ord);

  return new_id;
end;
$$;

-- ---------------------------------------------------------------------------
-- RPC: cast or change your single vote while the poll is open.
-- SECURITY INVOKER: RLS enforces membership, ownership and open status.
-- ---------------------------------------------------------------------------
create or replace function public.cast_vote(p_poll_id uuid, p_option_id uuid)
returns void
language plpgsql
security invoker
set search_path = ''
as $$
begin
  if not public.poll_accepts_votes(p_poll_id) then
    raise exception 'This poll is closed' using errcode = 'P0001';
  end if;

  insert into public.poll_votes (poll_id, option_id, user_id)
  values (p_poll_id, p_option_id, auth.uid())
  on conflict (poll_id, user_id) do update set option_id = excluded.option_id;
end;
$$;

-- ---------------------------------------------------------------------------
-- RPC: set your RSVP for an event.
-- ---------------------------------------------------------------------------
create or replace function public.set_rsvp(p_event_id uuid, p_status public.rsvp_status)
returns void
language plpgsql
security invoker
set search_path = ''
as $$
begin
  insert into public.event_rsvps (event_id, user_id, status)
  values (p_event_id, auth.uid(), p_status)
  on conflict (event_id, user_id) do update set status = excluded.status;
end;
$$;

-- ---------------------------------------------------------------------------
-- RPC: pin or unpin an announcement (owners and admins only).
-- ---------------------------------------------------------------------------
create or replace function public.set_announcement_pinned(p_announcement_id uuid, p_pinned boolean)
returns void
language plpgsql
security definer
set search_path = ''
as $$
declare
  gid uuid;
begin
  select group_id into gid from public.announcements where id = p_announcement_id;
  if gid is null or not public.is_group_admin(gid) then
    raise exception 'Only group admins can pin announcements' using errcode = '42501';
  end if;
  update public.announcements set is_pinned = p_pinned where id = p_announcement_id;
end;
$$;

-- ---------------------------------------------------------------------------
-- RPC: hand ownership to another member (owner only). The old owner becomes
-- an admin.
-- ---------------------------------------------------------------------------
create or replace function public.transfer_ownership(p_group_id uuid, p_new_owner uuid)
returns void
language plpgsql
security definer
set search_path = ''
as $$
declare
  uid uuid := auth.uid();
begin
  if public.group_role_of(p_group_id) is distinct from 'owner' then
    raise exception 'Only the owner can transfer ownership' using errcode = '42501';
  end if;
  if not exists (select 1 from public.group_members where group_id = p_group_id and user_id = p_new_owner) then
    raise exception 'That person is not a member of this group' using errcode = 'P0001';
  end if;
  if p_new_owner = uid then
    return;
  end if;

  update public.group_members set role = 'admin' where group_id = p_group_id and user_id = uid;
  update public.group_members set role = 'owner' where group_id = p_group_id and user_id = p_new_owner;
  update public.groups set owner_id = p_new_owner where id = p_group_id;
end;
$$;
