-- OurSpace: private storage buckets and access policies.
--
-- group-media: '<group_id>/<user_id>/<file>'  (post photos, chat images)
-- avatars:     '<user_id>/<file>'
--
-- Both buckets are private. The app shows files through short-lived signed
-- URLs, which Storage only issues when the select policy below passes.

insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values
  ('group-media', 'group-media', false, 10485760,
   array['image/jpeg', 'image/png', 'image/webp', 'image/gif']),
  ('avatars', 'avatars', false, 2097152,
   array['image/jpeg', 'image/png', 'image/webp'])
on conflict (id) do update
  set public = excluded.public,
      file_size_limit = excluded.file_size_limit,
      allowed_mime_types = excluded.allowed_mime_types;

-- ---------------------------------------------------------------------------
-- group-media
-- ---------------------------------------------------------------------------
create policy "group-media: members can read"
  on storage.objects for select to authenticated
  using (
    bucket_id = 'group-media'
    and public.is_group_member(public.try_uuid((storage.foldername(name))[1]))
  );

create policy "group-media: members upload into their own folder"
  on storage.objects for insert to authenticated
  with check (
    bucket_id = 'group-media'
    and public.is_group_member(public.try_uuid((storage.foldername(name))[1]))
    and (storage.foldername(name))[2] = (select auth.uid())::text
  );

create policy "group-media: uploader or admin can delete"
  on storage.objects for delete to authenticated
  using (
    bucket_id = 'group-media'
    and (
      (storage.foldername(name))[2] = (select auth.uid())::text
      or public.is_group_admin(public.try_uuid((storage.foldername(name))[1]))
    )
  );

-- ---------------------------------------------------------------------------
-- avatars
-- ---------------------------------------------------------------------------
create policy "avatars: visible to you and your group-mates"
  on storage.objects for select to authenticated
  using (
    bucket_id = 'avatars'
    and (
      (storage.foldername(name))[1] = (select auth.uid())::text
      or public.shares_group_with(public.try_uuid((storage.foldername(name))[1]))
    )
  );

create policy "avatars: upload your own"
  on storage.objects for insert to authenticated
  with check (bucket_id = 'avatars' and (storage.foldername(name))[1] = (select auth.uid())::text);

create policy "avatars: replace your own"
  on storage.objects for update to authenticated
  using (bucket_id = 'avatars' and (storage.foldername(name))[1] = (select auth.uid())::text)
  with check (bucket_id = 'avatars' and (storage.foldername(name))[1] = (select auth.uid())::text);

create policy "avatars: delete your own"
  on storage.objects for delete to authenticated
  using (bucket_id = 'avatars' and (storage.foldername(name))[1] = (select auth.uid())::text);
