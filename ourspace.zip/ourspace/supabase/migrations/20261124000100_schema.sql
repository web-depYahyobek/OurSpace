-- OurSpace: core schema
-- Tables, constraints and indexes. Access rules live in 20261124000300_rls.sql.

create extension if not exists pgcrypto with schema extensions;

-- ---------------------------------------------------------------------------
-- Enums
-- ---------------------------------------------------------------------------
create type public.group_role as enum ('owner', 'admin', 'member');
create type public.rsvp_status as enum ('going', 'maybe', 'not_going');

-- ---------------------------------------------------------------------------
-- Shared trigger: keep updated_at current
-- ---------------------------------------------------------------------------
create or replace function public.touch_updated_at()
returns trigger
language plpgsql
set search_path = ''
as $$
begin
  new.updated_at := now();
  return new;
end;
$$;

-- ---------------------------------------------------------------------------
-- Invite codes: 8 characters from an unambiguous 31-character alphabet
-- (no 0/O, 1/I/L). 31^8 ≈ 850 billion combinations.
-- ---------------------------------------------------------------------------
create or replace function public.generate_invite_code()
returns text
language plpgsql
volatile
security definer
set search_path = ''
as $$
declare
  alphabet constant text := 'ABCDEFGHJKMNPQRSTUVWXYZ23456789';
  bytes bytea := extensions.gen_random_bytes(8);
  result text := '';
  i int;
begin
  for i in 0..7 loop
    result := result || substr(alphabet, (get_byte(bytes, i) % 31) + 1, 1);
  end loop;
  return result;
end;
$$;

-- ---------------------------------------------------------------------------
-- Profiles (1:1 with auth.users)
-- ---------------------------------------------------------------------------
create table public.profiles (
  id           uuid primary key references auth.users (id) on delete cascade,
  username     text not null unique
               constraint profiles_username_format check (username ~ '^[a-z0-9_]{3,20}$'),
  display_name text not null
               constraint profiles_display_name_length check (char_length(btrim(display_name)) between 1 and 50),
  avatar_path  text,
  created_at   timestamptz not null default now(),
  updated_at   timestamptz not null default now()
);

create trigger profiles_touch_updated_at
  before update on public.profiles
  for each row execute function public.touch_updated_at();

-- ---------------------------------------------------------------------------
-- Groups and membership
-- ---------------------------------------------------------------------------
create table public.groups (
  id                   uuid primary key default gen_random_uuid(),
  name                 text not null
                       constraint groups_name_length check (char_length(btrim(name)) between 1 and 60),
  description          text
                       constraint groups_description_length check (char_length(description) <= 280),
  owner_id             uuid not null references public.profiles (id) on delete restrict,
  members_can_announce boolean not null default false,
  created_at           timestamptz not null default now()
);

create table public.group_members (
  id        uuid primary key default gen_random_uuid(),
  group_id  uuid not null references public.groups (id) on delete cascade,
  user_id   uuid not null references public.profiles (id) on delete cascade,
  role      public.group_role not null default 'member',
  joined_at timestamptz not null default now(),
  constraint group_members_unique unique (group_id, user_id)
);

create index group_members_user_idx on public.group_members (user_id);
-- Exactly one owner per group.
create unique index group_members_one_owner on public.group_members (group_id) where role = 'owner';

-- Revocable invitations. A group can have several active codes.
create table public.group_invites (
  id          uuid primary key default gen_random_uuid(),
  group_id    uuid not null references public.groups (id) on delete cascade,
  code        text not null unique default public.generate_invite_code(),
  created_by  uuid not null default auth.uid() references public.profiles (id) on delete cascade,
  created_at  timestamptz not null default now(),
  expires_at  timestamptz,
  max_uses    int constraint group_invites_max_uses_positive check (max_uses is null or max_uses > 0),
  use_count   int not null default 0,
  revoked_at  timestamptz
);

create index group_invites_group_idx on public.group_invites (group_id, created_at desc);

-- ---------------------------------------------------------------------------
-- Chat
-- ---------------------------------------------------------------------------
create table public.messages (
  id              uuid primary key default gen_random_uuid(),
  group_id        uuid not null references public.groups (id) on delete cascade,
  sender_id       uuid not null references public.profiles (id) on delete cascade,
  body            text constraint messages_body_length check (char_length(body) <= 4000),
  attachment_path text,
  created_at      timestamptz not null default now(),
  constraint messages_not_empty check (nullif(btrim(body), '') is not null or attachment_path is not null)
);

create index messages_group_created_idx on public.messages (group_id, created_at desc);

-- ---------------------------------------------------------------------------
-- Photo posts, likes, comments
-- ---------------------------------------------------------------------------
create table public.posts (
  id         uuid primary key default gen_random_uuid(),
  group_id   uuid not null references public.groups (id) on delete cascade,
  author_id  uuid not null references public.profiles (id) on delete cascade,
  caption    text constraint posts_caption_length check (char_length(caption) <= 2200),
  image_path text not null,
  created_at timestamptz not null default now()
);

create index posts_group_created_idx on public.posts (group_id, created_at desc);

create table public.post_likes (
  id         uuid primary key default gen_random_uuid(),
  post_id    uuid not null references public.posts (id) on delete cascade,
  user_id    uuid not null references public.profiles (id) on delete cascade,
  created_at timestamptz not null default now(),
  constraint post_likes_unique unique (post_id, user_id)
);

create index post_likes_user_idx on public.post_likes (user_id);

create table public.comments (
  id         uuid primary key default gen_random_uuid(),
  post_id    uuid not null references public.posts (id) on delete cascade,
  author_id  uuid not null references public.profiles (id) on delete cascade,
  body       text not null
             constraint comments_body_length check (char_length(btrim(body)) between 1 and 1000),
  created_at timestamptz not null default now()
);

create index comments_post_created_idx on public.comments (post_id, created_at);

-- ---------------------------------------------------------------------------
-- Polls (single choice in the MVP)
-- ---------------------------------------------------------------------------
create table public.polls (
  id                       uuid primary key default gen_random_uuid(),
  group_id                 uuid not null references public.groups (id) on delete cascade,
  creator_id               uuid not null references public.profiles (id) on delete cascade,
  question                 text not null
                           constraint polls_question_length check (char_length(btrim(question)) between 1 and 200),
  ends_at                  timestamptz,
  is_closed                boolean not null default false,
  show_results_before_vote boolean not null default false,
  created_at               timestamptz not null default now()
);

create index polls_group_created_idx on public.polls (group_id, created_at desc);

create table public.poll_options (
  id          uuid primary key default gen_random_uuid(),
  poll_id     uuid not null references public.polls (id) on delete cascade,
  option_text text not null
              constraint poll_options_text_length check (char_length(btrim(option_text)) between 1 and 100),
  position    smallint not null,
  constraint poll_options_position_unique unique (poll_id, position),
  -- Lets poll_votes prove that the option belongs to the poll.
  constraint poll_options_id_poll_unique unique (id, poll_id)
);

create table public.poll_votes (
  id         uuid primary key default gen_random_uuid(),
  poll_id    uuid not null references public.polls (id) on delete cascade,
  option_id  uuid not null,
  user_id    uuid not null references public.profiles (id) on delete cascade,
  created_at timestamptz not null default now(),
  constraint poll_votes_one_per_user unique (poll_id, user_id),
  constraint poll_votes_option_matches_poll
    foreign key (option_id, poll_id) references public.poll_options (id, poll_id) on delete cascade
);

create index poll_votes_option_idx on public.poll_votes (option_id);

-- ---------------------------------------------------------------------------
-- Events and RSVPs
-- ---------------------------------------------------------------------------
create table public.events (
  id          uuid primary key default gen_random_uuid(),
  group_id    uuid not null references public.groups (id) on delete cascade,
  creator_id  uuid not null references public.profiles (id) on delete cascade,
  title       text not null
              constraint events_title_length check (char_length(btrim(title)) between 1 and 100),
  description text constraint events_description_length check (char_length(description) <= 2000),
  starts_at   timestamptz not null,
  ends_at     timestamptz,
  location    text constraint events_location_length check (char_length(location) <= 200),
  created_at  timestamptz not null default now(),
  constraint events_end_after_start check (ends_at is null or ends_at > starts_at)
);

create index events_group_starts_idx on public.events (group_id, starts_at);

create table public.event_rsvps (
  id         uuid primary key default gen_random_uuid(),
  event_id   uuid not null references public.events (id) on delete cascade,
  user_id    uuid not null references public.profiles (id) on delete cascade,
  status     public.rsvp_status not null,
  updated_at timestamptz not null default now(),
  constraint event_rsvps_unique unique (event_id, user_id)
);

create trigger event_rsvps_touch_updated_at
  before update on public.event_rsvps
  for each row execute function public.touch_updated_at();

-- ---------------------------------------------------------------------------
-- Announcements
-- ---------------------------------------------------------------------------
create table public.announcements (
  id         uuid primary key default gen_random_uuid(),
  group_id   uuid not null references public.groups (id) on delete cascade,
  author_id  uuid not null references public.profiles (id) on delete cascade,
  title      text not null
             constraint announcements_title_length check (char_length(btrim(title)) between 1 and 120),
  body       text not null
             constraint announcements_body_length check (char_length(btrim(body)) between 1 and 5000),
  is_pinned  boolean not null default false,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index announcements_group_idx on public.announcements (group_id, is_pinned desc, created_at desc);

create trigger announcements_touch_updated_at
  before update on public.announcements
  for each row execute function public.touch_updated_at();
