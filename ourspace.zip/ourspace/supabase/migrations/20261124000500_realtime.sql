-- OurSpace: Realtime. Postgres Changes respects RLS, so subscribers only
-- receive rows they are allowed to select.

do $$
declare
  t text;
begin
  foreach t in array array['messages', 'poll_votes', 'announcements'] loop
    if not exists (
      select 1 from pg_publication_tables
      where pubname = 'supabase_realtime' and schemaname = 'public' and tablename = t
    ) then
      execute format('alter publication supabase_realtime add table public.%I', t);
    end if;
  end loop;
end;
$$;
