-- OurSpace privacy tests. Run with scripts/test-db.sh (throwaway local
-- PostgreSQL + supabase_stub.sql). Each check prints PASS or aborts with FAIL.
--
-- Cast: alice (owner), bob (member), dave (joins later, made admin),
--       carol (signed in, never invited).

\set ON_ERROR_STOP 1
\set QUIET 1
set client_min_messages = notice;

create schema tests;

create function tests.ok(cond boolean, label text) returns void language plpgsql as $$
begin
  if cond is distinct from true then raise exception 'FAIL: %', label; end if;
  raise notice 'PASS: %', label;
end $$;

create function tests.fails(stmt text, label text) returns void language plpgsql as $$
begin
  execute stmt;
  raise exception 'FAIL (no error): %', label;
exception when others then
  if sqlerrm like 'FAIL (no error)%' then raise; end if;
  raise notice 'PASS: % [%]', label, sqlerrm;
end $$;

create function tests.n(stmt text) returns bigint language plpgsql as $$
declare c bigint;
begin
  execute 'select count(*) from (' || stmt || ') s' into c;
  return c;
end $$;

create function tests.affected(stmt text) returns bigint language plpgsql as $$
declare c bigint;
begin
  execute stmt;
  get diagnostics c = row_count;
  return c;
end $$;

-- Switch identity: role stays 'authenticated', the JWT subject changes.
create function tests.as_user(uid uuid) returns void language sql as $$
  select set_config('request.jwt.claim.sub', uid::text, false);
$$;

grant usage on schema tests to anon, authenticated;
grant execute on all functions in schema tests to anon, authenticated;

insert into auth.users (id, email) values
  ('00000000-0000-0000-0000-00000000000a', 'alice@example.com'),
  ('00000000-0000-0000-0000-00000000000b', 'bob@example.com'),
  ('00000000-0000-0000-0000-00000000000c', 'carol@example.com'),
  ('00000000-0000-0000-0000-00000000000d', 'dave@example.com');

select set_config('t.alice', '00000000-0000-0000-0000-00000000000a', false),
       set_config('t.bob',   '00000000-0000-0000-0000-00000000000b', false),
       set_config('t.carol', '00000000-0000-0000-0000-00000000000c', false),
       set_config('t.dave',  '00000000-0000-0000-0000-00000000000d', false);

\echo '--- anonymous visitors'
set role anon;
select tests.fails($$select * from public.profiles$$, 'anon cannot read profiles');
select tests.fails($$select * from public.messages$$, 'anon cannot read messages');
select tests.fails($$select public.join_group('ANYTHING')$$, 'anon cannot call join_group');
reset role;

\echo '--- profiles'
set role authenticated;
select tests.as_user(current_setting('t.carol')::uuid);
select tests.fails($$select public.create_group('No profile yet')$$, 'cannot create a group before making a profile');

select tests.as_user(current_setting('t.alice')::uuid);
insert into public.profiles (id, username, display_name) values (current_setting('t.alice')::uuid, 'alice', 'Alice');
select tests.fails($$insert into public.profiles (id, username, display_name) values (current_setting('t.bob')::uuid, 'notbob', 'Fake Bob')$$,
  'cannot create a profile for someone else');
select tests.fails($$insert into public.profiles (id, username, display_name) values (current_setting('t.alice')::uuid, 'Bad Name!', 'x')$$,
  'username format is enforced');

select tests.as_user(current_setting('t.bob')::uuid);
insert into public.profiles (id, username, display_name) values (current_setting('t.bob')::uuid, 'bob', 'Bob');
select tests.as_user(current_setting('t.carol')::uuid);
insert into public.profiles (id, username, display_name) values (current_setting('t.carol')::uuid, 'carol', 'Carol');
select tests.as_user(current_setting('t.dave')::uuid);
insert into public.profiles (id, username, display_name) values (current_setting('t.dave')::uuid, 'dave', 'Dave');

select tests.ok(tests.n($$select 1 from public.profiles$$) = 1, 'before joining a group you only see your own profile');

\echo '--- group creation and invites'
select tests.as_user(current_setting('t.alice')::uuid);
select set_config('t.gid', public.create_group('9-A Friends', 'Our class')::text, false);
select tests.ok((select role from public.group_members where user_id = current_setting('t.alice')::uuid) = 'owner',
  'creator becomes owner');
select tests.fails($$insert into public.groups (name, owner_id) values ('Sneaky', current_setting('t.alice')::uuid)$$,
  'groups cannot be inserted directly');

with r as (insert into public.group_invites (group_id) values (current_setting('t.gid')::uuid) returning code)
select set_config('t.code', r.code, false) from r;
select tests.ok(current_setting('t.code') ~ '^[A-Z2-9]{8}$', 'invite code generated: ' || current_setting('t.code'));

select tests.as_user(current_setting('t.carol')::uuid);
select tests.ok(tests.n($$select * from public.preview_invite(current_setting('t.code'))$$) = 1, 'valid code can be previewed');
select tests.ok(tests.n($$select * from public.preview_invite('ZZZZZZZZ')$$) = 0, 'unknown code previews nothing');
select tests.ok(tests.n($$select 1 from public.groups$$) = 0, 'outsider sees no groups');
select tests.fails($$select public.join_group('ZZZZZZZZ')$$, 'unknown code cannot be used to join');

select tests.as_user(current_setting('t.bob')::uuid);
select tests.ok(public.join_group(lower(current_setting('t.code'))) = current_setting('t.gid')::uuid, 'bob joins with the code (case-insensitive)');
select public.join_group(current_setting('t.code'));
reset role;
select tests.ok((select use_count from public.group_invites where code = current_setting('t.code')) = 1, 'joining twice uses the invite once');
set role authenticated;

select tests.ok(tests.n($$select 1 from public.profiles$$) = 2, 'bob now sees alice''s profile (and his own)');
select tests.fails($$insert into public.group_invites (group_id) values (current_setting('t.gid')::uuid)$$, 'plain members cannot create invites');
select tests.ok(tests.n($$select 1 from public.group_invites$$) = 0, 'plain members cannot list invites');
select tests.ok(tests.affected($$update public.group_members set role = 'admin' where user_id = current_setting('t.bob')::uuid$$) = 0,
  'bob cannot promote himself');
select tests.fails($$insert into public.group_members (group_id, user_id) values (current_setting('t.gid')::uuid, current_setting('t.carol')::uuid)$$,
  'members cannot add people directly');

\echo '--- chat'
insert into public.messages (group_id, sender_id, body) values (current_setting('t.gid')::uuid, current_setting('t.bob')::uuid, 'Tomorrow at 3?');
select tests.fails($$insert into public.messages (group_id, sender_id, body) values (current_setting('t.gid')::uuid, current_setting('t.alice')::uuid, 'I am alice')$$,
  'cannot send a message as someone else');
select tests.fails($$insert into public.messages (group_id, sender_id, body) values (current_setting('t.gid')::uuid, current_setting('t.bob')::uuid, '   ')$$,
  'blank messages are rejected');
select tests.fails(format($$insert into public.messages (group_id, sender_id, attachment_path) values (%L, %L, %L)$$,
  current_setting('t.gid'), current_setting('t.bob'), current_setting('t.gid') || '/' || current_setting('t.alice') || '/x.png'),
  'attachment must live in your own folder');
select tests.fails($$update public.messages set body = 'edited'$$, 'messages cannot be edited');

select tests.as_user(current_setting('t.carol')::uuid);
select tests.ok(tests.n($$select 1 from public.messages$$) = 0, 'outsider reads no messages');
select tests.fails($$insert into public.messages (group_id, sender_id, body) values (current_setting('t.gid')::uuid, current_setting('t.carol')::uuid, 'hi')$$,
  'outsider cannot post into the chat');
select tests.ok(tests.n($$select 1 from public.profiles$$) = 1, 'outsider cannot see member profiles');

\echo '--- posts, likes, comments'
select tests.as_user(current_setting('t.bob')::uuid);
with p as (
  insert into public.posts (group_id, author_id, caption, image_path)
  values (current_setting('t.gid')::uuid, current_setting('t.bob')::uuid, 'Best class ever',
          current_setting('t.gid') || '/' || current_setting('t.bob') || '/sunset.jpg')
  returning id)
select set_config('t.post', p.id::text, false) from p;
select tests.fails(format($$insert into public.posts (group_id, author_id, image_path) values (%L, %L, %L)$$,
  current_setting('t.gid'), current_setting('t.bob'), current_setting('t.gid') || '/' || current_setting('t.alice') || '/x.jpg'),
  'post image must be in your own folder');
select tests.fails($$update public.posts set group_id = gen_random_uuid()$$, 'posts cannot be moved to another group');

select tests.as_user(current_setting('t.alice')::uuid);
insert into public.post_likes (post_id, user_id) values (current_setting('t.post')::uuid, current_setting('t.alice')::uuid);
select tests.fails($$insert into public.post_likes (post_id, user_id) values (current_setting('t.post')::uuid, current_setting('t.alice')::uuid)$$,
  'a post can only be liked once per person');
insert into public.comments (post_id, author_id, body) values (current_setting('t.post')::uuid, current_setting('t.alice')::uuid, 'Love it');
select tests.ok(tests.affected($$update public.posts set caption = 'hijacked'$$) = 0, 'cannot edit someone else''s caption');

select tests.as_user(current_setting('t.carol')::uuid);
select tests.ok(tests.n($$select 1 from public.posts$$) + tests.n($$select 1 from public.comments$$) + tests.n($$select 1 from public.post_likes$$) = 0,
  'outsider reads no posts, comments or likes');
select tests.fails($$insert into public.comments (post_id, author_id, body) values (current_setting('t.post')::uuid, current_setting('t.carol')::uuid, 'hi')$$,
  'outsider cannot comment');
select tests.fails($$insert into public.post_likes (post_id, user_id) values (current_setting('t.post')::uuid, current_setting('t.carol')::uuid)$$,
  'outsider cannot like');

\echo '--- polls'
select tests.as_user(current_setting('t.bob')::uuid);
select tests.fails($$select public.create_poll(current_setting('t.gid')::uuid, 'Movie?', array['Interstellar'])$$, 'polls need two options');
select tests.fails($$select public.create_poll(current_setting('t.gid')::uuid, 'Movie?', array['Same', ' same '])$$, 'duplicate options do not count');
select set_config('t.poll', public.create_poll(current_setting('t.gid')::uuid, 'What movie tonight?',
  array['Interstellar', 'Inception', 'The Dark Knight'])::text, false);
select tests.fails($$insert into public.polls (group_id, creator_id, question) values (current_setting('t.gid')::uuid, current_setting('t.bob')::uuid, 'direct')$$,
  'polls are created only through create_poll');
select tests.fails($$insert into public.poll_options (poll_id, option_text, position) values (current_setting('t.poll')::uuid, 'Late add', 9)$$,
  'options cannot be added afterwards');

select tests.as_user(current_setting('t.alice')::uuid);
select public.cast_vote(current_setting('t.poll')::uuid, (select id from public.poll_options where poll_id = current_setting('t.poll')::uuid and position = 0));

select tests.as_user(current_setting('t.bob')::uuid);
select tests.ok(tests.n($$select 1 from public.poll_votes$$) = 0, 'results hidden until you vote');
select public.cast_vote(current_setting('t.poll')::uuid, (select id from public.poll_options where poll_id = current_setting('t.poll')::uuid and position = 1));
select tests.ok(tests.n($$select 1 from public.poll_votes$$) = 2, 'results visible after voting');
select public.cast_vote(current_setting('t.poll')::uuid, (select id from public.poll_options where poll_id = current_setting('t.poll')::uuid and position = 2));
select tests.ok(tests.n($$select 1 from public.poll_votes where user_id = current_setting('t.bob')::uuid$$) = 1, 'changing your vote never creates a second vote');
select tests.fails($$insert into public.poll_votes (poll_id, option_id, user_id) values (current_setting('t.poll')::uuid, (select id from public.poll_options where poll_id = current_setting('t.poll')::uuid limit 1), current_setting('t.bob')::uuid)$$,
  'a direct second vote is rejected');

select set_config('t.poll2', public.create_poll(current_setting('t.gid')::uuid, 'Pizza or sushi?', array['Pizza', 'Sushi'])::text, false);
select tests.fails($$select public.cast_vote(current_setting('t.poll')::uuid, (select id from public.poll_options where poll_id = current_setting('t.poll2')::uuid limit 1))$$,
  'cannot vote with an option from another poll');

select tests.as_user(current_setting('t.carol')::uuid);
select tests.fails($$select public.create_poll(current_setting('t.gid')::uuid, 'Outsider poll', array['a', 'b'])$$, 'outsider cannot create polls');
select tests.fails($$select public.cast_vote(current_setting('t.poll2')::uuid, gen_random_uuid())$$, 'outsider cannot vote');

select tests.as_user(current_setting('t.alice')::uuid);
select tests.ok(tests.affected($$update public.polls set is_closed = true where id = current_setting('t.poll')::uuid$$) = 1, 'admin can close a poll');
select tests.fails($$select public.cast_vote(current_setting('t.poll')::uuid, (select id from public.poll_options where poll_id = current_setting('t.poll')::uuid limit 1))$$,
  'closed polls reject votes');

\echo '--- events'
select tests.as_user(current_setting('t.bob')::uuid);
with e as (
  insert into public.events (group_id, creator_id, title, starts_at, location)
  values (current_setting('t.gid')::uuid, current_setting('t.bob')::uuid, 'Group Movie Night', now() + interval '5 days', 'Cinema')
  returning id)
select set_config('t.event', e.id::text, false) from e;
select public.set_rsvp(current_setting('t.event')::uuid, 'going');
select public.set_rsvp(current_setting('t.event')::uuid, 'maybe');
select tests.ok((select status from public.event_rsvps where user_id = current_setting('t.bob')::uuid) = 'maybe', 'RSVP updates in place');
select tests.ok(tests.n($$select 1 from public.event_rsvps$$) = 1, 'one RSVP per person');
select tests.fails($$insert into public.events (group_id, creator_id, title, starts_at, ends_at) values (current_setting('t.gid')::uuid, current_setting('t.bob')::uuid, 'Backwards', now(), now() - interval '1 hour')$$,
  'events cannot end before they start');

select tests.as_user(current_setting('t.carol')::uuid);
select tests.fails($$select public.set_rsvp(current_setting('t.event')::uuid, 'going')$$, 'outsider cannot RSVP');
select tests.ok(tests.n($$select 1 from public.events$$) = 0, 'outsider sees no events');

\echo '--- announcements'
select tests.as_user(current_setting('t.bob')::uuid);
select tests.fails($$insert into public.announcements (group_id, author_id, title, body) values (current_setting('t.gid')::uuid, current_setting('t.bob')::uuid, 'Hi', 'Body')$$,
  'members cannot announce unless the group allows it');

select tests.as_user(current_setting('t.alice')::uuid);
with a as (
  insert into public.announcements (group_id, author_id, title, body)
  values (current_setting('t.gid')::uuid, current_setting('t.alice')::uuid, 'Trip money', 'Please pay by Friday')
  returning id)
select set_config('t.ann', a.id::text, false) from a;
update public.groups set members_can_announce = true where id = current_setting('t.gid')::uuid;

select tests.as_user(current_setting('t.bob')::uuid);
insert into public.announcements (group_id, author_id, title, body) values (current_setting('t.gid')::uuid, current_setting('t.bob')::uuid, 'Lost keys', 'Anyone seen them?');
select tests.fails($$insert into public.announcements (group_id, author_id, title, body, is_pinned) values (current_setting('t.gid')::uuid, current_setting('t.bob')::uuid, 'Pinned!', 'x', true)$$,
  'members cannot publish pre-pinned announcements');
select tests.fails($$select public.set_announcement_pinned(current_setting('t.ann')::uuid, true)$$, 'members cannot pin');
select tests.fails($$update public.announcements set is_pinned = true$$, 'is_pinned cannot be updated directly');

select tests.as_user(current_setting('t.alice')::uuid);
select public.set_announcement_pinned(current_setting('t.ann')::uuid, true);
select tests.ok((select is_pinned from public.announcements where id = current_setting('t.ann')::uuid), 'admin can pin');

\echo '--- storage'
select tests.as_user(current_setting('t.bob')::uuid);
insert into storage.objects (bucket_id, name) values ('group-media', current_setting('t.gid') || '/' || current_setting('t.bob') || '/sunset.jpg');
select tests.fails(format($$insert into storage.objects (bucket_id, name) values ('group-media', %L)$$, current_setting('t.gid') || '/' || current_setting('t.alice') || '/x.jpg'),
  'cannot upload into someone else''s folder');
select tests.fails($$insert into storage.objects (bucket_id, name) values ('group-media', 'not-a-uuid/whatever/x.jpg')$$,
  'malformed paths are rejected, not errors');
insert into storage.objects (bucket_id, name) values ('avatars', current_setting('t.bob') || '/avatar.png');

select tests.as_user(current_setting('t.carol')::uuid);
insert into storage.objects (bucket_id, name) values ('avatars', current_setting('t.carol') || '/avatar.png');
select tests.fails(format($$insert into storage.objects (bucket_id, name) values ('group-media', %L)$$, current_setting('t.gid') || '/' || current_setting('t.carol') || '/x.jpg'),
  'outsider cannot upload group media');
select tests.ok(tests.n($$select 1 from storage.objects where bucket_id = 'group-media'$$) = 0, 'outsider cannot see group media');
select tests.ok(tests.n($$select 1 from storage.objects where bucket_id = 'avatars'$$) = 1, 'outsider sees only their own avatar');

select tests.as_user(current_setting('t.alice')::uuid);
select tests.ok(tests.n($$select 1 from storage.objects$$) = 2, 'alice sees group media and bob''s avatar, not carol''s');

\echo '--- membership management'
select tests.as_user(current_setting('t.dave')::uuid);
select public.join_group(current_setting('t.code'));
select tests.as_user(current_setting('t.alice')::uuid);
select tests.ok(tests.affected($$update public.group_members set role = 'admin' where user_id = current_setting('t.dave')::uuid$$) = 1, 'owner promotes dave to admin');
select tests.fails($$update public.group_members set role = 'owner' where user_id = current_setting('t.dave')::uuid$$, 'roles cannot be set to owner directly');

select tests.as_user(current_setting('t.dave')::uuid);
with r as (insert into public.group_invites (group_id, max_uses) values (current_setting('t.gid')::uuid, 1) returning code)
select set_config('t.code2', r.code, false) from r;
select tests.ok(tests.affected($$delete from public.group_members where user_id = current_setting('t.alice')::uuid$$) = 0, 'admin cannot remove the owner');
select tests.ok(tests.affected($$update public.group_members set role = 'admin' where user_id = current_setting('t.bob')::uuid$$) = 0, 'admins cannot change roles');
select tests.ok(tests.affected($$delete from public.group_members where user_id = current_setting('t.bob')::uuid$$) = 1, 'admin removes bob');

select tests.as_user(current_setting('t.bob')::uuid);
select tests.ok(tests.n($$select 1 from public.messages$$) + tests.n($$select 1 from public.posts$$) + tests.n($$select 1 from public.groups$$) = 0,
  'removed member immediately loses access');
select tests.ok(tests.n($$select 1 from storage.objects where bucket_id = 'group-media'$$) = 0, 'removed member loses access to media');

select tests.as_user(current_setting('t.alice')::uuid);
update public.group_invites set revoked_at = now() where code = current_setting('t.code');
select tests.as_user(current_setting('t.bob')::uuid);
select tests.fails($$select public.join_group(current_setting('t.code'))$$, 'revoked invite cannot be used');
select public.join_group(current_setting('t.code2'));
select tests.as_user(current_setting('t.carol')::uuid);
select tests.fails($$select public.join_group(current_setting('t.code2'))$$, 'single-use invite cannot be used twice');

select tests.as_user(current_setting('t.alice')::uuid);
select tests.ok(tests.affected($$delete from public.group_members where user_id = current_setting('t.alice')::uuid$$) = 0, 'owner cannot leave without handing over');
select public.transfer_ownership(current_setting('t.gid')::uuid, current_setting('t.dave')::uuid);
select tests.ok((select role from public.group_members where user_id = current_setting('t.alice')::uuid) = 'admin', 'old owner becomes admin after transfer');
select tests.ok((select owner_id from public.groups) = current_setting('t.dave')::uuid, 'groups.owner_id follows the transfer');

reset role;
select tests.ok(exists (select 1 from pg_publication_tables where pubname = 'supabase_realtime' and tablename = 'messages'),
  'messages are published to Realtime');
select tests.ok(not exists (
  select 1 from pg_tables t where t.schemaname = 'public' and not t.rowsecurity
), 'every public table has RLS enabled');

\echo ''
\echo 'All privacy checks passed.'
