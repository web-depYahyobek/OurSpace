# OurSpace

**Friends. Together.** A private, invite-only social space for one close friend group: group chat, shared photos, polls, events and announcements.

Built with React 19, Vite, TypeScript, Tailwind CSS 4 and Supabase (Auth, Postgres, Storage, Realtime).

![Mobile screens](docs/screenshots/mobile.png)

> The screenshots use made-up sample data from a local preview. The app has no sample data: everything you see comes from your Supabase project.

---

## What's included

| Area | What works |
| --- | --- |
| **Accounts** | Sign up, sign in, sign out, persistent sessions, email confirmation, profile with name, username and optional avatar |
| **Private groups** | Create a group (you become owner), invite links/codes with expiry and use limits, revoke invites, join via link or code, roles (owner/admin/member), promote/demote admins, remove members, transfer ownership, leave group, group settings |
| **Home feed** | Member strip, pinned announcement and next-event highlights, photo posts newest first, likes, comments, delete own posts (admins can delete any) |
| **Photos** | Upload with type/size checks and a real progress bar, gallery grid, photo detail view with likes and comments |
| **Group chat** | Realtime messages, image attachments, day separators, grouped bubbles, sends appear instantly with retry if they fail, "load earlier", jump-to-new, live/offline indicator with automatic catch-up after reconnecting |
| **Polls** | 2–10 options, single choice, one vote per person (changeable while open), optional closing time, results hidden until you vote (or public), live vote counts, creator/admin can close |
| **Events** | Title, date, start/end time, location, details; RSVP Going/Maybe/Can't go; upcoming and past sections; attendee lists and counts |
| **Announcements** | Admin-only by default (setting allows all members), pin/unpin (admins only), live updates |
| **UX** | Mobile-first dark theme, bottom nav on phones and sidebar on desktop, loading skeletons, empty states, friendly errors, toasts, accessible forms and dialogs, keyboard support, reduced-motion support |

---

## Setup

### 1. Prerequisites

- Node.js 20 or newer
- A free Supabase project: [supabase.com/dashboard](https://supabase.com/dashboard)

### 2. Install

```bash
npm install
```

### 3. Environment variables

```bash
cp .env.example .env.local
```

Fill in both values from **Supabase → Project Settings → API**:

| Variable | Value |
| --- | --- |
| `VITE_SUPABASE_URL` | Project URL, e.g. `https://abcd1234.supabase.co` |
| `VITE_SUPABASE_ANON_KEY` | The **anon** key (or the newer **publishable** key, `sb_publishable_…`) |

Both are safe to ship to the browser; the database policies do the protecting. **Never** put the `service_role` / secret key in a `VITE_` variable.

If these are missing, the app shows a setup screen instead of failing.

### 4. Create the database

Run the five files in `supabase/migrations/` **in file-name order**. Either:

- **SQL editor**: paste each file into Supabase → SQL Editor and run it, or
- **Supabase CLI**:
  ```bash
  npx supabase link --project-ref <your-project-ref>
  npx supabase db push
  ```

| File | Creates |
| --- | --- |
| `…000100_schema.sql` | Tables, constraints, indexes |
| `…000200_functions.sql` | Membership helpers and RPCs (create group, join, polls, voting, RSVP, pinning, ownership transfer) |
| `…000300_rls.sql` | Row Level Security on every table, plus column-level privileges |
| `…000400_storage.sql` | Private `group-media` (10 MB) and `avatars` (2 MB) buckets and their policies |
| `…000500_realtime.sql` | Realtime for messages, poll votes and announcements |

### 5. Configure Auth

In **Supabase → Authentication → URL Configuration**:

- **Site URL**: `http://localhost:5173` for development (your real domain once deployed)
- **Redirect URLs**: add `http://localhost:5173/**` and your production URL with `/**`

Email confirmation is on by default in Supabase. New users then get a "check your email" screen, and the link brings them back to where they started (including an invite link). For quick local testing you can turn off **Confirm email** under Authentication → Providers → Email.

### 6. Run

```bash
npm run dev        # http://localhost:5173
npm run build      # type-check + production build into dist/
npm run preview    # serve the production build
```

### 7. First run

1. Sign up and create your profile.
2. Choose **Start a new group**. You are the owner.
3. On **Members**, create an invite link and send it to your friends.
4. Friends open the link, sign up, and join.

---

## Security model

Privacy is enforced **in the database**, not in the React code. The route guards in `App.tsx` only decide which screen to show.

- **RLS on every table.** A user can read a group's data only if they are in `group_members` for that group. Removing someone takes effect on their very next request.
- **You act only as yourself.** Every insert checks `author_id` / `sender_id` / `user_id = auth.uid()`.
- **Column-level grants.** Clients can only write the columns that make sense. For example, a post's caption can be edited but its `group_id` cannot, and `is_pinned` cannot be set by a normal update.
- **No direct writes to sensitive tables.** Groups, memberships, polls and pins change only through `SECURITY DEFINER` / RLS-checked functions that validate everything.
- **Private storage.** Files live at `<group_id>/<user_id>/<file>`. Only members can read a group's files, and only through short-lived signed URLs. You can only upload into your own folder.
- **Profiles** are visible only to yourself and people who share a group with you. There is no public directory or discovery.
- **Invites** are random 8-character codes with optional expiry and use limits. Admins can revoke them.

### Testing the policies

`supabase/tests/rls_test.sql` contains 78 checks covering outsiders, plain members, admins and owners: reading, impersonation, voting rules, invites, storage and removal. Run them against a throwaway local PostgreSQL (no Supabase account needed; requires PostgreSQL 15+ installed locally):

```bash
npm run test:db
```

The script runs the migrations on top of a small stand-in for Supabase's `auth`, `storage` and `realtime` pieces (`supabase/tests/supabase_stub.sql`). Never run that stub against a real project.

---

## Project structure

```
src/
  App.tsx                 routes and navigation guards
  main.tsx                entry point
  index.css               Tailwind theme and design tokens
  lib/                    Supabase client, types, uploads and signed URLs, formatting, errors
  contexts/               Auth (session + profile), Group (current group, role, members), Toasts
  components/ui/          Button, fields, avatar, modal, confirm dialog, image picker, skeletons…
  components/layout/      App shell (sidebar, top bar, bottom nav), logo, page header
  features/
    auth/                 welcome, sign in, sign up
    profile/              profile setup and settings
    groups/               onboarding, join via invite, members and invites, group settings
    feed/                 home feed, posts, likes, comments, gallery
    chat/                 realtime chat
    polls/                polls and voting
    events/               events and RSVPs
    announcements/        announcements and pinning
supabase/
  migrations/             SQL to run in order
  tests/                  RLS tests and local Supabase stand-in
scripts/test-db.sh        runs the RLS tests on a temporary local Postgres
```

---

## Changes from the original blueprint

These are intentional changes:

- **`group_invites` table instead of `groups.invite_code`.** One code per group can't be revoked without breaking it for everyone. Separate invites can each expire, have a use limit and be revoked.
- **`image_path` / `attachment_path` / `avatar_path` instead of `*_url`.** Buckets are private, so the database stores the storage path and the app creates a short-lived signed URL when showing the image.
- **Members strip instead of a stories strip.** Stories would be a new feature; the strip shows the group's members with an Invite button for admins, matching the concept board's look.
- **Extra columns:** `groups.members_can_announce` (the "optionally trusted members" setting), `polls.show_results_before_vote` (public results), `events.ends_at`, `poll_options.position`.
- **Database functions** for multi-step actions that must succeed or fail together: `create_group`, `preview_invite`, `join_group`, `create_poll`, `cast_vote`, `set_rsvp`, `set_announcement_pinned`, `transfer_ownership`.

---

## Deploying

Any static host works. Build with `npm run build` and serve `dist/`. The app uses client-side routes, so every path must serve `index.html`:

- **Vercel**: `vercel.json` is included.
- **Netlify**: `public/_redirects` is included.

Set `VITE_SUPABASE_URL` and `VITE_SUPABASE_ANON_KEY` in the host's environment settings, and add the production URL to Supabase's redirect URLs.

---

## Ideas for later

Password reset, editing events and posts, multiple-choice polls, read receipts, push notifications, image compression before upload, message reactions, and generated database types (`npx supabase gen types typescript`).
